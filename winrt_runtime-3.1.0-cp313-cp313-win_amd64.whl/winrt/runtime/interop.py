from winrt._winrt import initialize_with_window

__all__ = ["initialize_with_window"]
