﻿$exePath = "C:\Users\HuangXiaoXi\Downloads\202512\sogou_pinyin_guanwang_15.11.exe"

$script:InstallerWindowFinder =  @"
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

public static class InstallerWindowFinder
{
    public static IntPtr StartAndFindInteractiveWindow(
        string exePath,
        string arguments,
        int timeoutMs)
    {
        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = exePath;
        psi.Arguments = arguments;
        psi.UseShellExecute = true;

        Process rootProcess = Process.Start(psi);
        if (rootProcess == null)
            throw new InvalidOperationException("Failed to start installer.");

        Stopwatch sw = Stopwatch.StartNew();

        while (sw.ElapsedMilliseconds < timeoutMs)
        {
            HashSet<int> relatedPids = CollectProcessTree(rootProcess.Id);

            List<IntPtr> windows = EnumerateTopLevelWindows();
            foreach (IntPtr hwnd in windows)
            {
                uint pid;
                GetWindowThreadProcessId(hwnd, out pid);

                if (!relatedPids.Contains((int)pid))
                    continue;

                if (!IsCandidateInteractiveWindow(hwnd))
                    continue;

                return hwnd;
            }

            Thread.Sleep(200);
        }

        throw new TimeoutException("Timeout waiting for real installer UI window.");
    }

    // =========================
    // Process tree
    // =========================

    private static HashSet<int> CollectProcessTree(int rootPid)
    {
        HashSet<int> result = new HashSet<int>();
        result.Add(rootPid);

        Process[] all = Process.GetProcesses();
        foreach (Process p in all)
        {
            try
            {
                int parent = GetParentProcessId(p);
                if (parent == rootPid)
                {
                    result.Add(p.Id);
                    HashSet<int> children = CollectProcessTree(p.Id);
                    foreach (int c in children)
                        result.Add(c);
                }
            }
            catch { }
        }

        return result;
    }

    private static int GetParentProcessId(Process process)
    {
        PROCESS_BASIC_INFORMATION pbi;
        int returnLength;

        int status = NtQueryInformationProcess(
            process.Handle,
            0, // ProcessBasicInformation
            out pbi,
            Marshal.SizeOf(typeof(PROCESS_BASIC_INFORMATION)),
            out returnLength
        );

        if (status != 0)
            throw new InvalidOperationException("NtQueryInformationProcess failed.");

        return pbi.InheritedFromUniqueProcessId.ToInt32();
    }

    // =========================
    // Window enumeration
    // =========================

    private static List<IntPtr> EnumerateTopLevelWindows()
    {
        List<IntPtr> list = new List<IntPtr>();

        EnumWindows(delegate (IntPtr hWnd, IntPtr lParam)
        {
            list.Add(hWnd);
            return true;
        }, IntPtr.Zero);

        return list;
    }

    private static bool IsCandidateInteractiveWindow(IntPtr hwnd)
    {
        if (!IsWindowVisible(hwnd))
            return false;

        if (!IsWindowEnabled(hwnd))
            return false;

        RECT r;
        GetWindowRect(hwnd, out r);
        if (r.Right - r.Left < 120 || r.Bottom - r.Top < 120)
            return false;

        int style = GetWindowLong(hwnd, GWL_STYLE);
        int exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);

        if ((exStyle & WS_EX_TOOLWINDOW) != 0)
            return false;

        return ((style & WS_CAPTION) != 0) || ((style & WS_POPUP) != 0);
    }

    // =========================
    // Win32
    // =========================

    private const int GWL_STYLE = -16;
    private const int GWL_EXSTYLE = -20;

    private const int WS_CAPTION = 0x00C00000;
    private const int WS_POPUP = unchecked((int)0x80000000);
    private const int WS_EX_TOOLWINDOW = 0x00000080;

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsWindowEnabled(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    [DllImport("ntdll.dll")]
    private static extern int NtQueryInformationProcess(
        IntPtr processHandle,
        int processInformationClass,
        out PROCESS_BASIC_INFORMATION processInformation,
        int processInformationLength,
        out int returnLength
    );

    private struct PROCESS_BASIC_INFORMATION
    {
        public IntPtr Reserved1;
        public IntPtr PebBaseAddress;
        public IntPtr Reserved2_0;
        public IntPtr Reserved2_1;
        public IntPtr UniqueProcessId;
        public IntPtr InheritedFromUniqueProcessId;
    }

    private struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}
"@
# 获取最终显示在用户界面的进程句柄
function Start-InstallerAndWaitRealUI {
    param (
        [Parameter(Mandatory)]
        [string]$ExePath,
        [string]$Arguments = "",
        [int]$TimeoutSeconds = 60
    )

    if (-not ([System.Management.Automation.PSTypeName]'InstallerWindowFinder').Type) {
        Add-Type -TypeDefinition $script:InstallerWindowFinder -Language CSharp
    }

    return [InstallerWindowFinder]::StartAndFindInteractiveWindow(
        $ExePath,
        $Arguments,
        $TimeoutSeconds * 1000
    )
}


Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;

public static class ButtonClicker
{
    public const int BM_CLICK = 0x00F5;

    public delegate bool EnumChildProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    static extern bool EnumChildWindows(IntPtr hWnd, EnumChildProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

    public static bool ClickButtonByCaption(IntPtr parentHwnd, string caption)
    {
        IntPtr found = IntPtr.Zero;

        EnumChildWindows(parentHwnd, delegate (IntPtr hWnd, IntPtr lParam)
        {
            StringBuilder sb = new StringBuilder(256);
            GetWindowText(hWnd, sb, sb.Capacity);

            if (sb.ToString() == caption)
            {
                found = hWnd;
                return false;
            }
            return true;
        }, IntPtr.Zero);

        if (found == IntPtr.Zero)
            return false;

        SendMessage(found, BM_CLICK, IntPtr.Zero, IntPtr.Zero);
        return true;
    }
}
"@

$script:PostInstallWindowFinder = @"
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class PostInstallWindowFinder
{
    public static IntPtr WaitForWindow(
        DateTime afterTime,
        int timeoutMs,
        string[] captionKeywords)
    {
        Stopwatch sw = Stopwatch.StartNew();

        while (sw.ElapsedMilliseconds < timeoutMs)
        {
            List<IntPtr> windows = EnumerateTopLevelWindows();
            foreach (IntPtr hwnd in windows)
            {
                if (!IsCandidate(hwnd))
                    continue;

                string title = GetTitle(hwnd);
                if (!MatchCaption(title, captionKeywords))
                    continue;

                return hwnd;
            }

            Thread.Sleep(200);
        }

        return IntPtr.Zero;
    }

    private static bool IsCandidate(IntPtr hwnd)
    {
        if (!IsWindowVisible(hwnd) || !IsWindowEnabled(hwnd))
            return false;

        RECT r;
        GetWindowRect(hwnd, out r);
        return (r.Right - r.Left) > 120 && (r.Bottom - r.Top) > 120;
    }

    private static bool MatchCaption(string title, string[] keywords)
    {
        if (keywords == null || keywords.Length == 0)
            return true;

        foreach (string k in keywords)
        {
            if (title.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0)
                return true;
        }
        return false;
    }

    private static string GetTitle(IntPtr hwnd)
    {
        StringBuilder sb = new StringBuilder(256);
        GetWindowText(hwnd, sb, sb.Capacity);
        return sb.ToString();
    }

    private static List<IntPtr> EnumerateTopLevelWindows()
    {
        List<IntPtr> list = new List<IntPtr>();
        EnumWindows(delegate (IntPtr hWnd, IntPtr lParam)
        {
            list.Add(hWnd);
            return true;
        }, IntPtr.Zero);
        return list;
    }

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsWindowEnabled(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    private struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}
"@

function Wait-PostInstallUI {
    param (
        [DateTime]$AfterTime,
        [int]$TimeoutSeconds = 30,
        [string[]]$CaptionKeywords = @()
    )

    if (-not ([System.Management.Automation.PSTypeName]'PostInstallWindowFinder').Type) {
        Add-Type -TypeDefinition $script:PostInstallWindowFinder -Language CSharp
    }

    return [PostInstallWindowFinder]::WaitForWindow(
        $AfterTime,
        $TimeoutSeconds * 1000,
        $CaptionKeywords
    )
}


function Invoke-WindowClickByRatio {
    param (
        [Parameter(Mandatory)]
        [IntPtr]$Hwnd,

        [Parameter(Mandatory)]
        [double]$XRatio,

        [Parameter(Mandatory)]
        [double]$YRatio,

        [int]$DelayMs = 80
    )

    if ($XRatio -le 0 -or $XRatio -ge 1 -or
        $YRatio -le 0 -or $YRatio -ge 1) {
        throw "比例值必须在 0~1 之间"
    }

    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class Win32RatioClick
{
    public const int WM_LBUTTONDOWN = 0x0201;
    public const int WM_LBUTTONUP   = 0x0202;
    public const int MK_LBUTTON     = 0x0001;

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [DllImport("user32.dll")]
    public static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll")]
    public static extern IntPtr SendMessage(
        IntPtr hWnd,
        int Msg,
        IntPtr wParam,
        IntPtr lParam
    );

    public static IntPtr MakeLParam(int x, int y) {
        return (IntPtr)((y << 16) | (x & 0xFFFF));
    }
}
"@ -PassThru | Out-Null

    # 获取客户区尺寸
    $rect = New-Object Win32RatioClick+RECT
    if (-not [Win32RatioClick]::GetClientRect($Hwnd, [ref]$rect)) {
        throw "GetClientRect 失败"
    }

    $clientWidth  = $rect.Right
    $clientHeight = $rect.Bottom

    # 计算点击坐标
    $x = [int]($clientWidth  * $XRatio)
    $y = [int]($clientHeight * $YRatio)

    $lParam = [Win32RatioClick]::MakeLParam($x, $y)

    # 注入点击
    [Win32RatioClick]::SendMessage(
        $Hwnd,
        [Win32RatioClick]::WM_LBUTTONDOWN,
        [IntPtr][Win32RatioClick]::MK_LBUTTON,
        $lParam
    ) | Out-Null

    Start-Sleep -Milliseconds $DelayMs

    [Win32RatioClick]::SendMessage(
        $Hwnd,
        [Win32RatioClick]::WM_LBUTTONUP,
        [IntPtr]0,
        $lParam
    ) | Out-Null
}



$hwnd = Start-InstallerAndWaitRealUI -ExePath $exePath -TimeoutSeconds 90

Write-Host $hwnd

Invoke-WindowClickByRatio -Hwnd $hwnd -XRatio 0.09 -YRatio 0.62

# [ButtonClicker]::ClickButtonByCaption($hwnd, "Bro&wse...")

# # 记录安装器结束时间
# $endTime = Get-Date

# # 等待 WinRAR 后续设置窗口
# $hwnd = Wait-PostInstallUI `
#     -AfterTime $endTime `
#     -CaptionKeywords @("WinRAR", "Setup", "Options")

# if ($hwnd -ne [IntPtr]::Zero) {
#     "WinRAR post-install window: 0x{0:X}" -f $hwnd.ToInt64()
# }