using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

public static class InstallerWindowFinder
{
    public static IntPtr StartAndFindInteractiveWindow(
        string exePath,
        string arguments,
        int timeoutMs)
    {
        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = exePath;
        psi.Arguments = arguments;
        psi.UseShellExecute = true;

        Process rootProcess = Process.Start(psi);
        if (rootProcess == null)
            throw new InvalidOperationException("Failed to start installer.");

        Stopwatch sw = Stopwatch.StartNew();

        while (sw.ElapsedMilliseconds < timeoutMs)
        {
            HashSet<int> relatedPids = CollectProcessTree(rootProcess.Id);

            List<IntPtr> windows = EnumerateTopLevelWindows();
            foreach (IntPtr hwnd in windows)
            {
                uint pid;
                GetWindowThreadProcessId(hwnd, out pid);

                if (!relatedPids.Contains((int)pid))
                    continue;

                if (!IsCandidateInteractiveWindow(hwnd))
                    continue;

                return hwnd;
            }

            Thread.Sleep(200);
        }

        throw new TimeoutException("Timeout waiting for real installer UI window.");
    }

    // =========================
    // Process tree
    // =========================

    private static HashSet<int> CollectProcessTree(int rootPid)
    {
        HashSet<int> result = new HashSet<int>();
        result.Add(rootPid);

        Process[] all = Process.GetProcesses();
        foreach (Process p in all)
        {
            try
            {
                int parent = GetParentProcessId(p);
                if (parent == rootPid)
                {
                    result.Add(p.Id);
                    HashSet<int> children = CollectProcessTree(p.Id);
                    foreach (int c in children)
                        result.Add(c);
                }
            }
            catch { }
        }

        return result;
    }

    private static int GetParentProcessId(Process process)
    {
        PROCESS_BASIC_INFORMATION pbi;
        int returnLength;

        int status = NtQueryInformationProcess(
            process.Handle,
            0, // ProcessBasicInformation
            out pbi,
            Marshal.SizeOf(typeof(PROCESS_BASIC_INFORMATION)),
            out returnLength
        );

        if (status != 0)
            throw new InvalidOperationException("NtQueryInformationProcess failed.");

        return pbi.InheritedFromUniqueProcessId.ToInt32();
    }

    // =========================
    // Window enumeration
    // =========================

    private static List<IntPtr> EnumerateTopLevelWindows()
    {
        List<IntPtr> list = new List<IntPtr>();

        EnumWindows(delegate (IntPtr hWnd, IntPtr lParam)
        {
            list.Add(hWnd);
            return true;
        }, IntPtr.Zero);

        return list;
    }

    private static bool IsCandidateInteractiveWindow(IntPtr hwnd)
    {
        if (!IsWindowVisible(hwnd))
            return false;

        if (!IsWindowEnabled(hwnd))
            return false;

        RECT r;
        GetWindowRect(hwnd, out r);
        if (r.Right - r.Left < 120 || r.Bottom - r.Top < 120)
            return false;

        int style = GetWindowLong(hwnd, GWL_STYLE);
        int exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);

        if ((exStyle & WS_EX_TOOLWINDOW) != 0)
            return false;

        return ((style & WS_CAPTION) != 0) || ((style & WS_POPUP) != 0);
    }

    // =========================
    // Win32
    // =========================

    private const int GWL_STYLE = -16;
    private const int GWL_EXSTYLE = -20;

    private const int WS_CAPTION = 0x00C00000;
    private const int WS_POPUP = unchecked((int)0x80000000);
    private const int WS_EX_TOOLWINDOW = 0x00000080;

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsWindowEnabled(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    [DllImport("ntdll.dll")]
    private static extern int NtQueryInformationProcess(
        IntPtr processHandle,
        int processInformationClass,
        out PROCESS_BASIC_INFORMATION processInformation,
        int processInformationLength,
        out int returnLength
    );

    private struct PROCESS_BASIC_INFORMATION
    {
        public IntPtr Reserved1;
        public IntPtr PebBaseAddress;
        public IntPtr Reserved2_0;
        public IntPtr Reserved2_1;
        public IntPtr UniqueProcessId;
        public IntPtr InheritedFromUniqueProcessId;
    }

    private struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}