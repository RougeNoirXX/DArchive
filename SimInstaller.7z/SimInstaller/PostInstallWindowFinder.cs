using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class PostInstallWindowFinder
{
    public static IntPtr WaitForWindow(
        DateTime afterTime,
        int timeoutMs,
        string[] captionKeywords)
    {
        Stopwatch sw = Stopwatch.StartNew();

        while (sw.ElapsedMilliseconds < timeoutMs)
        {
            List<IntPtr> windows = EnumerateTopLevelWindows();
            foreach (IntPtr hwnd in windows)
            {
                if (!IsCandidate(hwnd))
                    continue;

                string title = GetTitle(hwnd);
                if (!MatchCaption(title, captionKeywords))
                    continue;

                return hwnd;
            }

            Thread.Sleep(200);
        }

        return IntPtr.Zero;
    }

    private static bool IsCandidate(IntPtr hwnd)
    {
        if (!IsWindowVisible(hwnd) || !IsWindowEnabled(hwnd))
            return false;

        RECT r;
        GetWindowRect(hwnd, out r);
        return (r.Right - r.Left) > 120 && (r.Bottom - r.Top) > 120;
    }

    private static bool MatchCaption(string title, string[] keywords)
    {
        if (keywords == null || keywords.Length == 0)
            return true;

        foreach (string k in keywords)
        {
            if (title.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0)
                return true;
        }
        return false;
    }

    private static string GetTitle(IntPtr hwnd)
    {
        StringBuilder sb = new StringBuilder(256);
        GetWindowText(hwnd, sb, sb.Capacity);
        return sb.ToString();
    }

    private static List<IntPtr> EnumerateTopLevelWindows()
    {
        List<IntPtr> list = new List<IntPtr>();
        EnumWindows(delegate (IntPtr hWnd, IntPtr lParam)
        {
            list.Add(hWnd);
            return true;
        }, IntPtr.Zero);
        return list;
    }

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsWindowEnabled(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    private struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}