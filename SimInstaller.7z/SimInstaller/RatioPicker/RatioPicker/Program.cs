// .NET 8 / .NET Framework 4.8 皆可编译
// WinForms 实用小工具：
// 1. 选择 EXE 并启动
// 2. 将鼠标移动到该窗口内
// 3. 实时显示鼠标在该窗口 Client 区域中的相对比例 (0~1)
// 修改：不依赖 WaitForInputIdle，支持自绘窗口或多进程启动的 EXE

using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WindowRatioPicker
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    public class MainForm : Form
    {
        private Button btnLaunch;
        private Label lblInfo;
        private Timer timer;

        private IntPtr targetHwnd = IntPtr.Zero;

        public MainForm()
        {
            Text = "窗口坐标比例获取工具";
            Width = 300;
            Height = 180;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            btnLaunch = new Button
            {
                Text = "选择并启动 EXE",
                Left = 20,
                Top = 20,
                Width = 160
            };
            btnLaunch.Click += BtnLaunch_Click;

            lblInfo = new Label
            {
                Left = 20,
                Top = 60,
                Width = 460,
                Height = 60
            };

            Controls.Add(btnLaunch);
            Controls.Add(lblInfo);

            timer = new Timer();
            timer.Interval = 50; // 20 FPS
            timer.Tick += Timer_Tick;
        }

        private void BtnLaunch_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "Executable (*.exe)|*.exe";

                if (ofd.ShowDialog() != DialogResult.OK)
                    return;

                var p = Process.Start(ofd.FileName);
                if (p == null)
                    return;

                // 不使用 WaitForInputIdle，改为轮询 MainWindowHandle
                targetHwnd = IntPtr.Zero;
                for (int i = 0; i < 50; i++) // 最多等待 5 秒
                {
                    p.Refresh();
                    if (p.MainWindowHandle != IntPtr.Zero)
                    {
                        targetHwnd = p.MainWindowHandle;
                        break;
                    }

                    System.Threading.Thread.Sleep(100);
                }

                if (targetHwnd == IntPtr.Zero)
                {
                    MessageBox.Show("未能获取窗口句柄，请确保窗口已经启动并可见");
                    return;
                }

                lblInfo.Text = "已获取窗口句柄，请将鼠标移入目标窗口";
                timer.Start();
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (targetHwnd == IntPtr.Zero)
                return;

            GetCursorPos(out POINT screenPt);

            IntPtr hwndUnderCursor = WindowFromPoint(screenPt);
            if (hwndUnderCursor != targetHwnd && !IsChild(targetHwnd, hwndUnderCursor))
            {
                lblInfo.Text = "鼠标未在目标窗口内";
                return;
            }

            if (!GetClientRect(targetHwnd, out RECT clientRect))
                return;

            POINT clientPt = screenPt;
            ScreenToClient(targetHwnd, ref clientPt);

            int width = clientRect.Right - clientRect.Left;
            int height = clientRect.Bottom - clientRect.Top;

            if (width <= 0 || height <= 0)
                return;

            double rx = (double)clientPt.X / width;
            double ry = (double)clientPt.Y / height;

            lblInfo.Text =
                $"ClientSize: {width} x {height}\r\n" +
                $"ClientPos:  X={clientPt.X}, Y={clientPt.Y}\r\n" +
                $"Ratio:      X={rx:F4}, Y={ry:F4}";
        }

        #region Win32

        [DllImport("user32.dll")]
        static extern bool GetCursorPos(out POINT lpPoint);

        [DllImport("user32.dll")]
        static extern IntPtr WindowFromPoint(POINT Point);

        [DllImport("user32.dll")]
        static extern bool IsChild(IntPtr hWndParent, IntPtr hWnd);

        [DllImport("user32.dll")]
        static extern bool ScreenToClient(IntPtr hWnd, ref POINT lpPoint);

        [DllImport("user32.dll")]
        static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);

        [StructLayout(LayoutKind.Sequential)]
        struct POINT
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        #endregion
    }
}