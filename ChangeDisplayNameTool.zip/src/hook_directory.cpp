#include "pch.h"
#include "hooks.h"
#include "handle_tracker.h"
#include "config.h"
#include "path_utils.h"
#include "detours.h"

// ============================================================================
// NT directory information structures (may not be in newer WinSDK winternl.h)
// ============================================================================

#ifndef FILE_DIRECTORY_INFORMATION_DEFINED
#define FILE_DIRECTORY_INFORMATION_DEFINED
typedef struct _FILE_DIRECTORY_INFORMATION {
    ULONG         NextEntryOffset;
    ULONG         FileIndex;
    LARGE_INTEGER CreationTime;
    LARGE_INTEGER LastAccessTime;
    LARGE_INTEGER LastWriteTime;
    LARGE_INTEGER ChangeTime;
    LARGE_INTEGER EndOfFile;
    LARGE_INTEGER AllocationSize;
    ULONG         FileAttributes;
    ULONG         FileNameLength;
    WCHAR         FileName[1];
} FILE_DIRECTORY_INFORMATION, *PFILE_DIRECTORY_INFORMATION;
#endif

#ifndef FILE_FULL_DIR_INFORMATION_DEFINED
#define FILE_FULL_DIR_INFORMATION_DEFINED
typedef struct _FILE_FULL_DIR_INFORMATION {
    ULONG         NextEntryOffset;
    ULONG         FileIndex;
    LARGE_INTEGER CreationTime;
    LARGE_INTEGER LastAccessTime;
    LARGE_INTEGER LastWriteTime;
    LARGE_INTEGER ChangeTime;
    LARGE_INTEGER EndOfFile;
    LARGE_INTEGER AllocationSize;
    ULONG         FileAttributes;
    ULONG         FileNameLength;
    ULONG         EaSize;
    WCHAR         FileName[1];
} FILE_FULL_DIR_INFORMATION, *PFILE_FULL_DIR_INFORMATION;
#endif

#ifndef FILE_BOTH_DIR_INFORMATION_DEFINED
#define FILE_BOTH_DIR_INFORMATION_DEFINED
typedef struct _FILE_BOTH_DIR_INFORMATION {
    ULONG         NextEntryOffset;
    ULONG         FileIndex;
    LARGE_INTEGER CreationTime;
    LARGE_INTEGER LastAccessTime;
    LARGE_INTEGER LastWriteTime;
    LARGE_INTEGER ChangeTime;
    LARGE_INTEGER EndOfFile;
    LARGE_INTEGER AllocationSize;
    ULONG         FileAttributes;
    ULONG         FileNameLength;
    ULONG         EaSize;
    CCHAR         ShortNameLength;
    WCHAR         ShortName[12];
    WCHAR         FileName[1];
} FILE_BOTH_DIR_INFORMATION, *PFILE_BOTH_DIR_INFORMATION;
#endif

#ifndef FILE_NAMES_INFORMATION_DEFINED
#define FILE_NAMES_INFORMATION_DEFINED
typedef struct _FILE_NAMES_INFORMATION {
    ULONG NextEntryOffset;
    ULONG FileIndex;
    ULONG FileNameLength;
    WCHAR FileName[1];
} FILE_NAMES_INFORMATION, *PFILE_NAMES_INFORMATION;
#endif

namespace HookDirectory
{

PFN_NtQueryDirectoryFile  OriginalNtQueryDirectoryFile  = nullptr;
PFN_NtQueryDirectoryFileEx OriginalNtQueryDirectoryFileEx = nullptr;

struct ScanState
{
    bool injectedDesktopIni;
};

static std::unordered_map<HANDLE, ScanState> g_scanStates;
static CRITICAL_SECTION g_scanCs;

static const ULONG kFileDirectoryInformation      = 1;
static const ULONG kFileFullDirectoryInformation   = 2;
static const ULONG kFileBothDirectoryInformation   = 3;
static const ULONG kFileNamesInformation           = 12;
static const ULONG kFileIdBothDirectoryInformation = 37;

static ULONG GetFileNameOffset(ULONG infoClass)
{
    switch (infoClass)
    {
    case kFileDirectoryInformation:      return FIELD_OFFSET(FILE_DIRECTORY_INFORMATION, FileName);
    case kFileFullDirectoryInformation:   return FIELD_OFFSET(FILE_FULL_DIR_INFORMATION, FileName);
    case kFileBothDirectoryInformation:   return FIELD_OFFSET(FILE_BOTH_DIR_INFORMATION, FileName);
    case kFileIdBothDirectoryInformation: return FIELD_OFFSET(FILE_ID_BOTH_DIR_INFORMATION_CUSTOM, FileName);
    case kFileNamesInformation:           return FIELD_OFFSET(FILE_NAMES_INFORMATION, FileName);
    default: return 0;
    }
}

static ULONG GetFileNameLengthOffset(ULONG infoClass)
{
    switch (infoClass)
    {
    case kFileNamesInformation:
        return FIELD_OFFSET(FILE_NAMES_INFORMATION, FileNameLength);
    default:
        return 60;
    }
}

static ULONG GetAttrOffset(ULONG infoClass)
{
    switch (infoClass)
    {
    case kFileDirectoryInformation:
    case kFileFullDirectoryInformation:
    case kFileBothDirectoryInformation:
    case kFileIdBothDirectoryInformation:
        return 56;
    default:
        return 0;
    }
}

static ULONG GetEntryBaseSize(ULONG infoClass)
{
    switch (infoClass)
    {
    case kFileDirectoryInformation:      return sizeof(FILE_DIRECTORY_INFORMATION) - sizeof(WCHAR);
    case kFileFullDirectoryInformation:   return sizeof(FILE_FULL_DIR_INFORMATION) - sizeof(WCHAR);
    case kFileBothDirectoryInformation:   return sizeof(FILE_BOTH_DIR_INFORMATION) - sizeof(WCHAR);
    case kFileIdBothDirectoryInformation: return sizeof(FILE_ID_BOTH_DIR_INFORMATION_CUSTOM) - sizeof(WCHAR);
    case kFileNamesInformation:           return sizeof(FILE_NAMES_INFORMATION) - sizeof(WCHAR);
    default: return 0;
    }
}

static bool IsSupportedClass(ULONG infoClass)
{
    return infoClass == kFileDirectoryInformation
        || infoClass == kFileFullDirectoryInformation
        || infoClass == kFileBothDirectoryInformation
        || infoClass == kFileIdBothDirectoryInformation
        || infoClass == kFileNamesInformation;
}

static bool IsClassWithAttributes(ULONG infoClass)
{
    return infoClass != kFileNamesInformation;
}

// Common prefix offsets (same across FILE_DIRECTORY/FULL/BOTH/ID_BOTH)
static const ULONG kOff_NextEntryOffset = 0;

static bool ContainsDesktopIni(BYTE* buf, ULONG bytesWritten, ULONG infoClass)
{
    ULONG nameOff = GetFileNameOffset(infoClass);
    ULONG nameLenOff = GetFileNameLengthOffset(infoClass);
    if (nameOff == 0) return false;

    BYTE* pos = buf;
    ULONG remaining = bytesWritten;

    while (remaining >= nameOff + 2)
    {
        ULONG nextOffset     = *(ULONG*)(pos + 0);
        ULONG fileNameLength = *(ULONG*)(pos + nameLenOff);
        WCHAR* fileName      = (WCHAR*)(pos + nameOff);

        if (fileNameLength == 22 && _wcsnicmp(fileName, L"desktop.ini", 11) == 0)
            return true;

        if (nextOffset == 0) break;
        if (nextOffset > remaining) break;

        pos += nextOffset;
        remaining -= nextOffset;
    }
    return false;
}

static BYTE* WalkToLastEntry(BYTE* buf, ULONG bytesWritten, ULONG infoClass)
{
    ULONG nameOff = GetFileNameOffset(infoClass);
    if (nameOff == 0) return nullptr;

    BYTE* pos = buf;
    BYTE* last = buf;
    ULONG remaining = bytesWritten;

    while (remaining >= nameOff + 2)
    {
        ULONG nextOffset = *(ULONG*)(pos + 0);
        last = pos;
        if (nextOffset == 0) break;
        if (nextOffset > remaining) break;
        pos += nextOffset;
        remaining -= nextOffset;
    }
    return last;
}

static void SetEntryTimes(BYTE* entry, ULONG infoClass)
{
    if (infoClass == kFileNamesInformation) return;

    FILETIME ft;
    GetSystemTimeAsFileTime(&ft);
    LARGE_INTEGER li;
    li.LowPart  = ft.dwLowDateTime;
    li.HighPart = ft.dwHighDateTime;

    static const ULONG offCT = 8,  offLAT = 16, offLWT = 24, offCT2 = 32;
    static const ULONG offEOF = 40, offAS  = 48;

    *(LARGE_INTEGER*)(entry + offCT)  = li;
    *(LARGE_INTEGER*)(entry + offLAT) = li;
    *(LARGE_INTEGER*)(entry + offLWT) = li;
    *(LARGE_INTEGER*)(entry + offCT2) = li;

    LARGE_INTEGER fileSize;
    fileSize.QuadPart = 100;
    *(LARGE_INTEGER*)(entry + offEOF) = fileSize;
    *(LARGE_INTEGER*)(entry + offAS)  = fileSize;
}

static bool TryInjectDesktopIni(
    BYTE* buf,
    ULONG bufLength,
    PIO_STATUS_BLOCK IoStatusBlock,
    ULONG infoClass)
{
    if (!IsSupportedClass(infoClass)) return false;

    ULONG bytesUsed = IoStatusBlock->Information;

    if (ContainsDesktopIni(buf, bytesUsed, infoClass)) return false;

    const wchar_t* fileName = L"desktop.ini";
    size_t nameLen    = wcslen(fileName);
    size_t nameBytes  = nameLen * sizeof(WCHAR);
    ULONG  baseSize   = GetEntryBaseSize(infoClass);
    ULONG  entrySize  = baseSize + (ULONG)nameBytes;

    entrySize = (entrySize + 7) & ~7UL;

    if (bytesUsed + entrySize > bufLength)
        return false;

    BYTE* entry = buf + bytesUsed;
    memset(entry, 0, entrySize);

    if (IsClassWithAttributes(infoClass))
    {
        SetEntryTimes(entry, infoClass);

        ULONG attrOff = GetAttrOffset(infoClass);
        if (attrOff > 0)
        {
            *(ULONG*)(entry + attrOff) = FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM | FILE_ATTRIBUTE_ARCHIVE;
        }
    }

    ULONG nameLenOff = GetFileNameLengthOffset(infoClass);
    *(ULONG*)(entry + nameLenOff) = (ULONG)nameBytes;

    ULONG nameOff = GetFileNameOffset(infoClass);
    wcscpy_s((wchar_t*)(entry + nameOff), nameLen + 1, fileName);

    if (bytesUsed > 0)
    {
        BYTE* last = WalkToLastEntry(buf, bytesUsed, infoClass);
        if (last)
        {
            *(ULONG*)(last + 0) = static_cast<ULONG>(entry - last);
        }
    }

    IoStatusBlock->Information = bytesUsed + entrySize;
    return true;
}

// ============================================================================
// P0.2: Patch FILE_ATTRIBUTE_READONLY on target folder entries in enumeration
// ============================================================================
static bool TryPatchTargetFolderAttributes(
    BYTE* buf,
    ULONG bytesWritten,
    ULONG infoClass,
    HANDLE dirHandle)
{
    if (!IsClassWithAttributes(infoClass)) return false;

    std::wstring parentPath = GetParentPathByHandle(dirHandle);
    if (parentPath.empty()) return false;

    ULONG nameOff    = GetFileNameOffset(infoClass);
    ULONG nameLenOff = GetFileNameLengthOffset(infoClass);
    ULONG attrOff    = GetAttrOffset(infoClass);
    if (nameOff == 0 || attrOff == 0) return false;

    BYTE* pos = buf;
    ULONG remaining = bytesWritten;

    while (remaining >= nameOff + 2)
    {
        ULONG nextOffset     = *(ULONG*)(pos + 0);
        ULONG fileNameLength = *(ULONG*)(pos + nameLenOff);
        WCHAR* fileName      = (WCHAR*)(pos + nameOff);
        ULONG attrs          = *(ULONG*)(pos + attrOff);

        if (attrs & FILE_ATTRIBUTE_DIRECTORY)
        {
            std::wstring entryName(fileName, fileNameLength / sizeof(WCHAR));
            std::wstring fullPath = parentPath + L"\\" + entryName;

            if (IsTargetFolderPath(fullPath.c_str()))
            {
                *(ULONG*)(pos + attrOff) |= FILE_ATTRIBUTE_READONLY;
            }
        }

        if (nextOffset == 0) break;
        if (nextOffset > remaining) break;

        pos += nextOffset;
        remaining -= nextOffset;
    }

    return true;
}

static bool IsHandleScanned(HANDLE handle, bool restartScan, bool& injected)
{
    EnterCriticalSection(&g_scanCs);
    if (restartScan)
        g_scanStates[handle] = ScanState{ false };
    auto it = g_scanStates.find(handle);
    if (it == g_scanStates.end())
    {
        g_scanStates[handle] = ScanState{ false };
        it = g_scanStates.find(handle);
    }
    injected = it->second.injectedDesktopIni;
    LeaveCriticalSection(&g_scanCs);
    return true;
}

static void MarkInjected(HANDLE handle)
{
    EnterCriticalSection(&g_scanCs);
    g_scanStates[handle].injectedDesktopIni = true;
    LeaveCriticalSection(&g_scanCs);
}

// ============================================================================
// Helper: post-process directory enumeration results
// ============================================================================
static void PostProcessEnumeration(
    HANDLE FileHandle,
    PVOID FileInformation,
    ULONG Length,
    PIO_STATUS_BLOCK IoStatusBlock,
    ULONG infoClass,
    bool& injected)
{
    BYTE* buf = (BYTE*)FileInformation;

    // P0.2: Patch READONLY on target folder entries
    TryPatchTargetFolderAttributes(buf, IoStatusBlock->Information, infoClass, FileHandle);

    // Inject virtual desktop.ini
    if (!injected)
    {
        if (TryInjectDesktopIni(buf, Length, IoStatusBlock, infoClass))
        {
            MarkInjected(FileHandle);
        }
    }
}

NTSTATUS NTAPI HookNtQueryDirectoryFile(
    HANDLE FileHandle,
    HANDLE Event,
    PIO_APC_ROUTINE ApcRoutine,
    PVOID ApcContext,
    PIO_STATUS_BLOCK IoStatusBlock,
    PVOID FileInformation,
    ULONG Length,
    FILE_INFORMATION_CLASS FileInformationClass,
    BOOLEAN ReturnSingleEntry,
    PUNICODE_STRING FileName,
    BOOLEAN RestartScan)
{
    bool isTarget = IsTargetDirectoryHandle(FileHandle);
    bool isParent = IsParentDirectoryHandle(FileHandle);
    bool injected = false;

    if (isTarget)
        IsHandleScanned(FileHandle, RestartScan != FALSE, injected);

    NTSTATUS status = OriginalNtQueryDirectoryFile(
        FileHandle, Event, ApcRoutine, ApcContext,
        IoStatusBlock, FileInformation, Length,
        FileInformationClass, ReturnSingleEntry, FileName, RestartScan);

    if ((isTarget || isParent) && NT_SUCCESS(status))
    {
        PostProcessEnumeration(
            FileHandle, FileInformation, Length,
            IoStatusBlock, (ULONG)FileInformationClass,
            injected);

        if (status == 0x80000006 && injected)
            status = 0;
    }

    return status;
}

NTSTATUS NTAPI HookNtQueryDirectoryFileEx(
    HANDLE FileHandle,
    HANDLE Event,
    PIO_APC_ROUTINE ApcRoutine,
    PVOID ApcContext,
    PIO_STATUS_BLOCK IoStatusBlock,
    PVOID FileInformation,
    ULONG Length,
    FILE_INFORMATION_CLASS FileInformationClass,
    ULONG QueryFlags,
    PUNICODE_STRING FileName)
{
    bool isTarget = IsTargetDirectoryHandle(FileHandle);
    bool isParent = IsParentDirectoryHandle(FileHandle);
    bool injected = false;
    bool restartScan = (QueryFlags & 0x01) != 0;

    if (isTarget)
        IsHandleScanned(FileHandle, restartScan, injected);

    NTSTATUS status = OriginalNtQueryDirectoryFileEx(
        FileHandle, Event, ApcRoutine, ApcContext,
        IoStatusBlock, FileInformation, Length,
        FileInformationClass, QueryFlags, FileName);

    if ((isTarget || isParent) && NT_SUCCESS(status))
    {
        PostProcessEnumeration(
            FileHandle, FileInformation, Length,
            IoStatusBlock, (ULONG)FileInformationClass,
            injected);

        if (status == 0x80000006 && injected)
            status = 0;
    }

    return status;
}

bool Initialize()
{
    InitializeCriticalSection(&g_scanCs);

    HMODULE hNt = GetModuleHandleW(L"ntdll.dll");
    if (!hNt) return false;

    OriginalNtQueryDirectoryFile = (PFN_NtQueryDirectoryFile)
        GetProcAddress(hNt, "NtQueryDirectoryFile");
    OriginalNtQueryDirectoryFileEx = (PFN_NtQueryDirectoryFileEx)
        GetProcAddress(hNt, "NtQueryDirectoryFileEx");

    if (!OriginalNtQueryDirectoryFile || !OriginalNtQueryDirectoryFileEx)
        return false;

    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    DetourAttach(&(PVOID&)OriginalNtQueryDirectoryFile, HookNtQueryDirectoryFile);
    DetourAttach(&(PVOID&)OriginalNtQueryDirectoryFileEx, HookNtQueryDirectoryFileEx);
    LONG err = DetourTransactionCommit();

    return err == NO_ERROR;
}

void Cleanup()
{
    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    if (OriginalNtQueryDirectoryFile)
        DetourDetach(&(PVOID&)OriginalNtQueryDirectoryFile, HookNtQueryDirectoryFile);
    if (OriginalNtQueryDirectoryFileEx)
        DetourDetach(&(PVOID&)OriginalNtQueryDirectoryFileEx, HookNtQueryDirectoryFileEx);
    DetourTransactionCommit();

    EnterCriticalSection(&g_scanCs);
    g_scanStates.clear();
    LeaveCriticalSection(&g_scanCs);
    DeleteCriticalSection(&g_scanCs);
}

} // namespace HookDirectory
