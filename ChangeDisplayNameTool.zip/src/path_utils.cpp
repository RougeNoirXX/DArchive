#include "pch.h"
#include "path_utils.h"
#include "config.h"

static const wchar_t* kProgramDataBase = L"C:\\ProgramData\\DesktopCustom";

static void ToLowerInPlace(std::wstring& s)
{
    for (auto& c : s)
    {
        c = static_cast<wchar_t>(std::towlower(static_cast<std::wint_t>(c)));
    }
}

std::wstring NormalizePath(const std::wstring& path)
{
    std::wstring result = path;

    while (!result.empty() && (result.back() == L'\\' || result.back() == L'/'))
    {
        result.pop_back();
    }

    if (result.size() >= 4 && _wcsnicmp(result.c_str(), L"\\\\?\\", 4) == 0)
    {
        result = result.substr(4);
    }
    if (result.size() >= 4 && _wcsnicmp(result.c_str(), L"\\??\\", 4) == 0)
    {
        result = result.substr(4);
    }

    if (result.size() >= 8 && _wcsnicmp(result.c_str(), L"\\\\?\\UNC\\", 8) == 0)
    {
        result = L"\\\\" + result.substr(8);
    }

    ToLowerInPlace(result);

    for (auto& c : result)
    {
        if (c == L'/')
        {
            c = L'\\';
        }
    }

    return result;
}

std::wstring BuildRedirectPath(const wchar_t* redirectKey)
{
    std::wstring path = kProgramDataBase;
    path += L"\\";
    path += redirectKey;
    return path;
}

std::wstring BuildRedirectDesktopIniPath(const wchar_t* redirectKey)
{
    return BuildRedirectPath(redirectKey) + L"\\desktop.ini";
}

const FolderCustom* FindCustomFolderByPath(const wchar_t* path)
{
    if (!path) return nullptr;

    std::wstring normalized = NormalizePath(path);

    for (size_t i = 0; i < GetCustomFolderCount(); ++i)
    {
        std::wstring target = NormalizePath(g_customFolders[i].targetPath);
        if (normalized == target)
        {
            return &g_customFolders[i];
        }
    }
    return nullptr;
}

bool IsTargetFolderPath(const wchar_t* path)
{
    return FindCustomFolderByPath(path) != nullptr;
}

bool IsParentOfTargetFolder(const wchar_t* path)
{
    if (!path) return false;

    std::wstring norm = NormalizePath(path);
    if (norm.empty()) return false;

    for (size_t i = 0; i < GetCustomFolderCount(); ++i)
    {
        std::wstring target = NormalizePath(g_customFolders[i].targetPath);
        if (target.size() > norm.size())
        {
            if (target.compare(0, norm.size(), norm) == 0
                && target[norm.size()] == L'\\')
            {
                size_t remaining = target.find(L'\\', norm.size() + 1);
                if (remaining == std::wstring::npos)
                    return true;
            }
        }
    }
    return false;
}
