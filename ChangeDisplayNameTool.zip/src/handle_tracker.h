#pragma once
#include <Windows.h>
#include <string>

struct FolderCustom;

void InitializeHandleTracker();
void CleanupHandleTracker();
void OnTargetDirectoryOpened(HANDLE handle, const FolderCustom* custom);
void OnParentDirectoryOpened(HANDLE handle, const std::wstring& path);
void OnHandleClosed(HANDLE handle);
const FolderCustom* GetTargetInfoByHandle(HANDLE handle);
bool IsTargetDirectoryHandle(HANDLE handle);
std::wstring GetParentPathByHandle(HANDLE handle);
bool IsParentDirectoryHandle(HANDLE handle);
