#include "pch.h"
#include "hooks.h"
#include "handle_tracker.h"
#include "path_utils.h"
#include "config.h"

// ============================================================================
// Forward declarations of hook functions defined in separate .cpp files
// ============================================================================

namespace HookDirectory
{
    extern PFN_NtQueryDirectoryFile  OriginalNtQueryDirectoryFile;
    extern PFN_NtQueryDirectoryFileEx OriginalNtQueryDirectoryFileEx;

    NTSTATUS NTAPI HookNtQueryDirectoryFile(
        HANDLE FileHandle, HANDLE Event, PIO_APC_ROUTINE ApcRoutine, PVOID ApcContext,
        PIO_STATUS_BLOCK IoStatusBlock, PVOID FileInformation, ULONG Length,
        FILE_INFORMATION_CLASS FileInformationClass, BOOLEAN ReturnSingleEntry,
        PUNICODE_STRING FileName, BOOLEAN RestartScan);

    NTSTATUS NTAPI HookNtQueryDirectoryFileEx(
        HANDLE FileHandle, HANDLE Event, PIO_APC_ROUTINE ApcRoutine, PVOID ApcContext,
        PIO_STATUS_BLOCK IoStatusBlock, PVOID FileInformation, ULONG Length,
        FILE_INFORMATION_CLASS FileInformationClass, ULONG QueryFlags,
        PUNICODE_STRING FileName);

    bool Initialize();
    void Cleanup();
}

namespace HookFile
{
    extern PFN_NtCreateFile OriginalNtCreateFile;
    extern PFN_NtCreateFile OriginalNtOpenFile;
    extern PFN_NtClose      OriginalNtClose;

    NTSTATUS NTAPI HookNtCreateFile(
        PHANDLE FileHandle, ACCESS_MASK DesiredAccess, POBJECT_ATTRIBUTES ObjectAttributes,
        PIO_STATUS_BLOCK IoStatusBlock, PLARGE_INTEGER AllocationSize, ULONG FileAttributes,
        ULONG ShareAccess, ULONG CreateDisposition, ULONG CreateOptions, PVOID EaBuffer, ULONG EaLength);

    NTSTATUS NTAPI HookNtOpenFile(
        PHANDLE FileHandle, ACCESS_MASK DesiredAccess, POBJECT_ATTRIBUTES ObjectAttributes,
        PIO_STATUS_BLOCK IoStatusBlock, ULONG ShareAccess, ULONG OpenOptions);

    NTSTATUS NTAPI HookNtClose(HANDLE Handle);

    bool Initialize();
    void Cleanup();
}

namespace HookAttribute
{
    extern PFN_GetFileAttributesW   OriginalGetFileAttributesW;
    extern PFN_GetFileAttributesExW OriginalGetFileAttributesExW;

    DWORD WINAPI HookGetFileAttributesW(LPCWSTR lpFileName);
    BOOL  WINAPI HookGetFileAttributesExW(LPCWSTR lpFileName, GET_FILEEX_INFO_LEVELS fInfoLevelId, LPVOID lpFileInformation);

    bool Initialize();
    void Cleanup();
}

// ============================================================================
// Global initialization / cleanup
// ============================================================================

#include "detours.h"

bool InitializeHooks()
{
    if (!HookDirectory::Initialize()) return false;
    if (!HookFile::Initialize())
    {
        HookDirectory::Cleanup();
        return false;
    }
    if (!HookAttribute::Initialize())
    {
        HookDirectory::Cleanup();
        HookFile::Cleanup();
        return false;
    }
    return true;
}

void CleanupHooks()
{
    HookAttribute::Cleanup();
    HookFile::Cleanup();
    HookDirectory::Cleanup();
}
