#pragma once
#include <string>

struct FolderCustom;

std::wstring NormalizePath(const std::wstring& path);
std::wstring BuildRedirectPath(const wchar_t* redirectKey);
std::wstring BuildRedirectDesktopIniPath(const wchar_t* redirectKey);
const FolderCustom* FindCustomFolderByPath(const wchar_t* path);
bool IsTargetFolderPath(const wchar_t* path);
bool IsParentOfTargetFolder(const wchar_t* path);
