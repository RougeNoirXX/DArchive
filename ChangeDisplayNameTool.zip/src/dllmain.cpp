#include "pch.h"
#include "hooks.h"
#include "handle_tracker.h"

namespace
{

bool IsExplorerProcess()
{
    wchar_t path[MAX_PATH];
    DWORD len = GetModuleFileNameW(nullptr, path, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) return false;

    std::wstring exe(path);
    // Find the filename portion
    size_t pos = exe.rfind(L'\\');
    if (pos != std::wstring::npos)
    {
        exe = exe.substr(pos + 1);
    }

    // Case-insensitive compare
    for (auto& c : exe)
    {
        c = static_cast<wchar_t>(std::towlower(static_cast<std::wint_t>(c)));
    }

    return exe == L"explorer.exe";
}

} // anonymous namespace

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    UNREFERENCED_PARAMETER(hModule);
    UNREFERENCED_PARAMETER(lpReserved);

    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    {
        DisableThreadLibraryCalls(hModule);

        if (!IsExplorerProcess())
            return TRUE;

        InitializeHandleTracker();

        if (!InitializeHooks())
        {
            CleanupHandleTracker();
            return FALSE;
        }
        break;
    }
    case DLL_PROCESS_DETACH:
    {
        if (IsExplorerProcess())
        {
            CleanupHooks();
            CleanupHandleTracker();
        }
        break;
    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
        break;
    }

    return TRUE;
}
