#include "pch.h"
#include "handle_tracker.h"
#include "config.h"

static std::unordered_map<HANDLE, const FolderCustom*> g_targetHandleMap;
static std::unordered_map<HANDLE, std::wstring> g_parentHandleMap;
static CRITICAL_SECTION g_cs;

void InitializeHandleTracker()
{
    InitializeCriticalSection(&g_cs);
}

void CleanupHandleTracker()
{
    EnterCriticalSection(&g_cs);
    g_targetHandleMap.clear();
    g_parentHandleMap.clear();
    LeaveCriticalSection(&g_cs);
    DeleteCriticalSection(&g_cs);
}

void OnTargetDirectoryOpened(HANDLE handle, const FolderCustom* custom)
{
    if (!handle || handle == INVALID_HANDLE_VALUE || !custom) return;
    EnterCriticalSection(&g_cs);
    g_targetHandleMap[handle] = custom;
    LeaveCriticalSection(&g_cs);
}

void OnParentDirectoryOpened(HANDLE handle, const std::wstring& path)
{
    if (!handle || handle == INVALID_HANDLE_VALUE || path.empty()) return;
    EnterCriticalSection(&g_cs);
    g_parentHandleMap[handle] = path;
    LeaveCriticalSection(&g_cs);
}

void OnHandleClosed(HANDLE handle)
{
    if (!handle || handle == INVALID_HANDLE_VALUE) return;
    EnterCriticalSection(&g_cs);
    g_targetHandleMap.erase(handle);
    g_parentHandleMap.erase(handle);
    LeaveCriticalSection(&g_cs);
}

const FolderCustom* GetTargetInfoByHandle(HANDLE handle)
{
    const FolderCustom* result = nullptr;
    EnterCriticalSection(&g_cs);
    auto it = g_targetHandleMap.find(handle);
    if (it != g_targetHandleMap.end())
        result = it->second;
    LeaveCriticalSection(&g_cs);
    return result;
}

bool IsTargetDirectoryHandle(HANDLE handle)
{
    return GetTargetInfoByHandle(handle) != nullptr;
}

std::wstring GetParentPathByHandle(HANDLE handle)
{
    std::wstring result;
    EnterCriticalSection(&g_cs);
    auto it = g_parentHandleMap.find(handle);
    if (it != g_parentHandleMap.end())
        result = it->second;
    LeaveCriticalSection(&g_cs);
    return result;
}

bool IsParentDirectoryHandle(HANDLE handle)
{
    EnterCriticalSection(&g_cs);
    bool found = g_parentHandleMap.find(handle) != g_parentHandleMap.end();
    LeaveCriticalSection(&g_cs);
    return found;
}
