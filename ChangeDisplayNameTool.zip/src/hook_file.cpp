#include "pch.h"
#include "hooks.h"
#include "handle_tracker.h"
#include "path_utils.h"
#include "config.h"
#include "detours.h"

namespace HookFile
{

PFN_NtCreateFile OriginalNtCreateFile = nullptr;
PFN_NtCreateFile OriginalNtOpenFile   = nullptr;
PFN_NtClose      OriginalNtClose      = nullptr;

static thread_local std::wstring t_redirectPath;

static bool IsDesktopIniFile(const wchar_t* fileName, ULONG nameLenBytes)
{
    if (!fileName) return false;
    if (nameLenBytes != 11 * sizeof(WCHAR)) return false;
    return _wcsnicmp(fileName, L"desktop.ini", 11) == 0;
}

static const FolderCustom* DetectTargetDirectory(POBJECT_ATTRIBUTES ObjectAttributes)
{
    if (!ObjectAttributes) return nullptr;
    if (!ObjectAttributes->ObjectName || !ObjectAttributes->ObjectName->Buffer)
        return nullptr;

    std::wstring fullPath(ObjectAttributes->ObjectName->Buffer,
                          ObjectAttributes->ObjectName->Length / sizeof(WCHAR));
    return FindCustomFolderByPath(fullPath.c_str());
}

static const FolderCustom* DetectDesktopIniOpen(POBJECT_ATTRIBUTES ObjectAttributes)
{
    if (!ObjectAttributes) return nullptr;

    if (ObjectAttributes->RootDirectory)
    {
        const FolderCustom* custom = GetTargetInfoByHandle(ObjectAttributes->RootDirectory);
        if (custom && ObjectAttributes->ObjectName && ObjectAttributes->ObjectName->Buffer)
        {
            if (IsDesktopIniFile(ObjectAttributes->ObjectName->Buffer,
                                 ObjectAttributes->ObjectName->Length))
            {
                return custom;
            }
        }
    }

    if (ObjectAttributes->ObjectName && ObjectAttributes->ObjectName->Buffer)
    {
        std::wstring fullPath(ObjectAttributes->ObjectName->Buffer,
                              ObjectAttributes->ObjectName->Length / sizeof(WCHAR));

        size_t pos = fullPath.rfind(L'\\');
        if (pos != std::wstring::npos)
        {
            std::wstring fileName  = fullPath.substr(pos + 1);
            std::wstring parentDir = fullPath.substr(0, pos);

            if (_wcsicmp(fileName.c_str(), L"desktop.ini") == 0)
            {
                return FindCustomFolderByPath(parentDir.c_str());
            }
        }
    }

    return nullptr;
}

// Detect if the opened path is a parent directory of any target folder
static bool TryTrackParentDirectory(POBJECT_ATTRIBUTES ObjectAttributes, HANDLE hNew)
{
    if (!ObjectAttributes || !ObjectAttributes->ObjectName || !ObjectAttributes->ObjectName->Buffer)
        return false;

    std::wstring fullPath(ObjectAttributes->ObjectName->Buffer,
                          ObjectAttributes->ObjectName->Length / sizeof(WCHAR));

    if (IsParentOfTargetFolder(fullPath.c_str()))
    {
        OnParentDirectoryOpened(hNew, NormalizePath(fullPath));
        return true;
    }
    return false;
}

static NTSTATUS HandleFileOpen(
    PHANDLE FileHandle,
    ACCESS_MASK DesiredAccess,
    POBJECT_ATTRIBUTES ObjectAttributes,
    PIO_STATUS_BLOCK IoStatusBlock,
    PLARGE_INTEGER AllocationSize,
    ULONG FileAttributes,
    ULONG ShareAccess,
    ULONG CreateDisposition,
    ULONG CreateOptions,
    PVOID EaBuffer,
    ULONG EaLength,
    PFN_NtCreateFile Original)
{
    const FolderCustom* iniCustom = DetectDesktopIniOpen(ObjectAttributes);

    if (iniCustom)
    {
        t_redirectPath = L"\\??\\" + BuildRedirectDesktopIniPath(iniCustom->redirectKey);

        UNICODE_STRING redirName;
        redirName.Buffer        = t_redirectPath.data();
        redirName.Length        = (USHORT)(t_redirectPath.size() * sizeof(WCHAR));
        redirName.MaximumLength = (USHORT)((t_redirectPath.size() + 1) * sizeof(WCHAR));

        OBJECT_ATTRIBUTES redirAttrs = *ObjectAttributes;
        redirAttrs.RootDirectory = nullptr;
        redirAttrs.ObjectName    = &redirName;

        return Original(
            FileHandle, DesiredAccess, &redirAttrs,
            IoStatusBlock, AllocationSize, FileAttributes,
            ShareAccess, CreateDisposition, CreateOptions,
            EaBuffer, EaLength);
    }

    NTSTATUS status = Original(
        FileHandle, DesiredAccess, ObjectAttributes,
        IoStatusBlock, AllocationSize, FileAttributes,
        ShareAccess, CreateDisposition, CreateOptions,
        EaBuffer, EaLength);

    if (NT_SUCCESS(status) && FileHandle && *FileHandle)
    {
        const FolderCustom* dirCustom = DetectTargetDirectory(ObjectAttributes);
        if (dirCustom)
        {
            OnTargetDirectoryOpened(*FileHandle, dirCustom);
        }
        else
        {
            TryTrackParentDirectory(ObjectAttributes, *FileHandle);
        }
    }

    return status;
}

NTSTATUS NTAPI HookNtCreateFile(
    PHANDLE FileHandle,
    ACCESS_MASK DesiredAccess,
    POBJECT_ATTRIBUTES ObjectAttributes,
    PIO_STATUS_BLOCK IoStatusBlock,
    PLARGE_INTEGER AllocationSize,
    ULONG FileAttributes,
    ULONG ShareAccess,
    ULONG CreateDisposition,
    ULONG CreateOptions,
    PVOID EaBuffer,
    ULONG EaLength)
{
    return HandleFileOpen(
        FileHandle, DesiredAccess, ObjectAttributes,
        IoStatusBlock, AllocationSize, FileAttributes,
        ShareAccess, CreateDisposition, CreateOptions,
        EaBuffer, EaLength,
        OriginalNtCreateFile);
}

NTSTATUS NTAPI HookNtOpenFile(
    PHANDLE FileHandle,
    ACCESS_MASK DesiredAccess,
    POBJECT_ATTRIBUTES ObjectAttributes,
    PIO_STATUS_BLOCK IoStatusBlock,
    ULONG ShareAccess,
    ULONG OpenOptions)
{
    return HandleFileOpen(
        FileHandle, DesiredAccess, ObjectAttributes,
        IoStatusBlock, nullptr, 0,
        ShareAccess, FILE_OPEN, OpenOptions,
        nullptr, 0,
        OriginalNtOpenFile);
}

NTSTATUS NTAPI HookNtClose(HANDLE Handle)
{
    OnHandleClosed(Handle);
    return OriginalNtClose(Handle);
}

bool Initialize()
{
    HMODULE hNt = GetModuleHandleW(L"ntdll.dll");
    if (!hNt) return false;

    OriginalNtCreateFile = (PFN_NtCreateFile)
        GetProcAddress(hNt, "NtCreateFile");
    OriginalNtOpenFile = (PFN_NtCreateFile)
        GetProcAddress(hNt, "NtOpenFile");
    OriginalNtClose = (PFN_NtClose)
        GetProcAddress(hNt, "NtClose");

    if (!OriginalNtCreateFile || !OriginalNtOpenFile || !OriginalNtClose)
        return false;

    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    DetourAttach(&(PVOID&)OriginalNtCreateFile, HookNtCreateFile);
    DetourAttach(&(PVOID&)OriginalNtOpenFile, HookNtOpenFile);
    DetourAttach(&(PVOID&)OriginalNtClose, HookNtClose);
    LONG err = DetourTransactionCommit();

    return err == NO_ERROR;
}

void Cleanup()
{
    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    if (OriginalNtCreateFile)
        DetourDetach(&(PVOID&)OriginalNtCreateFile, HookNtCreateFile);
    if (OriginalNtOpenFile)
        DetourDetach(&(PVOID&)OriginalNtOpenFile, HookNtOpenFile);
    if (OriginalNtClose)
        DetourDetach(&(PVOID&)OriginalNtClose, HookNtClose);
    DetourTransactionCommit();
}

} // namespace HookFile
