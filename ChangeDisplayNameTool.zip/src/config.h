#pragma once

struct FolderCustom
{
    const wchar_t* targetPath;    // e.g. L"Z:\\Doc" or L"\\\\ShareFolder\\Doc"
    const wchar_t* displayName;   // e.g. L"文档"
    const wchar_t* redirectKey;   // subdirectory under ProgramData\DesktopCustom, e.g. L"Doc"
};

static const FolderCustom g_customFolders[] = {
    { L"Z:\\Doc", L"文档", L"Doc" },
    // Add more entries here as needed, e.g.:
    // { L"\\\\ShareFolder\\Doc", L"文档", L"Doc" },
};

inline constexpr size_t GetCustomFolderCount()
{
    return sizeof(g_customFolders) / sizeof(g_customFolders[0]);
}
