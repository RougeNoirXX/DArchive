#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <Windows.h>
#include <winternl.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cwctype>
#include <cwchar>
