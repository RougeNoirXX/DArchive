#include "pch.h"
#include "hooks.h"
#include "path_utils.h"
#include "config.h"
#include "detours.h"

namespace HookAttribute
{

PFN_GetFileAttributesW   OriginalGetFileAttributesW   = nullptr;
PFN_GetFileAttributesExW OriginalGetFileAttributesExW = nullptr;

DWORD WINAPI HookGetFileAttributesW(LPCWSTR lpFileName)
{
    DWORD attrs = OriginalGetFileAttributesW(lpFileName);

    if (attrs != INVALID_FILE_ATTRIBUTES && IsTargetFolderPath(lpFileName))
    {
        attrs |= FILE_ATTRIBUTE_READONLY;
    }

    return attrs;
}

BOOL WINAPI HookGetFileAttributesExW(
    LPCWSTR lpFileName,
    GET_FILEEX_INFO_LEVELS fInfoLevelId,
    LPVOID lpFileInformation)
{
    BOOL result = OriginalGetFileAttributesExW(lpFileName, fInfoLevelId, lpFileInformation);

    if (result && IsTargetFolderPath(lpFileName))
    {
        if (fInfoLevelId == GetFileExInfoStandard)
        {
            WIN32_FILE_ATTRIBUTE_DATA* data = (WIN32_FILE_ATTRIBUTE_DATA*)lpFileInformation;
            data->dwFileAttributes |= FILE_ATTRIBUTE_READONLY;
        }
    }

    return result;
}

bool Initialize()
{
    HMODULE hKernel = GetModuleHandleW(L"kernel32.dll");
    if (!hKernel) return false;

    OriginalGetFileAttributesW = (PFN_GetFileAttributesW)
        GetProcAddress(hKernel, "GetFileAttributesW");
    OriginalGetFileAttributesExW = (PFN_GetFileAttributesExW)
        GetProcAddress(hKernel, "GetFileAttributesExW");

    if (!OriginalGetFileAttributesW || !OriginalGetFileAttributesExW)
        return false;

    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    DetourAttach(&(PVOID&)OriginalGetFileAttributesW, HookGetFileAttributesW);
    DetourAttach(&(PVOID&)OriginalGetFileAttributesExW, HookGetFileAttributesExW);
    LONG err = DetourTransactionCommit();

    return err == NO_ERROR;
}

void Cleanup()
{
    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    if (OriginalGetFileAttributesW)
        DetourDetach(&(PVOID&)OriginalGetFileAttributesW, HookGetFileAttributesW);
    if (OriginalGetFileAttributesExW)
        DetourDetach(&(PVOID&)OriginalGetFileAttributesExW, HookGetFileAttributesExW);
    DetourTransactionCommit();
}

} // namespace HookAttribute
