#include "InjectHelper.h"
#include <TlHelp32.h>
#include <iostream>

TargetArch DetectPEArch(const std::wstring& filePath)
{
	HANDLE hFile = CreateFileW(filePath.c_str(), GENERIC_READ, FILE_SHARE_READ,
		nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (hFile == INVALID_HANDLE_VALUE)
		return TargetArch::Unknown;

	HANDLE hMapping = CreateFileMappingW(hFile, nullptr, PAGE_READONLY, 0, 0, nullptr);
	CloseHandle(hFile);
	if (!hMapping)
		return TargetArch::Unknown;

	LPVOID pView = MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, 0);
	CloseHandle(hMapping);
	if (!pView)
		return TargetArch::Unknown;

	auto dosHeader = static_cast<PIMAGE_DOS_HEADER>(pView);
	auto ntHeaders = reinterpret_cast<PIMAGE_NT_HEADERS>(
		static_cast<BYTE*>(pView) + dosHeader->e_lfanew);

	TargetArch arch = TargetArch::Unknown;
	WORD machine = ntHeaders->FileHeader.Machine;
	if (machine == IMAGE_FILE_MACHINE_I386)
		arch = TargetArch::X86;
	else if (machine == IMAGE_FILE_MACHINE_AMD64)
		arch = TargetArch::X64;

	UnmapViewOfFile(pView);
	return arch;
}

bool InjectDLLSameArch(HANDLE hProcess, const std::wstring& dllPath)
{
	size_t dllPathSize = (dllPath.length() + 1) * sizeof(WCHAR);
	LPVOID pRemoteMem = VirtualAllocEx(hProcess, nullptr, dllPathSize,
		MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!pRemoteMem)
		return false;

	if (!WriteProcessMemory(hProcess, pRemoteMem, dllPath.c_str(), dllPathSize, nullptr))
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	auto pLoadLibrary = reinterpret_cast<LPTHREAD_START_ROUTINE>(
		GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW"));
	if (!pLoadLibrary)
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	HANDLE hThread = CreateRemoteThread(hProcess, nullptr, 0, pLoadLibrary, pRemoteMem, 0, nullptr);
	if (!hThread)
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	WaitForSingleObject(hThread, INFINITE);
	DWORD exitCode;
	GetExitCodeThread(hThread, &exitCode);
	CloseHandle(hThread);
	VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
	return exitCode != 0;
}

static DWORD SafeReadDword(HANDLE hProcess, ULONG_PTR addr, bool* ok)
{
	DWORD val = 0;
	SIZE_T bytesRead;
	if (ReadProcessMemory(hProcess, reinterpret_cast<LPCVOID>(addr), &val, sizeof(val), &bytesRead)
		&& bytesRead == sizeof(val))
	{
		if (ok) *ok = true;
		return val;
	}
	if (ok) *ok = false;
	return 0;
}

static WORD SafeReadWord(HANDLE hProcess, ULONG_PTR addr, bool* ok)
{
	WORD val = 0;
	SIZE_T bytesRead;
	if (ReadProcessMemory(hProcess, reinterpret_cast<LPCVOID>(addr), &val, sizeof(val), &bytesRead)
		&& bytesRead == sizeof(val))
	{
		if (ok) *ok = true;
		return val;
	}
	if (ok) *ok = false;
	return 0;
}

static bool SafeRead(HANDLE hProcess, ULONG_PTR addr, LPVOID buffer, SIZE_T size)
{
	SIZE_T bytesRead;
	return ReadProcessMemory(hProcess, reinterpret_cast<LPCVOID>(addr), buffer, size, &bytesRead)
		&& bytesRead == size;
}

HMODULE FindRemoteModule(HANDLE hProcess, const wchar_t* moduleName, bool isTarget64)
{
	DWORD pid = GetProcessId(hProcess);

	for (int pass = 0; pass < 2; pass++)
	{
		DWORD flags = TH32CS_SNAPMODULE;
		if (!isTarget64 && pass == 1)
			flags = TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32;

		HANDLE hSnapshot = CreateToolhelp32Snapshot(flags, pid);
		if (hSnapshot == INVALID_HANDLE_VALUE)
			continue;

		MODULEENTRY32W me = { sizeof(me) };
		if (Module32FirstW(hSnapshot, &me))
		{
			do
			{
				if (_wcsicmp(me.szModule, moduleName) == 0)
				{
					HMODULE result = me.hModule;
					CloseHandle(hSnapshot);
					return result;
				}
			} while (Module32NextW(hSnapshot, &me));
		}
		CloseHandle(hSnapshot);
	}

	return nullptr;
}

FARPROC FindRemoteProcAddress(HANDLE hProcess, HMODULE hRemoteModule,
	const char* funcName, bool isModule64)
{
	IMAGE_DOS_HEADER dosHdr;
	if (!SafeRead(hProcess, reinterpret_cast<ULONG_PTR>(hRemoteModule), &dosHdr, sizeof(dosHdr)))
		return nullptr;
	if (dosHdr.e_magic != IMAGE_DOS_SIGNATURE)
		return nullptr;

	ULONG_PTR ntOffset = reinterpret_cast<ULONG_PTR>(hRemoteModule) + dosHdr.e_lfanew;

	DWORD peSig;
	if (!SafeRead(hProcess, ntOffset, &peSig, sizeof(peSig)))
		return nullptr;
	if (peSig != IMAGE_NT_SIGNATURE)
		return nullptr;

	ULONG_PTR optHdrOffset = ntOffset + 4 + sizeof(IMAGE_FILE_HEADER);

	bool ok;
	WORD magic = SafeReadWord(hProcess, optHdrOffset, &ok);
	if (!ok) return nullptr;

	ULONG_PTR dataDirOffset;
	if (magic == IMAGE_NT_OPTIONAL_HDR32_MAGIC)
		dataDirOffset = optHdrOffset + 96;
	else if (magic == IMAGE_NT_OPTIONAL_HDR64_MAGIC)
		dataDirOffset = optHdrOffset + 112;
	else
		return nullptr;

	IMAGE_DATA_DIRECTORY exportDir;
	if (!SafeRead(hProcess, dataDirOffset, &exportDir, sizeof(exportDir)))
		return nullptr;
	if (exportDir.VirtualAddress == 0)
		return nullptr;

	ULONG_PTR exportBase = reinterpret_cast<ULONG_PTR>(hRemoteModule) + exportDir.VirtualAddress;

	IMAGE_EXPORT_DIRECTORY exportHdr;
	if (!SafeRead(hProcess, exportBase, &exportHdr, sizeof(exportHdr)))
		return nullptr;

	ULONG_PTR funcsRVA = reinterpret_cast<ULONG_PTR>(hRemoteModule) + exportHdr.AddressOfFunctions;
	ULONG_PTR namesRVA = reinterpret_cast<ULONG_PTR>(hRemoteModule) + exportHdr.AddressOfNames;
	ULONG_PTR ordsRVA  = reinterpret_cast<ULONG_PTR>(hRemoteModule) + exportHdr.AddressOfNameOrdinals;

	for (DWORD i = 0; i < exportHdr.NumberOfNames; i++)
	{
		DWORD nameRVA = SafeReadDword(hProcess, namesRVA + i * sizeof(DWORD), &ok);
		if (!ok) continue;

		WORD ordinal = SafeReadWord(hProcess, ordsRVA + i * sizeof(WORD), &ok);
		if (!ok) continue;

		ULONG_PTR nameAddr = reinterpret_cast<ULONG_PTR>(hRemoteModule) + nameRVA;
		char nameBuf[128] = {};
		SIZE_T bytesRead = 0;

		if (!ReadProcessMemory(hProcess, reinterpret_cast<LPCVOID>(nameAddr),
			nameBuf, sizeof(nameBuf) - 1, &bytesRead) || bytesRead == 0)
			continue;

		nameBuf[bytesRead < sizeof(nameBuf) - 1 ? bytesRead : sizeof(nameBuf) - 1] = '\0';

		if (strcmp(nameBuf, funcName) == 0)
		{
			DWORD funcRVA = SafeReadDword(hProcess, funcsRVA + ordinal * sizeof(DWORD), &ok);
			if (!ok) return nullptr;
			return reinterpret_cast<FARPROC>(reinterpret_cast<ULONG_PTR>(hRemoteModule) + funcRVA);
		}
	}

	return nullptr;
}

bool InjectDLL(HANDLE hProcess, const std::wstring& dllPath, TargetArch targetArch)
{
#if defined(_M_AMD64) || defined(_M_ARM64)
	bool launcherIs64 = true;
#else
	bool launcherIs64 = false;
#endif

	bool targetIs64 = (targetArch == TargetArch::X64);

	if (launcherIs64 == targetIs64)
		return InjectDLLSameArch(hProcess, dllPath);

	HMODULE hRemoteKernel32 = FindRemoteModule(hProcess, L"kernel32.dll", targetIs64);
	if (!hRemoteKernel32)
	{
		std::wcerr << L"  [Inject] kernel32 not found in suspended process (err="
			<< GetLastError() << L")\n";
		return false;
	}

	FARPROC pRemoteLoadLibraryW = FindRemoteProcAddress(
		hProcess, hRemoteKernel32, "LoadLibraryW", targetIs64);
	if (!pRemoteLoadLibraryW)
	{
		std::wcerr << L"  [Inject] LoadLibraryW not found, err=" << GetLastError() << std::endl;
		return false;
	}

	size_t dllPathSize = (dllPath.length() + 1) * sizeof(WCHAR);
	LPVOID pRemoteMem = VirtualAllocEx(hProcess, nullptr, dllPathSize,
		MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!pRemoteMem)
		return false;

	if (!WriteProcessMemory(hProcess, pRemoteMem, dllPath.c_str(), dllPathSize, nullptr))
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	HANDLE hThread = CreateRemoteThread(hProcess, nullptr, 0,
		reinterpret_cast<LPTHREAD_START_ROUTINE>(pRemoteLoadLibraryW),
		pRemoteMem, 0, nullptr);
	if (!hThread)
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	WaitForSingleObject(hThread, INFINITE);
	DWORD exitCode;
	GetExitCodeThread(hThread, &exitCode);
	CloseHandle(hThread);
	VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
	return exitCode != 0;
}

bool InjectDLLWakeAndInject(HANDLE hProcess, HANDLE hThread,
	const std::wstring& dllPath, TargetArch targetArch)
{
	bool targetIs64 = (targetArch == TargetArch::X64);

	ResumeThread(hThread);

	HMODULE hRemoteKernel32 = nullptr;
	for (int retry = 0; retry < 500; retry++)
	{
		Sleep(10);
		hRemoteKernel32 = FindRemoteModule(hProcess, L"kernel32.dll", targetIs64);
		if (hRemoteKernel32)
		{
			Sleep(200);
			break;
		}
	}

	if (!hRemoteKernel32)
	{
		std::wcerr << L"  [WakeInject] Timed out waiting for kernel32.dll to load\n";
		return false;
	}

	FARPROC pRemoteLoadLibraryW = FindRemoteProcAddress(
		hProcess, hRemoteKernel32, "LoadLibraryW", targetIs64);
	if (!pRemoteLoadLibraryW)
	{
		std::wcerr << L"  [WakeInject] LoadLibraryW not found, err=" << GetLastError() << std::endl;
		return false;
	}

	size_t dllPathSize = (dllPath.length() + 1) * sizeof(WCHAR);
	LPVOID pRemoteMem = VirtualAllocEx(hProcess, nullptr, dllPathSize,
		MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!pRemoteMem)
		return false;

	if (!WriteProcessMemory(hProcess, pRemoteMem, dllPath.c_str(), dllPathSize, nullptr))
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	HANDLE hRemoteThread = CreateRemoteThread(hProcess, nullptr, 0,
		reinterpret_cast<LPTHREAD_START_ROUTINE>(pRemoteLoadLibraryW),
		pRemoteMem, 0, nullptr);
	if (!hRemoteThread)
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	WaitForSingleObject(hRemoteThread, INFINITE);
	DWORD exitCode;
	GetExitCodeThread(hRemoteThread, &exitCode);
	CloseHandle(hRemoteThread);
	VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
	return exitCode != 0;
}
