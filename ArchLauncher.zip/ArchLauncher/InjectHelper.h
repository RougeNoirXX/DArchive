#pragma once
#include <windows.h>
#include <string>

enum class TargetArch { X86, X64, Unknown };

TargetArch DetectPEArch(const std::wstring& filePath);
bool InjectDLLSameArch(HANDLE hProcess, const std::wstring& dllPath);
HMODULE FindRemoteModule(HANDLE hProcess, const wchar_t* moduleName, bool isTarget64);
FARPROC FindRemoteProcAddress(HANDLE hProcess, HMODULE hRemoteModule,
	const char* funcName, bool isModule64);
bool InjectDLL(HANDLE hProcess, const std::wstring& dllPath, TargetArch targetArch);
bool InjectDLLWakeAndInject(HANDLE hProcess, HANDLE hThread,
	const std::wstring& dllPath, TargetArch targetArch);
