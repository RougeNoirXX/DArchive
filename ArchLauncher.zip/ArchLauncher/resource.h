#pragma once

#define IDR_HOOK_DLL_86 101
#define IDR_HOOK_DLL_64 102
