#include <windows.h>
#include <iostream>
#include <string>
#include "resource.h"
#include "InjectHelper.h"

static std::wstring GetExeDir()
{
	WCHAR path[MAX_PATH];
	GetModuleFileNameW(nullptr, path, MAX_PATH);
	std::wstring fullPath(path);
	size_t pos = fullPath.find_last_of(L"\\/");
	return fullPath.substr(0, pos + 1);
}

static TargetArch GetTargetArch(LPCWSTR installerPath)
{
	return DetectPEArch(installerPath);
}

static std::wstring ExtractDLLFromResource(int resId)
{
	HRSRC hRes = FindResourceW(nullptr, MAKEINTRESOURCEW(resId), RT_RCDATA);
	if (!hRes) return L"";

	HGLOBAL hData = LoadResource(nullptr, hRes);
	if (!hData) return L"";

	LPVOID pData = LockResource(hData);
	DWORD size = SizeofResource(nullptr, hRes);

	wchar_t tempPath[MAX_PATH];
	if (!GetTempPathW(MAX_PATH, tempPath)) return L"";

	wchar_t tempFile[MAX_PATH];
	if (!GetTempFileNameW(tempPath, L"AHK", 0, tempFile)) return L"";

	std::wstring dllPath = std::wstring(tempFile) + L".dll";
	DeleteFileW(tempFile);

	HANDLE hFile = CreateFileW(dllPath.c_str(), GENERIC_WRITE, 0, nullptr,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (hFile == INVALID_HANDLE_VALUE) return L"";

	DWORD written;
	WriteFile(hFile, pData, size, &written, nullptr);
	CloseHandle(hFile);

	return dllPath;
}

static std::wstring FindDLLFile(TargetArch arch)
{
	std::wstring dllName = (arch == TargetArch::X64) ? L"ArchHook64.dll" : L"ArchHook86.dll";
	std::wstring path = GetExeDir() + dllName;

	if (GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES)
		return path;

	std::wstring extDir;
	wchar_t selfPath[MAX_PATH];
	GetModuleFileNameW(nullptr, selfPath, MAX_PATH);
	std::wstring self(selfPath);

	size_t pos = self.find_last_of(L"\\/");
	if (pos != std::wstring::npos)
	{
		extDir = self.substr(0, pos + 1);
		path = extDir + dllName;
		if (GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES)
			return path;
	}

	return L"";
}

static std::wstring GetDLLPath(TargetArch arch, bool* fromResource)
{
	int resId = (arch == TargetArch::X64) ? IDR_HOOK_DLL_64 : IDR_HOOK_DLL_86;

	std::wstring dllPath = ExtractDLLFromResource(resId);
	if (!dllPath.empty())
	{
		if (fromResource) *fromResource = true;
		return dllPath;
	}

	dllPath = FindDLLFile(arch);
	if (!dllPath.empty())
	{
		if (fromResource) *fromResource = false;
		return dllPath;
	}

	return L"";
}

int wmain(int argc, wchar_t* argv[])
{
	if (argc < 2)
	{
		std::wcout << L"ArchLauncher - Spoof x64 architecture for ARM64 Windows installers\n\n";
		std::wcout << L"Usage: ArchLauncher.exe <installer_path> [args...]\n\n";
#if defined(_M_ARM64)
		std::wcout << L"  [ARM64 build - supports x86 and x64 installers]\n";
#elif defined(_M_AMD64)
		std::wcout << L"  [x64 build - supports x64 (native) + x86 (needs ArchHook86.dll in same dir)]\n";
#else
		std::wcout << L"  [x86 build - supports x86 (native) + x64 (needs ArchHook64.dll in same dir)]\n";
#endif
		return 1;
	}

	std::wstring installerPath = argv[1];

	std::wstring cmdLine;
	for (int i = 1; i < argc; i++)
	{
		if (i > 1) cmdLine += L" ";
		cmdLine += L"\"" + std::wstring(argv[i]) + L"\"";
	}

	TargetArch targetArch = GetTargetArch(installerPath.c_str());
	if (targetArch == TargetArch::Unknown)
	{
		std::wcerr << L"Error: Cannot detect architecture of " << installerPath << L"\n";
		return 1;
	}

	std::wcout << L"Launching: " << installerPath << std::endl;
	std::wcout << L"Target Architecture: " << (targetArch == TargetArch::X64 ? L"x64" : L"x86") << std::endl;

	bool fromResource = false;
	std::wstring dllPath = GetDLLPath(targetArch, &fromResource);
	if (dllPath.empty())
	{
		std::wcerr << L"Error: Cannot find "
			<< (targetArch == TargetArch::X64 ? L"ArchHook64.dll" : L"ArchHook86.dll")
			<< L". Place it next to ArchLauncher.exe or rebuild with embedded resources.\n";
		return 1;
	}

	std::wcout << L"DLL source: " << (fromResource ? L"embedded resource" : L"external file") << std::endl;

	STARTUPINFOW si = { sizeof(si) };
	PROCESS_INFORMATION pi = {};

	if (!CreateProcessW(nullptr, &cmdLine[0], nullptr, nullptr, FALSE,
		CREATE_SUSPENDED, nullptr, nullptr, &si, &pi))
	{
		std::wcerr << L"Error: Failed to create process (code " << GetLastError() << L").\n";
		if (fromResource) DeleteFileW(dllPath.c_str());
		return 1;
	}

	std::wcout << L"Injecting DLL..." << std::endl;

#if defined(_M_AMD64) || defined(_M_ARM64)
	bool launcherIs64 = true;
#else
	bool launcherIs64 = false;
#endif
	bool targetIs64 = (targetArch == TargetArch::X64);

	bool injected;
	if (launcherIs64 == targetIs64)
	{
		injected = InjectDLL(pi.hProcess, dllPath, targetArch);
		if (injected)
			ResumeThread(pi.hThread);
	}
	else
	{
		std::wcout << L"  Cross-arch: waking process to load modules..." << std::endl;
		injected = InjectDLLWakeAndInject(pi.hProcess, pi.hThread, dllPath, targetArch);
	}

	if (!injected)
	{
		std::wcerr << L"Error: DLL injection failed (code " << GetLastError() << L").\n";
		TerminateProcess(pi.hProcess, 1);
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
		if (fromResource) DeleteFileW(dllPath.c_str());
		return 1;
	}

	WaitForSingleObject(pi.hProcess, INFINITE);

	DWORD exitCode;
	GetExitCodeProcess(pi.hProcess, &exitCode);

	CloseHandle(pi.hThread);
	CloseHandle(pi.hProcess);

	if (fromResource)
		DeleteFileW(dllPath.c_str());

	std::wcout << L"Process exited with code: " << exitCode << std::endl;
	return static_cast<int>(exitCode);
}
