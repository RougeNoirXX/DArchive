#include "IAT.h"

LPVOID IAT::Hook(LPCSTR lpModuleName, LPCSTR lpFunctionName, LPVOID lpFunction)
{
	HMODULE hModule = GetModuleHandleA(nullptr);
	if (!hModule)
		return nullptr;

	const auto lpImageDOSHeader = reinterpret_cast<PIMAGE_DOS_HEADER>(hModule);
	if (lpImageDOSHeader->e_magic != IMAGE_DOS_SIGNATURE)
		return nullptr;

	const auto lpImageNtHeader = reinterpret_cast<PIMAGE_NT_HEADERS>(
		reinterpret_cast<DWORD_PTR>(lpImageDOSHeader) + lpImageDOSHeader->e_lfanew);
	if (lpImageNtHeader->Signature != IMAGE_NT_SIGNATURE)
		return nullptr;

	const IMAGE_DATA_DIRECTORY importDataDirectory =
		lpImageNtHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
	if (importDataDirectory.VirtualAddress == 0)
		return nullptr;

	auto lpImageImportDescriptor = reinterpret_cast<PIMAGE_IMPORT_DESCRIPTOR>(
		reinterpret_cast<DWORD_PTR>(hModule) + importDataDirectory.VirtualAddress);

	while (lpImageImportDescriptor->Characteristics)
	{
		LPCSTR szModuleName = reinterpret_cast<LPCSTR>(
			reinterpret_cast<DWORD_PTR>(hModule) + lpImageImportDescriptor->Name);

		if (lpModuleName == nullptr || _stricmp(szModuleName, lpModuleName) == 0)
		{
			auto lpImageThunkDataOrig = reinterpret_cast<PIMAGE_THUNK_DATA>(
				reinterpret_cast<DWORD_PTR>(hModule) + lpImageImportDescriptor->OriginalFirstThunk);
			auto lpImageThunkData = reinterpret_cast<PIMAGE_THUNK_DATA>(
				reinterpret_cast<DWORD_PTR>(hModule) + lpImageImportDescriptor->FirstThunk);

			if (!lpImageImportDescriptor->OriginalFirstThunk)
				lpImageThunkDataOrig = lpImageThunkData;

			while (lpImageThunkDataOrig->u1.AddressOfData)
			{
				if (!(lpImageThunkDataOrig->u1.Ordinal & IMAGE_ORDINAL_FLAG))
				{
					const auto lpImageImportByName = reinterpret_cast<PIMAGE_IMPORT_BY_NAME>(
						reinterpret_cast<DWORD_PTR>(hModule) + lpImageThunkDataOrig->u1.AddressOfData);

					if (strcmp(lpImageImportByName->Name, lpFunctionName) == 0)
					{
						MEMORY_BASIC_INFORMATION mbi{};
						VirtualQuery(lpImageThunkData, &mbi, sizeof(mbi));

						DWORD dwJunk;
						if (!VirtualProtect(mbi.BaseAddress, mbi.RegionSize, PAGE_READWRITE, &mbi.Protect))
							return nullptr;

						const auto lpOrgFunction = reinterpret_cast<LPVOID>(
							static_cast<DWORD_PTR>(lpImageThunkData->u1.Function));
						lpImageThunkData->u1.Function = reinterpret_cast<DWORD_PTR>(lpFunction);

						VirtualProtect(mbi.BaseAddress, mbi.RegionSize, mbi.Protect, &dwJunk);
						return lpOrgFunction;
					}
				}
				lpImageThunkDataOrig++;
				lpImageThunkData++;
			}
		}
		lpImageImportDescriptor++;
	}

	return nullptr;
}

LPVOID IAT::Hook(LPCSTR lpFunctionName, LPVOID lpFunction)
{
	return Hook(nullptr, lpFunctionName, lpFunction);
}
