#pragma once

#include <windows.h>

class IAT
{
public:
	static LPVOID Hook(LPCSTR lpModuleName, LPCSTR lpFunctionName, LPVOID lpFunction);
	static LPVOID Hook(LPCSTR lpFunctionName, LPVOID lpFunction);
};
