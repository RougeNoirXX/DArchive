#include <windows.h>
#include <shellapi.h>
#include <string>
#include "IAT.h"

#pragma comment(lib, "shell32.lib")

typedef BOOL(WINAPI* IsWow64Process2_t)(HANDLE, USHORT*, USHORT*);
typedef DWORD(WINAPI* GetEnvironmentVariableW_t)(LPCWSTR, LPWSTR, DWORD);
typedef FARPROC(WINAPI* GetProcAddress_t)(HMODULE, LPCSTR);
typedef BOOL(WINAPI* CreateProcessW_t)(LPCWSTR, LPWSTR, LPSECURITY_ATTRIBUTES, LPSECURITY_ATTRIBUTES,
	BOOL, DWORD, LPVOID, LPCWSTR, LPSTARTUPINFOW, LPPROCESS_INFORMATION);
typedef BOOL(WINAPI* CreateProcessA_t)(LPCSTR, LPSTR, LPSECURITY_ATTRIBUTES, LPSECURITY_ATTRIBUTES,
	BOOL, DWORD, LPVOID, LPCSTR, LPSTARTUPINFOA, LPPROCESS_INFORMATION);
typedef BOOL(WINAPI* ShellExecuteExW_t)(LPSHELLEXECUTEINFOW);

static IsWow64Process2_t        Original_IsWow64Process2        = nullptr;
static GetEnvironmentVariableW_t  Original_GetEnvironmentVariableW = nullptr;
static GetProcAddress_t         Original_GetProcAddress         = nullptr;
static CreateProcessW_t         Original_CreateProcessW         = nullptr;
static CreateProcessA_t         Original_CreateProcessA         = nullptr;
static ShellExecuteExW_t        Original_ShellExecuteExW        = nullptr;

static HMODULE g_hSelfModule = nullptr;
static wchar_t g_szSelfPath[MAX_PATH] = {};

static void ResolveOriginal_IsWow64Process2()
{
	if (Original_IsWow64Process2) return;
	HMODULE h = GetModuleHandleA("kernel32.dll");
	if (h) Original_IsWow64Process2 = reinterpret_cast<IsWow64Process2_t>(
		GetProcAddress(h, "IsWow64Process2"));
}

static void ResolveOriginal_GetEnvironmentVariableW()
{
	if (Original_GetEnvironmentVariableW) return;
	HMODULE h = GetModuleHandleA("kernel32.dll");
	if (h) Original_GetEnvironmentVariableW = reinterpret_cast<GetEnvironmentVariableW_t>(
		GetProcAddress(h, "GetEnvironmentVariableW"));
}

static void ResolveOriginal_GetProcAddress()
{
	if (Original_GetProcAddress) return;
	HMODULE h = GetModuleHandleA("kernel32.dll");
	if (h) Original_GetProcAddress = reinterpret_cast<GetProcAddress_t>(
		GetProcAddress(h, "GetProcAddress"));
}

static void ResolveOriginal_CreateProcessW()
{
	if (Original_CreateProcessW) return;
	HMODULE h = GetModuleHandleA("kernel32.dll");
	if (h) Original_CreateProcessW = reinterpret_cast<CreateProcessW_t>(
		GetProcAddress(h, "CreateProcessW"));
}

static void ResolveOriginal_CreateProcessA()
{
	if (Original_CreateProcessA) return;
	HMODULE h = GetModuleHandleA("kernel32.dll");
	if (h) Original_CreateProcessA = reinterpret_cast<CreateProcessA_t>(
		GetProcAddress(h, "CreateProcessA"));
}

static void ResolveOriginal_ShellExecuteExW()
{
	if (Original_ShellExecuteExW) return;
	HMODULE h = GetModuleHandleA("shell32.dll");
	if (h) Original_ShellExecuteExW = reinterpret_cast<ShellExecuteExW_t>(
		GetProcAddress(h, "ShellExecuteExW"));
}

BOOL WINAPI Hook_IsWow64Process2(HANDLE hProcess, USHORT* pProcessMachine, USHORT* pNativeMachine)
{
	ResolveOriginal_IsWow64Process2();
	if (!Original_IsWow64Process2) return FALSE;
	BOOL result = Original_IsWow64Process2(hProcess, pProcessMachine, pNativeMachine);
	if (result && pNativeMachine)
		*pNativeMachine = IMAGE_FILE_MACHINE_AMD64;
	return result;
}

DWORD WINAPI Hook_GetEnvironmentVariableW(LPCWSTR lpName, LPWSTR lpBuffer, DWORD nSize)
{
	if (lpName)
	{
		if (_wcsicmp(lpName, L"PROCESSOR_ARCHITECTURE") == 0)
		{
			const wchar_t* amd64 = L"AMD64";
			DWORD len = static_cast<DWORD>(wcslen(amd64));
			if (lpBuffer && nSize > len) { wcscpy_s(lpBuffer, nSize, amd64); return len; }
			return len + 1;
		}
		if (_wcsicmp(lpName, L"PROCESSOR_IDENTIFIER") == 0)
		{
			const wchar_t* id = L"Intel64 Family 6 Model 165 Stepping 3, GenuineIntel";
			DWORD len = static_cast<DWORD>(wcslen(id));
			if (lpBuffer && nSize > len) { wcscpy_s(lpBuffer, nSize, id); return len; }
			return len + 1;
		}
		if (_wcsicmp(lpName, L"PROCESSOR_ARCHITEW6432") == 0)
		{
			SetLastError(ERROR_ENVVAR_NOT_FOUND);
			return 0;
		}
	}
	ResolveOriginal_GetEnvironmentVariableW();
	if (!Original_GetEnvironmentVariableW) { SetLastError(ERROR_ENVVAR_NOT_FOUND); return 0; }
	return Original_GetEnvironmentVariableW(lpName, lpBuffer, nSize);
}

FARPROC WINAPI Hook_GetProcAddress(HMODULE hModule, LPCSTR lpProcName)
{
	if (!IS_INTRESOURCE(lpProcName))
	{
		if (strcmp(lpProcName, "IsWow64Process2") == 0)
			return reinterpret_cast<FARPROC>(Hook_IsWow64Process2);
		if (strcmp(lpProcName, "GetEnvironmentVariableW") == 0)
			return reinterpret_cast<FARPROC>(Hook_GetEnvironmentVariableW);
	}
	ResolveOriginal_GetProcAddress();
	if (!Original_GetProcAddress) { SetLastError(ERROR_PROC_NOT_FOUND); return nullptr; }
	return Original_GetProcAddress(hModule, lpProcName);
}

static bool ShouldInjectChild(LPCWSTR lpAppName, LPCWSTR lpCommandLine)
{
	std::wstring path;
	if (lpAppName && lpAppName[0])
		path = lpAppName;
	else if (lpCommandLine && lpCommandLine[0])
	{
		path = lpCommandLine;
		size_t pos = path.find(L' ');
		if (pos != std::wstring::npos)
			path = path.substr(0, pos);
		if (path.size() >= 2 && path[0] == L'"')
		{
			size_t end = path.find(L'"', 1);
			if (end != std::wstring::npos)
				path = path.substr(1, end - 1);
		}
	}

	if (path.empty()) return false;

	std::wstring lower = path;
	for (auto& c : lower) c = towlower(c);

	wchar_t temp[MAX_PATH];
	DWORD len = GetTempPathW(MAX_PATH, temp);
	std::wstring tempPath(temp, len);
	for (auto& c : tempPath) c = towlower(c);

	return (lower.find(L".tmp") != std::wstring::npos ||
		(lower.find(tempPath) != std::wstring::npos &&
		 lower.find(L"is-") != std::wstring::npos));
}

static bool InjectSelfIntoChild(HANDLE hProcess)
{
	if (!g_szSelfPath[0]) return false;

	size_t pathSize = (wcslen(g_szSelfPath) + 1) * sizeof(WCHAR);
	LPVOID pRemoteMem = VirtualAllocEx(hProcess, nullptr, pathSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!pRemoteMem) return false;

	if (!WriteProcessMemory(hProcess, pRemoteMem, g_szSelfPath, pathSize, nullptr))
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	auto pLoadLibrary = reinterpret_cast<LPTHREAD_START_ROUTINE>(
		GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW"));
	if (!pLoadLibrary)
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	HANDLE hThread = CreateRemoteThread(hProcess, nullptr, 0, pLoadLibrary, pRemoteMem, 0, nullptr);
	if (!hThread)
	{
		VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
		return false;
	}

	WaitForSingleObject(hThread, INFINITE);
	DWORD exitCode;
	GetExitCodeThread(hThread, &exitCode);
	CloseHandle(hThread);
	VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
	return exitCode != 0;
}

BOOL WINAPI Hook_CreateProcessW(LPCWSTR lpApplicationName, LPWSTR lpCommandLine,
	LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes,
	BOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment,
	LPCWSTR lpCurrentDirectory, LPSTARTUPINFOW lpStartupInfo,
	LPPROCESS_INFORMATION lpProcessInformation)
{
	BOOL shouldInject = ShouldInjectChild(lpApplicationName, lpCommandLine);
	DWORD flags = dwCreationFlags;
	bool wasSuspended = (flags & CREATE_SUSPENDED) != 0;

	if (shouldInject)
		flags |= CREATE_SUSPENDED;

	ResolveOriginal_CreateProcessW();
	if (!Original_CreateProcessW) return FALSE;

	BOOL result = Original_CreateProcessW(lpApplicationName, lpCommandLine,
		lpProcessAttributes, lpThreadAttributes, bInheritHandles,
		flags, lpEnvironment, lpCurrentDirectory, lpStartupInfo, lpProcessInformation);

	if (result && shouldInject)
	{
		InjectSelfIntoChild(lpProcessInformation->hProcess);
		if (!wasSuspended)
			ResumeThread(lpProcessInformation->hThread);
	}

	return result;
}

BOOL WINAPI Hook_CreateProcessA(LPCSTR lpApplicationName, LPSTR lpCommandLine,
	LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes,
	BOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment,
	LPCSTR lpCurrentDirectory, LPSTARTUPINFOA lpStartupInfo,
	LPPROCESS_INFORMATION lpProcessInformation)
{
	DWORD flags = dwCreationFlags;
	bool wasSuspended = (flags & CREATE_SUSPENDED) != 0;
	bool shouldInject = false;

	std::wstring wAppName, wCmdLine;
	if (lpApplicationName && lpApplicationName[0])
	{
		int len = MultiByteToWideChar(CP_ACP, 0, lpApplicationName, -1, nullptr, 0);
		wAppName.resize(len);
		MultiByteToWideChar(CP_ACP, 0, lpApplicationName, -1, &wAppName[0], len);
		shouldInject = ShouldInjectChild(wAppName.c_str(), nullptr);
	}
	else if (lpCommandLine && lpCommandLine[0])
	{
		int len = MultiByteToWideChar(CP_ACP, 0, lpCommandLine, -1, nullptr, 0);
		wCmdLine.resize(len);
		MultiByteToWideChar(CP_ACP, 0, lpCommandLine, -1, &wCmdLine[0], len);
		shouldInject = ShouldInjectChild(nullptr, wCmdLine.c_str());
	}

	if (shouldInject)
		flags |= CREATE_SUSPENDED;

	ResolveOriginal_CreateProcessA();
	if (!Original_CreateProcessA) return FALSE;

	BOOL result = Original_CreateProcessA(lpApplicationName, lpCommandLine,
		lpProcessAttributes, lpThreadAttributes, bInheritHandles,
		flags, lpEnvironment, lpCurrentDirectory, lpStartupInfo, lpProcessInformation);

	if (result && shouldInject)
	{
		InjectSelfIntoChild(lpProcessInformation->hProcess);
		if (!wasSuspended)
			ResumeThread(lpProcessInformation->hThread);
	}

	return result;
}

BOOL WINAPI Hook_ShellExecuteExW(LPSHELLEXECUTEINFOW lpExecInfo)
{
	if (lpExecInfo && lpExecInfo->lpFile)
	{
		if (ShouldInjectChild(lpExecInfo->lpFile, lpExecInfo->lpParameters))
		{
			std::wstring cmdLine = L"\"";
			cmdLine += lpExecInfo->lpFile;
			cmdLine += L"\"";
			if (lpExecInfo->lpParameters && lpExecInfo->lpParameters[0])
			{
				cmdLine += L" ";
				cmdLine += lpExecInfo->lpParameters;
			}

			STARTUPINFOW si = { sizeof(si) };
			if (lpExecInfo->fMask & SEE_MASK_NO_CONSOLE)
				si.dwFlags |= STARTF_USESHOWWINDOW;
			si.wShowWindow = static_cast<WORD>(lpExecInfo->nShow);

			PROCESS_INFORMATION pi = {};
			DWORD flags = CREATE_SUSPENDED;

			BOOL created = CreateProcessW(
				nullptr, &cmdLine[0],
				nullptr, nullptr, FALSE,
				flags, nullptr,
				lpExecInfo->lpDirectory,
				&si, &pi);

			if (created)
			{
				InjectSelfIntoChild(pi.hProcess);
				ResumeThread(pi.hThread);

				if (lpExecInfo->fMask & SEE_MASK_NOCLOSEPROCESS)
					lpExecInfo->hProcess = pi.hProcess;
				else
					CloseHandle(pi.hProcess);

				CloseHandle(pi.hThread);
		lpExecInfo->hInstApp = reinterpret_cast<HINSTANCE>(static_cast<DWORD_PTR>(33));
		return TRUE;
	}

	lpExecInfo->hInstApp = reinterpret_cast<HINSTANCE>(static_cast<DWORD_PTR>(GetLastError()));
			return FALSE;
		}
	}

	ResolveOriginal_ShellExecuteExW();
	if (!Original_ShellExecuteExW) return FALSE;
	return Original_ShellExecuteExW(lpExecInfo);
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	UNREFERENCED_PARAMETER(lpReserved);

	if (ul_reason_for_call == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hModule);
		g_hSelfModule = hModule;
		GetModuleFileNameW(hModule, g_szSelfPath, MAX_PATH);

		Original_IsWow64Process2 = reinterpret_cast<IsWow64Process2_t>(
			IAT::Hook("IsWow64Process2", Hook_IsWow64Process2));

		Original_GetEnvironmentVariableW = reinterpret_cast<GetEnvironmentVariableW_t>(
			IAT::Hook("GetEnvironmentVariableW", Hook_GetEnvironmentVariableW));

		Original_GetProcAddress = reinterpret_cast<GetProcAddress_t>(
			IAT::Hook("GetProcAddress", Hook_GetProcAddress));

		Original_CreateProcessW = reinterpret_cast<CreateProcessW_t>(
			IAT::Hook("CreateProcessW", Hook_CreateProcessW));

		Original_CreateProcessA = reinterpret_cast<CreateProcessA_t>(
			IAT::Hook("CreateProcessA", Hook_CreateProcessA));

		Original_ShellExecuteExW = reinterpret_cast<ShellExecuteExW_t>(
			IAT::Hook("ShellExecuteExW", Hook_ShellExecuteExW));
	}
	else if (ul_reason_for_call == DLL_PROCESS_DETACH)
	{
		if (Original_IsWow64Process2)
			IAT::Hook("IsWow64Process2", reinterpret_cast<LPVOID>(Original_IsWow64Process2));
		if (Original_GetEnvironmentVariableW)
			IAT::Hook("GetEnvironmentVariableW", reinterpret_cast<LPVOID>(Original_GetEnvironmentVariableW));
		if (Original_GetProcAddress)
			IAT::Hook("GetProcAddress", reinterpret_cast<LPVOID>(Original_GetProcAddress));
		if (Original_CreateProcessW)
			IAT::Hook("CreateProcessW", reinterpret_cast<LPVOID>(Original_CreateProcessW));
		if (Original_CreateProcessA)
			IAT::Hook("CreateProcessA", reinterpret_cast<LPVOID>(Original_CreateProcessA));
		if (Original_ShellExecuteExW)
			IAT::Hook("ShellExecuteExW", reinterpret_cast<LPVOID>(Original_ShellExecuteExW));
	}

	return TRUE;
}
