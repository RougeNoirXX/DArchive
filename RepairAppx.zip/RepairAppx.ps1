# RepairAppx.ps1 - by nicolas.dietrich@microsoft.com
# Microsoft Customer Support and Services Modern Apps troubleshooting tool
# This tool is provided AS IS, no support nor warranty of any kind is provided for its usage.
# https://github.com/CSS-Windows/WindowsDiag/tree/master/UEX/RepairAppx

param (
  [string]$package, 
  [string]$action = "repair",
  [switch]$force = $false,
  [switch]$verbose = $false,
  [switch]$no_download = $false,
  [switch]$no_change = $false,
  [switch]$no_deps = $false,
  [switch]$accepteula = $false
)

$VERSION =  "v1.9"
$SLEEP_DELAY =  1000
$CONFIG_COLUMN_PAD = 60
$global:mainPFNs = @()
$global:userRights = $false
$global:canInstallForAllUsers = $false
$global:allUsersSwitch = "-AllUsers"
$global:repairSucceeded = $false


Add-Type -AssemblyName System.ServiceModel
$BindingFlags = [System.Reflection.BindingFlags]::NonPublic -bor [System.Reflection.BindingFlags]::Static
[Windows.Management.Deployment.PackageManager,Windows.Management.Deployment,ContentType=WindowsRuntime] | Out-Null
[Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallManager,Windows.ApplicationModel.Store.Preview.InstallControl,ContentType=WindowsRuntime] | Out-Null

# Credits for using IAsyncOperation from PS go to https://fleexlab.blogspot.com/2018/02/using-winrts-iasyncoperation-in.html
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
Function Await($WinRtTask, $ResultType) {
  try {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
  }
  catch {
    $savedForegroundColor = $host.ui.RawUI.ForegroundColor
    $savedBackgroundColor = $host.ui.RawUI.BackgroundColor
    $host.ui.RawUI.ForegroundColor = "Red"
    $host.ui.RawUI.BackgroundColor = "Black"

    "Async call failed with:"    
    "  Exception Type: $($_.Exception.GetType().FullName)"
    "    Exception Message: $($_.Exception.Message)"

    ""
    $host.ui.RawUI.ForegroundColor = $savedForegroundColor
    $host.ui.RawUI.BackgroundColor = $savedBackgroundColor
  }
}

function ShowUsage()
{
  "USAGE:"
  "------"
  "  .\RepairAppx.ps1 -action <Action> <PACKAGE_NAME>"
  ""
  ""
  "EXAMPLE:"
  "--------"
  "  Repair Microsoft Photo app:"
  "    .\RepairAppx.ps1 *Photo*"
  ""
  "  Look for packages binaries corruption:"
  "    .\RepairAppx.ps1 -action verify *ExperiencePack*"
  ""
  "  Set Calc and its dependencies to modified appmodel state"
  "    .\RepairAppx.ps1 -action setstate *Calc*"
  ""
  "  List packages that depepnd on .NET Native framework 2.2"
  "    .\RepairAppx.ps1 -action depends *NET.Native.Runtime.2.2"
  ""
  "PARAMETERS:"
  "-----------"
  "  -action <Action>"
  "      repair     - [Default] Try to repair app package(s) and their dependencies by downloading them again"
  "      register   - Registers app package(s) and dependencies for the current user but doesn't repair files"
  "      verify     - Verify package(s) consistency by comparing the on-disk files with package declaration"
  ""
  "      setstate   - Sets package(s) and dependencies to modified state, to prepare downloaing them again"
  "      resetstate - Clears the modified state of package(s) and dependencies to get back to normal state"
  ""
  "      config     - Shows config settings related to AppStore, GPO and Windows Update"
  "      depends    - List dependees and dependencies of specified main package(s) or framework(s)"
  ""
  "      queue      - List active items in the download queue"
  "      cancel     - Cancels the Store active download queue"
  "      update     - Scan for all Store updates available (requires admin rights)"
  ""
  "  <PACKAGE_NAME>"
  "      Package(s) name(s) to work on."
  "      This switch can only be omited for a verify action, where it run on all packages for all users."
  "      Note: Wildcards are permitted, but should be used with caution to avoid repairing many packages at one time"
  ""
  "  [optional settings]"
  "    -verbose     - Used in conjonction to -verify, to output verbose about files being verified"
  "    -no_deps     - Do not try to repair frameworks / package dependencies"
  "    -no_change   - Only search for available package updates, do not modify any package"
  "    -no_check    - Do not show configuration settings"
  "    -no_cancel   - Do not cancel the current download queue items"
  "    -no_download - Avoid trying to to download package files from Windows Update"
  "    -no_clear    - Do not reset package status at the end of a repair operation"
  ""
  ""
  "DISCLAIMER:"
  "-----------"
  "  This tool is provided AS IS, no support nor warranty of any kind is provided for its usage."
  ""
}

function CheckConfig()
{
  "Checking Store and Windows Update configuration:"
  "------------------------------------------------"

  $privatestore = $false
  $nostoreaccess = $false

  " Current context:"
  $winVer = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion")
  "   - OS".PadRight($CONFIG_COLUMN_PAD," ") + $winVer.ProductName + " " + $winVer.ReleaseId + " (build " + $winVer.CurrentBuildNumber + ")"
  "   - UserName".PadRight($CONFIG_COLUMN_PAD," ") + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
  "   - ComputerName".PadRight($CONFIG_COLUMN_PAD," ") + $env:ComputerName
  "   - Security".PadRight($CONFIG_COLUMN_PAD," ") + $global:userRights
  
  ""
   
  " AppManager properties:"
  if ($global:canInstallForAllUsers -eq $true) { $val = "Yes" } elseif ($global:canInstallForAllUsers -eq $false) { $val = "No" } else { $val = $global:canInstallForAllUsers }
  if ($global:allUsersSwitch -ne '') { $val += " (will use '$allUsersSwitch')"}
  "   - CanInstallForAllUsers".PadRight($CONFIG_COLUMN_PAD," ") + $val

  try {
    $val = $appInstallManager.AutoUpdateSetting 
    }
  catch {
    $val = "N/A"    
  }
  "   - AutoUpdateSetting".PadRight($CONFIG_COLUMN_PAD," ") + $val
   
  try {
    if (Await ($appInstallManager.IsStoreBlockedByPolicyAsync("Microsoft.WindowsStore", "CN=Microsoft Corporation, O=Microsoft Corporation, L=Redmond, S=Washington, C=US")) ([bool]))
    {
      $nostoreaccess = true
      $val = "blocked"
    }
    else {
      $val = "NOT blocked"
    }
  }
  catch {
    $val = "N/A"    
  }
  "   - IsStoreBlockedByPolicy".PadRight($CONFIG_COLUMN_PAD," ") + $val

  ""
  " Services:"
  $service = Get-Service -Name "AppxSvc"
  "   - $($service.Name) ($($service.DisplayName))".PadRight($CONFIG_COLUMN_PAD," ") + $($service.Status)

  $service = Get-Service -Name "AppReadiness"
  "   - $($service.Name) ($($service.DisplayName))".PadRight($CONFIG_COLUMN_PAD," ") + $($service.Status)

  $service = Get-Service -Name "StorSvc"
  "   - $($service.Name) ($($service.DisplayName))".PadRight($CONFIG_COLUMN_PAD," ") + $($service.Status)

  ""
  " User Profile:"
  $key = "AllowDeploymentInSpecialProfiles"
  $val = (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\Appx -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val)"; $nostoreaccess = true} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set"}
  "$msg"

  $key = "SpecialRoamingOverrideAllowed"
  $val = (Get-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val)"; $nostoreaccess = true} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set"}
  "$msg"

  ""
  " Group Policies:"
  $key = "RemoveWindowsStore"
  $val = (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val) in HKLM"} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set in HKLM"}
  $msg = $msg.PadRight($CONFIG_COLUMN_PAD+19," ")
  $val = (Get-ItemProperty -Path HKCU:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg += "and is set to $($val) in HKCU"} else {$msg += "and is not set in HKCU"}
  "$msg"
  
  $key = "RequirePrivateStoreOnly"
  $val = (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val) in HKLM"} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set in HKLM"}
  $msg = $msg.PadRight($CONFIG_COLUMN_PAD+19," ")
  $val = (Get-ItemProperty -Path HKCU:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg += "and is set to $($val) in HKCU"; $privatestore = $true} else {$msg += "and is not set in HKCU"}
  "$msg"

  $key = "DisableStoreApps"
  $val = (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val) in HKLM"} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set in HKLM"}
  $msg = $msg.PadRight($CONFIG_COLUMN_PAD+19," ")
  $val = (Get-ItemProperty -Path HKCU:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg += "and is set to $($val) in HKCU"} else {$msg += "and is not set in HKCU"}
  "$msg" 
  
  $key = "NoUseStoreOpenWith"
  $val = (Get-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val) in HKLM"} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set in HKLM"}
  $msg = $msg.PadRight($CONFIG_COLUMN_PAD+19," ")
  $val = (Get-ItemProperty -Path HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg += "and is set to $($val) in HKCU"} else {$msg += "and is not set in HKCU"}
  "$msg"
  
  $key = "AutoDownload"
  $val = (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val) in HKLM"} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set in HKLM"}
  $msg = $msg.PadRight($CONFIG_COLUMN_PAD+19," ")
  $val = (Get-ItemProperty -Path HKCU:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg += "and is set to $($val) in HKCU"} else {$msg += "and is not set in HKCU"}
  "$msg"
  
  $key = "SetDisableUXWUAccess"
  $val = (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val) in HKLM"} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set in HKLM"}
  $msg = $msg.PadRight($CONFIG_COLUMN_PAD+19," ")
  $val = (Get-ItemProperty -Path HKCU:\Software\Policies\Microsoft\WindowsStore\ -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg += "and is set to $($val) in HKCU"} else {$msg += "and is not set in HKCU"}
  "$msg"
  
  $key = "DoNotConnectToWindowsUpdateInternetLocations"
  $val = (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is set to $($val) in HKLM"} else {$msg = "   - $key".PadRight($CONFIG_COLUMN_PAD," ") + "is not set in HKLM"}
  $msg = $msg.PadRight($CONFIG_COLUMN_PAD+19," ")
  $val = (Get-ItemProperty -Path HKCU:\Software\Policies\Microsoft\Windows\WindowsUpdate -Name $key -ErrorAction SilentlyContinue).$key
  if ($val) {$msg += "and is set to $($val) in HKCU"; $nostoreaccess = true} else {$msg += "and is not set in HKCU"}
  "$msg"

  ""
  " Windows Update:"
  $MUSM = New-Object -ComObject "Microsoft.Update.ServiceManager"
  $val = ($MUSM.Services | Where-Object IsDefaultAUService | Select-Object Name).Name
  "   - Default Update Service".PadRight($CONFIG_COLUMN_PAD," ") + $val

  $val = ($MUSM.Services | Where-Object ServiceId -Match "855e8a7c-ecb4-4ca3-b045-1dfa50104289").ServiceUrl
  $response = try { (Invoke-WebRequest -UseDefaultCredentials -URI $val -ErrorAction Stop).BaseRequest } catch { $_.Exception.Response }
  "   - WU Test ($val)".PadRight($CONFIG_COLUMN_PAD," ") + "$(if (!@(200, 403) -contains ([int]$response.StatusCode)) {'DOES NOT '; $nostoreaccess = $true})looks reachable"

  ""
  if ($privatestore)  { "WARNING: You use the private store, please ensure you have added the apps there for the repair to work."; "" }
  if ($nostoreaccess) { "WARNING: Your settings block Windows Update from accessing internet, the script will likely not be able to re-download apps and fix file corruptions."; "" }
}

function CleanupUpdateQueue()
{
  $queuedApps = $appInstallManager.AppInstallItems

  "Cancelling any active update:"
  "-----------------------------"
  if (!$queuedApps.length) { "  No installation or update is in the active queue."}
  foreach($queuedApp in $queuedApps)
  {
    # Do not cancel Store app update to avoid leaving it in an unconsistent state
    if ($queuedApp.PackageFamilyName -like '*Microsoft.WindowsStore*') {
      "WARNING: The store app is currently being updated. You may have to run again the script once it will be completed."
    }
    else {
      "  - Cancelling update for $($queuedApp.PackageFamilyName)"
      $queuedApp.Cancel()
    }
  }
  ""
}

function ListUpdateQueue()
{
  $queuedApps = $appInstallManager.AppInstallItems

  "Active update queue:"
  "--------------------"
  if (!$queuedApps.length) { "  No installation or update is in the active queue."}
  foreach($queuedApp in $queuedApps)
  {
    $status = $queuedApp.GetCurrentStatus()
    $currentstate = [Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallState]$status.InstallState
    "  - $($queuedApp.PackageFamilyName) is in state $currentstate"
  }
  ""
}

function SetPackageToModifiedState()
{
  $packages = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch $package"
  $packageManager = New-Object Windows.Management.Deployment.PackageManager

  "Setting following packages to modified state:"
  "---------------------------------------------"

  foreach ($p in $packages)
  {
    "  - $($p.PackageFullName)"
    $global:mainPFNs += $p.PackageFamilyName
    $packageManager.SetPackageStatus($p.PackageFullName, [Windows.Management.Deployment.PackageStatus]::Modified)
    
    if ($no_deps)
    {
      "  - [No dependencies processing was requested]"
    }
    else
    {
      ForEach ($dependencies in (Get-AppxPackageManifest $p.PackageFullName).package.dependencies.packagedependency.name) 
      {
        $dep = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch -PackageTypeFilter Framework $dependencies"
        ForEach ($d in $dep) 
        {
          "  - " + $d.PackageFullName
          $packageManager.SetPackageStatus($d.PackageFullName, [Windows.Management.Deployment.PackageStatus]::Modified)
        }
      }
    }
  }
  ""
}

function ClearPackageFromModifiedState()
{
  $packages = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch -PackageTypeFilter Main $package"
  $packageManager = New-Object Windows.Management.Deployment.PackageManager

  "Resetting state of following packages:"
  "--------------------------------------"

  foreach ($p in $packages)
  {
    "  - $($p.PackageFullName)"
    $packageManager.ClearPackageStatus($p.PackageFullName, [Windows.Management.Deployment.PackageStatus]::Modified)
    
    if ($no_deps)
    {
      "  - [No dependencies processing was requested]"
    }
    else
    {
      ForEach ($dependencies in (Get-AppxPackageManifest $p.PackageFullName).package.dependencies.packagedependency.name) 
      {
        $dep = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch -PackageTypeFilter Framework $dependencies"
        ForEach ($d in $dep) 
        {
          "  - " + $d.PackageFullName
          $packageManager.ClearPackageStatus($d.PackageFullName, [Windows.Management.Deployment.PackageStatus]::Modified)
        }
      }
    }
  }
  ""
}

function RegisterPackageAndDeps()
{
  $packages = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch $package"

  "Force registering following packages:"
  "-------------------------------------"

  foreach ($p in $packages)
  {
    if ($no_deps)
    {
      "  - [No dependencies processing was requested]"
    }
    else
    {
      ForEach ($dependencies in (Get-AppxPackageManifest $p.PackageFullName).package.dependencies.packagedependency.name) 
      {
        $dep = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch -PackageTypeFilter Framework $dependencies"
        ForEach ($d in $dep) 
        {
          "  - " + $d.PackageFullName
          $manifestPath = Join-Path -Path $d.InstallLocation -ChildPath "AppxManifest.xml"
          if (Test-Path($manifestPath))
          {
            # Masking errors especially for frequent "Deployment failed with HRESULT: 0x80073D06, The package could not be installed because a higher version of this package is already installed."
            Add-AppxPackage -DisableDevelopmentMode -ForceApplicationShutdown -register  $manifestPath -ErrorAction SilentlyContinue
          }
          else {
            "    -> Can't find Manifest to register: " + $manifestPath
          }
        }
      }
    }
    $manifestPath = Join-Path -Path $p.InstallLocation -ChildPath "AppxManifest.xml"
    if (Test-Path($manifestPath))
    {
      Add-AppxPackage -DisableDevelopmentMode -ForceApplicationShutdown -register  $manifestPath
    }
    else {
      "    -> Can't find Manifest to register: " + $manifestPath
    }
  }
  ""
}

function SearchForPFNUpdates()
{
  $global:ProgressPreference = 'Continue'
  $finished = $true

  foreach($packageFamilyName in $global:mainPFNs)
  {
    "Looking for available Apps Store updates:"
    "-----------------------------------------"

    try
    {
      $finished = $true
      $appinstalls = Await ($appInstallManager.UpdateAppByPackageFamilyNameAsync($packageFamilyName)) ([Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallItem])
      if ($appinstalls.Length -eq 0) 
      { 
        "Package Manager didn't return any package to download for this family name!"
        ""
        SearchForAllUpdates
      }
      else
      {
        foreach($appinstall in $appinstalls)
        {
          if ($appinstall.PackageFamilyName)
          {
            try { $appstoreaction = "to " + ([Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallType]$appinstall.InstallType) } catch { $appstoreaction = "" }
            "  - Requesting $($appinstall.PackageFamilyName) $appstoreaction"
            Start-Sleep -Milliseconds $SLEEP_DELAY
            $finished = $false
          }
        }
        
        ""
        "Running the update process:"
        "---------------------------"
        while (!$finished)
        {
          $finished = $true        
          for ($index=0; $index -lt $appinstalls.Length; $index++)
          {
            $appUpdate = $appinstalls[$index]
            $packageFamilyName = $appUpdate.PackageFamilyName
            $status = $appUpdate.GetCurrentStatus()
            $currentstate = [Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallState]$status.InstallState

            if (!($status.PercentComplete -eq 100) -and !($status.ErrorCode))
            {
              Write-Progress -Id $index -Activity $packageFamilyName -status ("$currentstate $([Math]::Round($status.BytesDownloaded/1024).ToString('N0'))kb ($($status.PercentComplete)%)") -percentComplete $status.PercentComplete
    
              if ($finished)
              {
                $finished = $false
              }
            }
          }
          Start-Sleep -Milliseconds $SLEEP_DELAY
        }
        for ($index=0; $index -lt $appinstalls.Length; $index++)
        {
          $appUpdate = $appinstalls[$index]
          $packageFamilyName = $appUpdate.PackageFamilyName
          $status = $appUpdate.GetCurrentStatus()
          $currentstate = [Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallState]$status.InstallState
    
          if ($status.PercentComplete -eq 100)
          {
            Write-Progress -Id $index -Activity $packageFamilyName -Status "Completed" -Completed
            "  -> $packageFamilyName ended as $currentstate $(if ($status.ReadyForLaunch) {"and reports now to be READY FOR LAUNCH!"} Else {"and is NOT ready for launch"})"
            $global:repairSucceeded = $true
          }
          elseif ($status.ErrorCode)
          {
            "  -> $packageFamilyName failed with Error $status.ErrorCode / $currentstate"
            Write-Progress -Id $index -Activity $packageFamilyName -Status $msg -Completed
          }
        }
        ""
        "The store apps update process ended for $($appinstalls.Length) packages"
        ""
      }
    }
    catch
    {
        $savedForegroundColor = $host.ui.RawUI.ForegroundColor
        $savedBackgroundColor = $host.ui.RawUI.BackgroundColor
        $host.ui.RawUI.ForegroundColor = "Red"
        $host.ui.RawUI.BackgroundColor = "Black"

        "Exception Type: $($_.Exception.GetType().FullName)"
        "    Exception Message: $($_.Exception.Message)"
 
  #      "Trying to open the Microsoft Store, please check the ongoing downloads and try to update it there."
  #      Invoke-Expression "ms-windows-store://pdp/?PFN=$($global:mainPFN)"

        ""
        "Going to reset package status to get back to a normal state"
        $host.ui.RawUI.ForegroundColor = $savedForegroundColor
        $host.ui.RawUI.BackgroundColor = $savedBackgroundColor
        ""
      }
    }
}
function SearchForAllUpdates()
{
  $global:ProgressPreference = 'Continue'
  $finished = $true

  "Looking for all available Apps Store updates:"
  "---------------------------------------------"

  try
  {
    $appinstalls = Await ($appInstallManager.SearchForAllUpdatesAsync()) ([System.Collections.Generic.IReadOnlyList[Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallItem]])

    if ($appinstalls.Length -eq 0) 
    { 
      "Package Manager didn't return any package to download for the machine!"
    }
    else
    {
      foreach($appinstall in $appinstalls)
      {
        if ($appinstall.PackageFamilyName)
        {
          try { $appstoreaction = "to " + ([Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallType]$appinstall.InstallType) } catch { $appstoreaction = "" }
          "  - Requesting $($appinstall.PackageFamilyName) $appstoreaction"
          Start-Sleep -Milliseconds $SLEEP_DELAY
          $finished = $false
        }
      }

    ""
    "Running the update process:"
    "---------------------------"
    while (!$finished)
    {
      $finished = $true
      for ($index=0; $index -lt $appinstalls.Length; $index++)
      {
        $appUpdate = $appinstalls[$index]
        $packageFamilyName = $appUpdate.PackageFamilyName
        $status = $appUpdate.GetCurrentStatus()
        $currentstate = [Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallState]$status.InstallState

        if (!($status.PercentComplete -eq 100) -and !($status.ErrorCode))
        {
          Write-Progress -Id $index -Activity $packageFamilyName -status ("$currentstate $([Math]::Round($status.BytesDownloaded/1024).ToString('N0'))kb ($($status.PercentComplete)%)") -percentComplete $status.PercentComplete

          if ($finished)
          {
            $finished = $false
          }
        }
      }
      Start-Sleep -Milliseconds $SLEEP_DELAY
    }
    for ($index=0; $index -lt $appinstalls.Length; $index++)
    {
      $appUpdate = $appinstalls[$index]
      $packageFamilyName = $appUpdate.PackageFamilyName
      $status = $appUpdate.GetCurrentStatus()
      $currentstate = [Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallState]$status.InstallState

      if ($status.PercentComplete -eq 100)
      {
        Write-Progress -Id $index -Activity $packageFamilyName -Status "Completed" -Completed
        "  -> $packageFamilyName ended as $currentstate $(if ($status.ReadyForLaunch) {"and reports now to be READY FOR LAUNCH!"} Else {"and is NOT ready for launch"})"
        $global:repairSucceeded = $true
      }
      elseif ($status.ErrorCode)
      {
        "  -> $packageFamilyName failed with Error $status.ErrorCode / $currentstate"
        Write-Progress -Id $index -Activity $packageFamilyName -Status $msg -Completed
      }
    }
    ""
    "The store apps update process ended for $($appinstalls.Length) packages"
    ""
  }
}
catch
{
    $savedForegroundColor = $host.ui.RawUI.ForegroundColor
    $savedBackgroundColor = $host.ui.RawUI.BackgroundColor
    $host.ui.RawUI.ForegroundColor = "Red"
    $host.ui.RawUI.BackgroundColor = "Black"

    "Exception Type: $($_.Exception.GetType().FullName)"
    "    Exception Message: $($_.Exception.Message)"

#      "Trying to open the Microsoft Store, please check the ongoing downloads and try to update it there."
#      Invoke-Expression "ms-windows-store://pdp/?PFN=$($global:mainPFN)"

    ""
    "Going to reset package status to get back to a normal state"
    $host.ui.RawUI.ForegroundColor = $savedForegroundColor
    $host.ui.RawUI.BackgroundColor = $savedBackgroundColor
    ""
  }
}

function ReinstallStore()
{
  try {
    $appinstalls = Await ($appInstallManager.StartAppInstallAsync("9WZDNCRFJBMP", "", $true, $true)) ([Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallItem])
    if ($appinstalls.Length -eq 0) 
    { 
      "Package Manager didn't return any package to download for this reinstall"
      ""
    }
    else
    {
      foreach($appinstall in $appinstalls)
      {
        if ($appinstall.PackageFamilyName)
        {
          try { $appstoreaction = "to " + ([Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallType]$appinstall.InstallType) } catch { $appstoreaction = "" }
          "  - Requesting $($appinstall.PackageFamilyName) $appstoreaction"
          Start-Sleep -Milliseconds $SLEEP_DELAY
          $finished = $false
        }
      }
      
      ""
      "Running the update process:"
      "---------------------------"
      while (!$finished)
      {
        $finished = $true        
        for ($index=0; $index -lt $appinstalls.Length; $index++)
        {
          $appUpdate = $appinstalls[$index]
          $packageFamilyName = $appUpdate.PackageFamilyName
          $status = $appUpdate.GetCurrentStatus()
          $currentstate = [Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallState]$status.InstallState

          if (!($status.PercentComplete -eq 100) -and !($status.ErrorCode))
          {
            Write-Progress -Id $index -Activity $packageFamilyName -status ("$currentstate $([Math]::Round($status.BytesDownloaded/1024).ToString('N0'))kb ($($status.PercentComplete)%)") -percentComplete $status.PercentComplete

            if ($finished)
            {
              $finished = $false
            }
          }
        }
        Start-Sleep -Milliseconds $SLEEP_DELAY
      }
      for ($index=0; $index -lt $appinstalls.Length; $index++)
      {
        $appUpdate = $appinstalls[$index]
        $packageFamilyName = $appUpdate.PackageFamilyName
        $status = $appUpdate.GetCurrentStatus()
        $currentstate = [Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallState]$status.InstallState

        if ($status.PercentComplete -eq 100)
        {
          Write-Progress -Id $index -Activity $packageFamilyName -Status "Completed" -Completed
          "  -> $packageFamilyName ended as $currentstate $(if ($status.ReadyForLaunch) {"and reports now to be READY FOR LAUNCH!"} Else {"and is NOT ready for launch"})"
          $global:repairSucceeded = $true
        }
        elseif ($status.ErrorCode)
        {
          "  -> $packageFamilyName failed with Error $status.ErrorCode / $currentstate"
          Write-Progress -Id $index -Activity $packageFamilyName -Status $msg -Completed
        }
      }
      ""
      "The store apps update process ended for $($appinstalls.Length) packages"
      ""
    }
  }
  catch
  {
      $savedForegroundColor = $host.ui.RawUI.ForegroundColor
      $savedBackgroundColor = $host.ui.RawUI.BackgroundColor
      $host.ui.RawUI.ForegroundColor = "Red"
      $host.ui.RawUI.BackgroundColor = "Black"

      "Exception Type: $($_.Exception.GetType().FullName)"
      "    Exception Message: $($_.Exception.Message)"

  #      "Trying to open the Microsoft Store, please check the ongoing downloads and try to update it there."
  #      Invoke-Expression "ms-windows-store://pdp/?PFN=$($global:mainPFN)"

      ""
      "Going to reset package status to get back to a normal state"
      $host.ui.RawUI.ForegroundColor = $savedForegroundColor
      $host.ui.RawUI.BackgroundColor = $savedBackgroundColor
      ""
    }
}

function VerifyPackagesConsistency()
{
  "Checking packages consistency:"
  "------------------------------"
  if (!$package)
  {
    $package = "*"
  }

  $packages = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch $package" | Where-Object {$_.InstallLocation}
  $invalidPackages = 0
  $packagesIndex = 0

  Foreach ($pack in $packages)
  { 
    $packagesIndex++
    "Checking package $($packagesIndex.ToString("000")) / $($packages.Count.ToString("000")) - $($pack.Name)"
    if ($verbose)
    {
      "  Installed in $($pack.InstallLocation)"
    }

    # Reading the AppxBlockMap file and compare each of the expected file with size on-disk 
    $appxBlockMap = $pack.InstallLocation + "\AppxBlockMap.xml"
    if (!(Test-Path $appxBlockMap))
    {
      "  WARNING - No .appxBlockMap file found inside package $($pack.Name)"
      $expectedPackageSize = -1
    }
    else
    {
      $expectedPackageSize = 0
      $realPackageSize = 0
      $missingFiles = 0

      Foreach ($expectedFile in (Select-Xml "/" -Path $appxBlockMap).node.BlockMap.File)
      {
        $realFilePath = $pack.InstallLocation + "\" + $expectedFile.Name
        $expectedFileSize = $expectedFile.Size -as [int]
        $expectedPackageSize = $expectedPackageSize + $expectedFileSize
        if (!(Test-Path $realFilePath))
        {  
            "  WARNING - File not found : $($expectedFile.Name)"
            $missingFiles++
        }
        else
        {
          $realFileSize = (Get-Item $realFilePath).length
          $realPackageSize += $realFileSize
          if ($realFileSize -ne $expectedFileSize)
          {
            "  WARNING - Unexpected size: $($expectedFile.Name) should be $expectedFileSize bytes but is $realFileSize bytes"
          }
          elseif ($verbose)
          {
            "  - $($expectedFile.Name) is as expected $expectedFileSize bytes"
          }
        }
      }
    }

    if ($expectedPackageSize -ne $realPackageSize)
    {
      "=> PACKAGE INVALID $($pack.Name) expected to sum $expectedPackageSize bytes, but is $realPackageSize bytes $(if ($missingFiles -ne 0) {"with $missingFiles files missing"} else {"with no file missing"})"
      ""
      $invalidPackages++
    }
    elseif ($verbose)
    {
      "-> PACKAGE VALID $($pack.Name) sums as expected $expectedPackageSize bytes"
      ""
    }
  }

  if ($packagesIndex -eq 0)
  {
    "==> NO PACKAGE FOUND TO CHECK <=="
    "Please review your package name and rerun with -verbose"
  }
  elseif ($invalidPackages -eq 0)
  {
    "==> NO ERROR FOUND IN " + $packagesIndex + " PACKAGES CHECKED <=="
  }
  else
  {
    ""
    "!!! $invalidPackages INVALID PACKAGES WERE FOUND IN $packagesIndex PACKAGES CHECKED !!!"
  }
  ""
}

function LookForDependencies()
{
  $dependees = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch $package"

  ForEach ($dependee in $dependees)
  { 
    "Listing dependencies of $($dependee.PackageFullName)"
    ForEach ($d in (Get-AppxPackageManifest $dependee).package.dependencies.packagedependency.name) 
    { 
      "  - $d"
    }
    ""
  }
}

function LookForDependees()
{
  $dependencies = Invoke-Expression "Get-AppXPackage $global:allUsersSwitch $package"

  ForEach ($dependency in $dependencies) 
  { 
    "Listing packages depending on $dependency"
    ForEach ($p in $(Invoke-Expression "Get-AppxPackage $global:allUsersSwitch")) 
    { 
      ForEach ($d in (Get-AppxPackageManifest $p).package.dependencies.packagedependency.name) 
      { 
        if ($d -eq $dependency.Name) 
        {
          "  - $p"
        }
      }
    }
    ""
  }
}

function CheckAdminRights()
{
  $isAdmin = $false

  try {
    $bytes = New-Object -TypeName byte[](4)
    $hToken = ([System.ServiceModel.PeerNode].Assembly.GetType('System.ServiceModel.Channels.AppContainerInfo')).GetMethod('GetCurrentProcessToken', $BindingFlags).Invoke($null, @())
    ([System.ServiceModel.PeerNode].Assembly.GetType('System.ServiceModel.Activation.Utility')).GetMethod('GetTokenInformation', $BindingFlags).Invoke($null, @($hToken, 18, [byte[]]$bytes))
    if ($bytes[0] -eq 1)
    {
        $GetTokenInformation.Invoke($null, @($hToken, 20, [byte[]]$bytes)) # TokenElevation
        if ($bytes[0])   { $global:userRights = "UAC disabled but token elevated (Build-in Admin)"; $isAdmin = $true} 
        else             { $global:userRights = "UAC is disabled and not elevated" }
    }
    if ($bytes[0] -eq 2) { $global:userRights = "UAC enabled and token elevated (Run As Admin)"; $isAdmin = $true }
    if ($bytes[0] -eq 3) { $global:userRights = "UAC enabled and token NOT elevated" }
  }
  catch {
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if ($currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
      $global:userRights = "Administrator"
      $isAdmin = $true
    }
    else {
      $global:userRights = "NOT Administrator"
    }
  }

  try {
    $global:canInstallForAllUsers = $appInstallManager.CanInstallForAllUsers
  }
  catch {
    $global:canInstallForAllUsers = "N/A"    
  }
  finally {
    if (($global:canInstallForAllUsers -ne $true) -and (!$isAdmin)) { $global:allUsersSwitch = ""} 
  }
}

[void][System.Reflection.Assembly]::Load('System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
[void][System.Reflection.Assembly]::Load('System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')

function ShowEULAPopup($mode)
{
    $EULA = New-Object -TypeName System.Windows.Forms.Form
    $richTextBox1 = New-Object System.Windows.Forms.RichTextBox
    $btnAcknowledge = New-Object System.Windows.Forms.Button
    $btnCancel = New-Object System.Windows.Forms.Button

    $EULA.SuspendLayout()
    $EULA.Name = "EULA"
    $EULA.Text = "Microsoft Diagnostic Tools End User License Agreement"

    $richTextBox1.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $richTextBox1.Location = New-Object System.Drawing.Point(12,12)
    $richTextBox1.Name = "richTextBox1"
    $richTextBox1.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Vertical
    $richTextBox1.Size = New-Object System.Drawing.Size(776, 397)
    $richTextBox1.TabIndex = 0
    $richTextBox1.ReadOnly=$True
    $richTextBox1.Add_LinkClicked({Start-Process -FilePath $_.LinkText})
    $richTextBox1.Rtf = @"
{\rtf1\ansi\ansicpg1252\deff0\nouicompat{\fonttbl{\f0\fswiss\fprq2\fcharset0 Segoe UI;}{\f1\fnil\fcharset0 Calibri;}{\f2\fnil\fcharset0 Microsoft Sans Serif;}}
{\colortbl ;\red0\green0\blue255;}
{\*\generator Riched20 10.0.19041}{\*\mmathPr\mdispDef1\mwrapIndent1440 }\viewkind4\uc1 
\pard\widctlpar\f0\fs19\lang1033 MICROSOFT SOFTWARE LICENSE TERMS\par
Microsoft Diagnostic Scripts and Utilities\par
\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}These license terms are an agreement between you and Microsoft Corporation (or one of its affiliates). IF YOU COMPLY WITH THESE LICENSE TERMS, YOU HAVE THE RIGHTS BELOW. BY USING THE SOFTWARE, YOU ACCEPT THESE TERMS.\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}\par
\pard 
{\pntext\f0 1.\tab}{\*\pn\pnlvlbody\pnf0\pnindent0\pnstart1\pndec{\pntxta.}}
\fi-360\li360 INSTALLATION AND USE RIGHTS. Subject to the terms and restrictions set forth in this license, Microsoft Corporation (\ldblquote Microsoft\rdblquote ) grants you (\ldblquote Customer\rdblquote  or \ldblquote you\rdblquote ) a non-exclusive, non-assignable, fully paid-up license to use and reproduce the script or utility provided under this license (the "Software"), solely for Customer\rquote s internal business purposes, to help Microsoft troubleshoot issues with one or more Microsoft products, provided that such license to the Software does not include any rights to other Microsoft technologies (such as products or services). \ldblquote Use\rdblquote  means to copy, install, execute, access, display, run or otherwise interact with the Software. \par
\pard\widctlpar\par
\pard\widctlpar\li360 You may not sublicense the Software or any use of it through distribution, network access, or otherwise. Microsoft reserves all other rights not expressly granted herein, whether by implication, estoppel or otherwise. You may not reverse engineer, decompile or disassemble the Software, or otherwise attempt to derive the source code for the Software, except and to the extent required by third party licensing terms governing use of certain open source components that may be included in the Software, or remove, minimize, block, or modify any notices of Microsoft or its suppliers in the Software. Neither you nor your representatives may use the Software provided hereunder: (i) in a way prohibited by law, regulation, governmental order or decree; (ii) to violate the rights of others; (iii) to try to gain unauthorized access to or disrupt any service, device, data, account or network; (iv) to distribute spam or malware; (v) in a way that could harm Microsoft\rquote s IT systems or impair anyone else\rquote s use of them; (vi) in any application or situation where use of the Software could lead to the death or serious bodily injury of any person, or to physical or environmental damage; or (vii) to assist, encourage or enable anyone to do any of the above.\par
\par
\pard\widctlpar\fi-360\li360 2.\tab DATA. Customer owns all rights to data that it may elect to share with Microsoft through using the Software. You can learn more about data collection and use in the help documentation and the privacy statement at {{\field{\*\fldinst{HYPERLINK https://aka.ms/privacy }}{\fldrslt{https://aka.ms/privacy\ul0\cf0}}}}\f0\fs19 . Your use of the Software operates as your consent to these practices.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 3.\tab FEEDBACK. If you give feedback about the Software to Microsoft, you grant to Microsoft, without charge, the right to use, share and commercialize your feedback in any way and for any purpose.\~ You will not provide any feedback that is subject to a license that would require Microsoft to license its software or documentation to third parties due to Microsoft including your feedback in such software or documentation. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 4.\tab EXPORT RESTRICTIONS. Customer must comply with all domestic and international export laws and regulations that apply to the Software, which include restrictions on destinations, end users, and end use. For further information on export restrictions, visit {{\field{\*\fldinst{HYPERLINK https://aka.ms/exporting }}{\fldrslt{https://aka.ms/exporting\ul0\cf0}}}}\f0\fs19 .\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 5.\tab REPRESENTATIONS AND WARRANTIES. Customer will comply with all applicable laws under this agreement, including in the delivery and use of all data. Customer or a designee agreeing to these terms on behalf of an entity represents and warrants that it (i) has the full power and authority to enter into and perform its obligations under this agreement, (ii) has full power and authority to bind its affiliates or organization to the terms of this agreement, and (iii) will secure the permission of the other party prior to providing any source code in a manner that would subject the other party\rquote s intellectual property to any other license terms or require the other party to distribute source code to any of its technologies.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 6.\tab DISCLAIMER OF WARRANTY. THE SOFTWARE IS PROVIDED \ldblquote AS IS,\rdblquote  WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\par
\pard\widctlpar\qj\par
\pard\widctlpar\fi-360\li360\qj 7.\tab LIMITATION ON AND EXCLUSION OF DAMAGES. IF YOU HAVE ANY BASIS FOR RECOVERING DAMAGES DESPITE THE PRECEDING DISCLAIMER OF WARRANTY, YOU CAN RECOVER FROM MICROSOFT AND ITS SUPPLIERS ONLY DIRECT DAMAGES UP TO U.S. $5.00. YOU CANNOT RECOVER ANY OTHER DAMAGES, INCLUDING CONSEQUENTIAL, LOST PROFITS, SPECIAL, INDIRECT, OR INCIDENTAL DAMAGES. This limitation applies to (i) anything related to the Software, services, content (including code) on third party Internet sites, or third party applications; and (ii) claims for breach of contract, warranty, guarantee, or condition; strict liability, negligence, or other tort; or any other claim; in each case to the extent permitted by applicable law. It also applies even if Microsoft knew or should have known about the possibility of the damages. The above limitation or exclusion may not apply to you because your state, province, or country may not allow the exclusion or limitation of incidental, consequential, or other damages.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 8.\tab BINDING ARBITRATION AND CLASS ACTION WAIVER. This section applies if you live in (or, if a business, your principal place of business is in) the United States.  If you and Microsoft have a dispute, you and Microsoft agree to try for 60 days to resolve it informally. If you and Microsoft can\rquote t, you and Microsoft agree to binding individual arbitration before the American Arbitration Association under the Federal Arbitration Act (\ldblquote FAA\rdblquote ), and not to sue in court in front of a judge or jury. Instead, a neutral arbitrator will decide. Class action lawsuits, class-wide arbitrations, private attorney-general actions, and any other proceeding where someone acts in a representative capacity are not allowed; nor is combining individual proceedings without the consent of all parties. The complete Arbitration Agreement contains more terms and is at {{\field{\*\fldinst{HYPERLINK https://aka.ms/arb-agreement-4 }}{\fldrslt{https://aka.ms/arb-agreement-4\ul0\cf0}}}}\f0\fs19 . You and Microsoft agree to these terms. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 9.\tab LAW AND VENUE. If U.S. federal jurisdiction exists, you and Microsoft consent to exclusive jurisdiction and venue in the federal court in King County, Washington for all disputes heard in court (excluding arbitration). If not, you and Microsoft consent to exclusive jurisdiction and venue in the Superior Court of King County, Washington for all disputes heard in court (excluding arbitration).\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 10.\tab ENTIRE AGREEMENT. This agreement, and any other terms Microsoft may provide for supplements, updates, or third-party applications, is the entire agreement for the software.\par
\pard\sa200\sl276\slmult1\f1\fs22\lang9\par
\pard\f2\fs17\lang2057\par
}
"@
    $richTextBox1.BackColor = [System.Drawing.Color]::White
    $btnAcknowledge.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnAcknowledge.Location = New-Object System.Drawing.Point(544, 415)
    $btnAcknowledge.Name = "btnAcknowledge";
    $btnAcknowledge.Size = New-Object System.Drawing.Size(119, 23)
    $btnAcknowledge.TabIndex = 1
    $btnAcknowledge.Text = "Accept"
    $btnAcknowledge.UseVisualStyleBackColor = $True
    $btnAcknowledge.Add_Click({$EULA.DialogResult=[System.Windows.Forms.DialogResult]::Yes})

    $btnCancel.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnCancel.Location = New-Object System.Drawing.Point(669, 415)
    $btnCancel.Name = "btnCancel"
    $btnCancel.Size = New-Object System.Drawing.Size(119, 23)
    $btnCancel.TabIndex = 2
    if($mode -ne 0)
    {
	    $btnCancel.Text = "Close"
    }
    else
    {
	    $btnCancel.Text = "Decline"
    }
    $btnCancel.UseVisualStyleBackColor = $True
    $btnCancel.Add_Click({$EULA.DialogResult=[System.Windows.Forms.DialogResult]::No})

    $EULA.AutoScaleDimensions = New-Object System.Drawing.SizeF(6.0, 13.0)
    $EULA.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Font
    $EULA.ClientSize = New-Object System.Drawing.Size(800, 450)
    $EULA.Controls.Add($btnCancel)
    $EULA.Controls.Add($richTextBox1)
    if($mode -ne 0)
    {
	    $EULA.AcceptButton=$btnCancel
    }
    else
    {
        $EULA.Controls.Add($btnAcknowledge)
	    $EULA.AcceptButton=$btnAcknowledge
        $EULA.CancelButton=$btnCancel
    }
    $EULA.ResumeLayout($false)
    $EULA.Size = New-Object System.Drawing.Size(800, 650)

    Return ($EULA.ShowDialog())
}

function ShowEULAIfNeeded($toolName, $mode)
{
	$eulaRegPath = "HKCU:Software\Microsoft\CESDiagnosticTools"
	$eulaAccepted = "No"
	$eulaValue = $toolName + " EULA Accepted"
	if(Test-Path $eulaRegPath)
	{
		$eulaRegKey = Get-Item $eulaRegPath
		$eulaAccepted = $eulaRegKey.GetValue($eulaValue, "No")
	}
	else
	{
		$eulaRegKey = New-Item $eulaRegPath
	}
	if($mode -eq 2) # silent accept
	{
		$eulaAccepted = "Yes"
       		$ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
	}
	else
	{
		if($eulaAccepted -eq "No")
		{
			$eulaAccepted = ShowEULAPopup($mode)
			if($eulaAccepted -eq [System.Windows.Forms.DialogResult]::Yes)
			{
	        		$eulaAccepted = "Yes"
	        		$ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
			}
		}
	}
	return $eulaAccepted
}


""
"RepairAppx $VERSION - Repair & troubleshooting tool for AppX packages"
""
"Command line run: " + $MyInvocation.Line
""

if($accepteula) { ShowEULAIfNeeded "RepairAppX" 2 }
else {
    $accepted = ShowEULAIfNeeded "RepairAppX" 0
    if($accepted -ne "Yes") { exit }
}

$appInstallManager = New-Object Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallManager
CheckAdminRights

switch ( $action )
{
  "config"      { CheckConfig; exit }
  "verify"      { VerifyPackagesConsistency; exit }
  "setstate"    { SetPackageToModifiedState; exit }
  "resetstate"  { ClearPackageFromModifiedState; exit }
  "depends"     { LookForDependencies; LookForDependees; exit }
  "queue"       { ListUpdateQueue; exit }
  "cancel"      { CleanupUpdateQueue; exit }
  "update"      { CheckConfig; SearchForAllUpdates; exit }
  "register"    { RegisterPackageAndDeps; exit }
  "repair"      {
    if (!$package)      { ShowUsage; exit } 
    if (!$no_check)     { CheckConfig                   } else { "No config check was requested." }
    if (!$no_cancel)    { CleanupUpdateQueue            } else { "No active queue cleanup was requested." }
    if (!$no_change)    { SetPackageToModifiedState     } else { "No package state change was requested." }
    if (!$no_download)  { SearchForPFNUpdates           } else { "No package download was requested." }
    if ($force -and !$global:repairSucceeded)
    {
      $savedForegroundColor = $host.ui.RawUI.ForegroundColor
      $savedBackgroundColor = $host.ui.RawUI.BackgroundColor
      $host.ui.RawUI.ForegroundColor = "Red"
#      $host.ui.RawUI.BackgroundColor = "Black"

      "Couldn't automate Windows Update, running its scheduled task as a fallback:"

      New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\InstallService\State" -Name "AutoUpdateLastSuccessTime" -Value "2010-01-01 00:00:00" -PropertyType STRING -Force | Out-Null
      New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\InstallService\State" -Name "HasFrameworkUpdates" -Value 1 -PropertyType DWORD -Force | Out-Null

      schtasks.exe /run /tn "\Microsoft\Windows\InstallService\ScanForUpdates" /I
      ""
      "==> Please now give time for Windows Update to run..."
      ""
      $host.ui.RawUI.ForegroundColor = $savedForegroundColor
      $host.ui.RawUI.BackgroundColor = $savedBackgroundColor
    }
    if (!$no_clear)     { ClearPackageFromModifiedState } else { "No package state reset was requested."    }
    if (!$no_register)  { RegisterPackageAndDeps        } else { "No package registration requested." }
  }
  default { ShowUsage; exit }
}
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDsxgz1IvgtWHd+
# O2vI0JJz1tlSIqgrBJTtBjjyM4LAf6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgzBFX31iK
# M5FHdCOgz2uWsDPD7bwV7Aztodtq6NdNXpAwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQB6EXc20AZumMGAnwJm0oAp+QJffhvubEcyaSuZ1RG2
# Sr6vQSuyVtWQEv//QqDNQp+jp/SDlev0wn47FlL6oF3CVeds7SdW4z1VBllOmf6z
# p5mIz3eu3mY5QwZ4lenERwhgHpiPcV8+PY3b943lctp3+YUZE5rKUjbDqvloVTwt
# 9YAOEPVh/1Cm1WvNbNF8boy1/1qmcJFmODPEZqxX58hVRpOJFx7/0pdxSVU0Y7zm
# r7f5TllX25W8DD2gWSC/i15NLKACq6l+wq99f2fVaxoViCcaAaepBd4PFUDI83Nc
# 84BBKK2ddReQ+sh/yZwn4w9Wun6qoRGcA8QuaCnauxdMoYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIGN9rf+MWh75Aa/ez6CNuou14JdpsTKBbNDBR9QA
# tBA7AgZg06FmLwgYEzIwMjEwNzAxMjAxMjU1LjgyM1owBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjpDNEJELUUzN0YtNUZGQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABV0QHYtxv6L4qAAAA
# AAFXMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIxM1oXDTIyMDQxMTE5MDIxM1owgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpDNEJE
# LUUzN0YtNUZGQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAN5tA6dUZvnnwL9qQtXc
# wPANhB4ez+5CQrePp/Z8TH4NBr5vAfGMo0lV/lidBatKTgHErOuKH11xVAfBehHJ
# vH9T/OhOc83CJs9bzDhrld0Jdy3eJyC0yBdxVeucS+2a2ZBd50wBg/5/2YjQ2ylf
# D0dxKK6tQLxdODTuadQMbda05lPGnWGwZ3niSgIKVRgqqCVlhHzwNtRh1AH+Zxbf
# Se7t8z3oEKAdTAy7SsP8ykht3srjdh0BykPFdpaAgqwWCJJJmGk0gArSvHC8+vXt
# Go3MJhWQRe5JtzdD5kdaKH9uc9gnShsXyDEhGZjx3+b8cuqEO8bHv0WPX9MREfrf
# xvkCAwEAAaOCARswggEXMB0GA1UdDgQWBBRdMXu76DghnU/kPTMKdFkR9oCp2TAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAld3kAgG6XWiZyvdibLRmWr7yb6RSy
# cjVDg8tcCitS01sTVp4T8Ad2QeYfJWfK6DMEk7QRBfKgdN7oE8dXtmQVL+JcxLj0
# pUuy4NB5RchcteD5dRnTfKlRi8vgKUaxDcoFIzNEUz1EHpopeagDb4/uI9Uj5tIu
# wlik/qrv/sHAw7kM4gELLNOgdev9Z/7xo1JIwfe0eoQM3wxcCFLuf8S9OncttaFA
# WHtEER8IvgRAgLJ/WnluFz68+hrDfRyX/qqWSPIE0voE6qFx1z8UvLwKpm65QNyN
# DRMp/VmCpqRZrxB1o0RY7P+n4jSNGvbk2bR70kKt/dogFFRBHVVuUxf+MIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpD
# NEJELUUzN0YtNUZGQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAES34SWJ7DfbSG/gbIQwTrzgZ8PKggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOSIAwEwIhgPMjAyMTA3MDExMzAxNTNaGA8yMDIxMDcwMjEzMDE1M1owdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5IgDAQIBADAKAgEAAgIlegIB/zAHAgEAAgIRWTAK
# AgUA5IlUgQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAAMnJaSoZq52EMdm
# VlBziWSmg8A5qcCCXbQ5BKNTMd5GeqViqGR9eXMjru9R2n8eA/2CMUyfXOId/GP3
# LEzFbtpAcPcCeCmWF1ITfkO+902OjERtheK4wsnWwEJctTDcV0lE+79ddZ1IYdtB
# g/MJ/Dmk47qVJK6oPG+S2z1XPbTuMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFXRAdi3G/ovioAAAAAAVcwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgwXVQYi/o1l9b6AFLODUopK1cDQAzttbX7r8sl+q9l1YwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCAsWo0NQ6vzuuupUsZEMSJ4UsRjtQw2dFxZWkHt
# qRygEzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# V0QHYtxv6L4qAAAAAAFXMCIEIHNsVj5VJSeAh9LU1c1KZrzmkRPTEmS79ojd3ydQ
# EfXtMA0GCSqGSIb3DQEBCwUABIIBANA5tLc+uBuU3bbUnSymIwcC4M+CKrxaDVAm
# Eg/L0wTrCJ7yNMQnM34f77RxXQ4JkohYqmpvccar/OojTHryJvwLwAD0fs9udiU+
# b2mVx2LzSBW3+wMHBYVcG2akMAIYbb3MnHO1QtBl6mN95fdrg7xqLTKILPKbOn6K
# Fn7R+jCNh2xGuY3fqQ+fPWTPZ4wkjnCFjjOQrktX428bau9rEnVT+/ZOB2CVOA/K
# lg6/+nbrXfca3hQcbxIA/nxAq+KAFFnk9BjOPoUg9oBg15lr/Plsm7RA3o2PNdE3
# +PrJhbEVs9x8REJvCImVUQiMiGdJUuVgF5sNzzqbaIPYuLrHsgs=
# SIG # End signature block
