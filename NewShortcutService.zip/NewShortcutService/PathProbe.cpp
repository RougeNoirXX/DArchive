#include "PathProbe.h"

#include "Constants.h"

#include <windows.h>

#include <atomic>
#include <cwctype>
#include <memory>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

// =============================================================================
// PathProbe.cpp
// -----------------------------------------------------------------------------
// 带超时路径探测的实现。
//
// 实现方式（与 PathClassifier 中 ResolveIsRemoteWithTimeout 同模式）：
//   探测动作在独立线程中执行，主调在超时后放弃等待。
//   线程通过 shared_ptr 持有状态块，超时 detach 后仍安全。
//
// 防累积：
//   全局维护在途探测计数。一旦卡死在死 UNC 上的探测线程达到上限，
//   后续探测直接按“存在”返回，不再派发新线程——既限制线程累积，
//   又保证“不确定”时永远采取保守动作。
// =============================================================================

namespace pathprobe
{
	// 探测线程并发配额的 RAII 预留：
	// CAS 占位成功后立即持有；未 Commit 时任何异常路径自动归还配额，
	// 杜绝“+1 已提交、线程构造失败、配额永久泄漏”的半提交状态。
	struct SlotReservation
	{
		std::atomic<int>& counter;
		bool committed{false};

		explicit SlotReservation(std::atomic<int>& c) noexcept : counter(c)
		{
		}

		~SlotReservation()
		{
			if (!committed)
			{
				counter.fetch_sub(1, std::memory_order_acq_rel);
			}
		}

		void Commit() noexcept
		{
			committed = true;
		}
	};

	std::wstring ExpandEnvironmentVariablesDynamic(const std::wstring& path)
	{
		if (path.find(L'%') == std::wstring::npos)
		{
			return path;
		}

		// 两阶段：先查询所需长度，再动态分配展开，避免固定缓冲截断。
		DWORD required = ExpandEnvironmentStringsW(path.c_str(), nullptr, 0);
		if (required == 0)
		{
			return path;
		}
		std::vector<wchar_t> buffer(required);
		if (ExpandEnvironmentStringsW(path.c_str(), buffer.data(), required) == 0)
		{
			return path;
		}
		return std::wstring(buffer.data());
	}

	// 用户级环境变量名集合：这些变量的取值因用户而异。服务以
	// LocalSystem 运行时，其展开结果不是目标用户的真实环境。
	namespace
	{
		constexpr std::wstring_view USER_CONTEXT_VARIABLES[] = {
			L"USERPROFILE",
			L"APPDATA",
			L"LOCALAPPDATA",
			L"TEMP",
			L"TMP",
			L"HOMEDRIVE",
			L"HOMEPATH",
			L"HOMESHARE",
			L"USERNAME",
		};

		bool EqualsIgnoreCase(std::wstring_view a, std::wstring_view b) noexcept
		{
			if (a.size() != b.size())
			{
				return false;
			}
			for (size_t i = 0; i < a.size(); ++i)
			{
				if (static_cast<wchar_t>(std::towlower(a[i])) !=
					static_cast<wchar_t>(std::towlower(b[i])))
				{
					return false;
				}
			}
			return true;
		}
	}

	bool ContainsUserContextVariable(const std::wstring& path)
	{
		size_t pos = 0;
		while ((pos = path.find(L'%', pos)) != std::wstring::npos)
		{
			size_t end = path.find(L'%', pos + 1);
			if (end == std::wstring::npos)
			{
				// 不成对的 %：不属于任何变量引用。
				break;
			}
			if (end > pos + 1)
			{
				std::wstring_view name(path.data() + pos + 1, end - pos - 1);
				for (const auto& var : USER_CONTEXT_VARIABLES)
				{
					if (EqualsIgnoreCase(name, var))
					{
						return true;
					}
				}
			}
			pos = end + 1;
		}
		return false;
	}

	bool PathExistsWithTimeout(const std::wstring& path, unsigned long timeoutMs)
	{
		// 保守语义（数据安全优先）：目标含用户级环境变量时，其在服务
		// （LocalSystem）上下文中的展开值不是目标用户的实际路径，
		// 探测结论必然失真——直接按"存在"处理，绝不因展开错误而
		// 触发删除类决策。
		if (ContainsUserContextVariable(path))
		{
			return true;
		}

		// 全局在途计数：跨调用共享（本服务的探测均为低频动作）。
		static std::atomic<int> s_inFlight{0};

		// 原子限流（CAS 占位）：只有成功增加计数的调用才派发探测线程，
		// 并发调用下也严格不超过上限。
		int current = s_inFlight.load(std::memory_order_acquire);
		for (;;)
		{
			if (current >= constants::TARGET_PROBE_MAX_IN_FLIGHT)
			{
				// 已达并发上限：按“存在”保守返回。
				return true;
			}
			if (s_inFlight.compare_exchange_weak(current, current + 1,
				std::memory_order_acq_rel, std::memory_order_acquire))
			{
				break;
			}
			// 占位失败：current 已被更新为最新值，重试。
		}

		// 占位成功：RAII 预留。以下任何异常（make_shared / 事件创建 / 展开 /
		// std::thread 构造失败）都通过预留析构自动归还配额。
		SlotReservation reservation{s_inFlight};

		// 状态块：事件与结果。detach 的线程通过 shared_ptr 安全持有，
		// doneEvent 由最后一个持有者析构关闭，无句柄泄漏。
		struct Shared
		{
			std::atomic<bool> exists{false};
			HANDLE doneEvent{nullptr};

			~Shared()
			{
				if (doneEvent)
				{
					CloseHandle(doneEvent);
				}
			}
		};
		auto shared = std::make_shared<Shared>();
		shared->doneEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
		if (shared->doneEvent == nullptr)
		{
			// 预留析构自动归还配额。
			return true;
		}

		// 目标路径可能包含环境变量（如 %ProgramFiles%），先展开再探测
		//（两阶段动态缓冲，避免固定缓冲截断导致误判）。
		std::wstring target = ExpandEnvironmentVariablesDynamic(path);

		// 展开后仍残留 '%'（未知 / 无法解析的变量）：无法可靠判定，
		// 按"存在"保守处理，避免把状态不确定的目标误判为"不存在"。
		if (target.find(L'%') != std::wstring::npos)
		{
			return true;
		}

		std::thread worker([shared, target]()
		{
			// 线程无论以何种方式结束（join / detach 后自行退出）都归还并发额度。
			struct SlotGuard
			{
				std::atomic<int>& counter;
				~SlotGuard() { counter.fetch_sub(1, std::memory_order_acq_rel); }
			} guard{s_inFlight};

			// 对死 UNC，GetFileAttributesW 会阻塞至底层超时；
			// 调用方在其超时后放弃等待并按“存在”保守处理。
			DWORD attrs = GetFileAttributesW(target.c_str());
			shared->exists.store(attrs != INVALID_FILE_ATTRIBUTES, std::memory_order_release);
			SetEvent(shared->doneEvent);
		});

		// 线程创建成功：配额转由线程退出时（SlotGuard）归还。
		reservation.Commit();

		DWORD wait = WaitForSingleObject(shared->doneEvent, static_cast<DWORD>(timeoutMs));
		if (wait == WAIT_OBJECT_0)
		{
			bool exists = shared->exists.load(std::memory_order_acquire);
			worker.join();
			return exists;
		}

		// 超时：探测线程可能卡在死 UNC 上。
		// 先尝试取消其挂起的同步 IO（降低永久僵尸概率），随后 detach
		// 让其自行结束；按“存在”保守返回——宁可不删，不可误删。
		{
			HANDLE th = OpenThread(THREAD_TERMINATE, FALSE,
				GetThreadId(worker.native_handle()));
			if (th)
			{
				CancelSynchronousIo(th);
				CloseHandle(th);
			}
		}
		worker.detach();
		return true;
	}
}
