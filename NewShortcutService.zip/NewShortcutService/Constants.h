#pragma once

#include <windows.h>
#include <string_view>

// =============================================================================
// Constants.h
// -----------------------------------------------------------------------------
// 集中存放整个服务用到的所有硬编码常量。
// 目的：避免魔法值散落在各个源文件中，后期若需调整路径 / 服务名 / 时间参数，
//       只需修改此处一个文件即可。
// =============================================================================

namespace constants
{
	// -------------------------------------------------------------------------
	// 路径相关常量
	// -------------------------------------------------------------------------

	// 公共桌面目录：所有用户可见的桌面，普通快捷方式最终会被集中搬运到这里。
	inline constexpr std::wstring_view PUBLIC_DESKTOP = L"C:\\Users\\Public\\Desktop";

	// HarmonyOS 桌面重定向根目录：该目录下每个子目录的 Desktop 也会被扫描。
	inline constexpr std::wstring_view REDIRECT_ROOT = L"C:\\HarmonyOS";

	// 用户目录根：用于枚举 C:\Users\<用户名>\Desktop。
	inline constexpr std::wstring_view USERS_ROOT = L"C:\\Users";

	// 快捷方式文件扩展名（小写，比较时需大小写不敏感）。
	inline constexpr std::wstring_view SHORTCUT_EXTENSION = L".lnk";

	// -------------------------------------------------------------------------
	// 服务标识常量
	// -------------------------------------------------------------------------

	// 服务内部名称（供 SCM 使用，也用于事件日志源名称）。
	inline constexpr std::wstring_view SERVICE_NAME = L"ShortcutService";

	// 服务显示名称（在“服务”管理器中展示）。
	inline constexpr std::wstring_view SERVICE_DISPLAY_NAME = L"ShortcutMoveService";

	// 服务描述文本。
	inline constexpr std::wstring_view SERVICE_DESCRIPTION =
		L"Automatic move User's Desktop shortcut link to Public's Desktop folder";

	// 服务启动类型：随系统自动启动。
	inline constexpr DWORD SERVICE_START_TYPE = SERVICE_AUTO_START;

	// 服务运行账户：本地系统账户（拥有 SE_TCB_PRIVILEGE，可跨会话取用户令牌）。
	inline constexpr std::wstring_view SERVICE_ACCOUNT = L"NT AUTHORITY\\SYSTEM";

	// -------------------------------------------------------------------------
	// 时间 / 行为参数
	// -------------------------------------------------------------------------

	// 文件事件去抖延迟（毫秒）。
	// 快捷方式创建 / 写入过程中操作系统会连续抛出多条通知，
	// 收到通知后等待该时长再统一处理，避免处理“尚在写入中”的 .lnk 文件，
	// 同时把短时间内的多次变更合并为一次处理。
	inline constexpr DWORD DEBOUNCE_DELAY_MS = 500;

	// 目录监控取消的有界确认窗口（毫秒）。
	// CancelIo 只是"请求取消"，被取消的异步读取仍需完成；按微软文档，
	// 在确认完成之前不得关闭 / 复用对应的 OVERLAPPED。正常（本地文件
	// 系统）情况下取消在 CancelIo 内同步完成，此窗口不会被真正占用；
	// provider 未响应时窗口到期即放弃等待（上下文退役，OVERLAPPED 不复用）。
	inline constexpr DWORD WATCH_CANCEL_COMPLETE_TIMEOUT_MS = 1000;

	// 远程 / 重定向桌面的轮询间隔（毫秒）。
	// C:\HarmonyOS 下的桌面是指向自实现 UNC 共享的符号链接，该后端不支持
	// 目录更改通知（ReadDirectoryChangesW 会静默永不触发），只能改用定时轮询。
	inline constexpr DWORD POLL_INTERVAL_MS = 60000;

	// 远程目录可达性探测超时（毫秒）。
	// 共享服务存在低概率宕机的可能，触碰远程路径的操作前先做带超时的探测，
	// 若在该时限内无响应则视为不可达并跳过本轮，避免工作线程被 SMB 超时长时间阻塞。
	inline constexpr DWORD REMOTE_PROBE_TIMEOUT_MS = 3000;

	// 编译期保护：探测超时必须显著小于轮询间隔。
	// 否则单次轮询中对多个远程目录的门禁探测累计耗时可能逼近甚至超过轮询周期，
	// 使轮询逻辑失去意义。若日后有人误改这两个常量导致关系倒置，此处直接编译失败。
	static_assert(REMOTE_PROBE_TIMEOUT_MS < POLL_INTERVAL_MS,
	              "REMOTE_PROBE_TIMEOUT_MS must be smaller than POLL_INTERVAL_MS");

	// 探测线程卡死的黑窗上限（毫秒）。
	// 若探测线程因死 UNC 卡住且取消同步 IO 也无法解救，超过该时长后会被
	// 强制“退役”（detach）并重起新线程，保证远程目录处理不会永久失明。
	inline constexpr DWORD REMOTE_PROBE_MAX_BLACKOUT_MS = 120000;

	// 探测超时后的宽限等待（毫秒）：给被取消 / 即将自然完成的探测一个收尾窗口，
	// 使调用方有机会取回迟到的结果并让在途标记及时归零。
	inline constexpr DWORD REMOTE_PROBE_CANCEL_GRACE_MS = 1000;

	// 退役后允许滞留的“僵尸”探测线程数量上限。
	// 仅当共享后端永不响应且取消同步 IO 无效时才会产生僵尸线程；
	// 达到上限后暂停退役（保持旧状态一致），待僵尸线程自行退出被收割后恢复，
	// 避免网络异常期间无限创建线程。
	inline constexpr int REMOTE_PROBE_MAX_ZOMBIE_THREADS = 4;

	// 目标存在性探测的并发上限。
	// 判断快捷方式目标是否存在时可能撞上死 UNC；卡死的探测线程达到该数量后，
	// 后续探测直接按“存在”处理——既防线程累积，也绝不因不确定而删除文件。
	inline constexpr int TARGET_PROBE_MAX_IN_FLIGHT = 8;

	// 目录分类探测的并发上限（含被 detach 的卡死线程）。
	// 分类探测对每个未知路径仅发生一次（带缓存），卡死线程数量级为未知
	// 路径数；达到上限后不再派发新探测线程，直接按 Unknown 处理，
	// 杜绝“路径数量多 + 后端无响应”场景下的僵尸线程累积。
	inline constexpr int CLASSIFY_PROBE_MAX_IN_FLIGHT = 8;

	// 停机时等待工作线程退出的宽限（毫秒）。
	// CancelSynchronousIo 不保证所有文件系统 provider 即时响应取消；
	// join 前轮询等待该时长，超时仍存活则 detach（进程即将退出，安全），
	// 避免 OnStop 无限挂起。
	inline constexpr DWORD SERVICE_WORKER_JOIN_GRACE_MS = 5000;

	// 桌面集合重枚举间隔（毫秒）。
	// 周期性重新枚举桌面目录，拾取服务运行期间新增的用户桌面 / 重定向目录。
	inline constexpr DWORD REENUM_INTERVAL_MS = 600000;

	// 编译期保护：黑窗上限必须大于单次探测超时，宽限必须小于轮询间隔，
	// 重枚举间隔必须大于轮询间隔。若常量关系被误改倒置，直接编译失败。
	static_assert(REMOTE_PROBE_MAX_BLACKOUT_MS > REMOTE_PROBE_TIMEOUT_MS,
	              "REMOTE_PROBE_MAX_BLACKOUT_MS must be larger than REMOTE_PROBE_TIMEOUT_MS");
	static_assert(REMOTE_PROBE_CANCEL_GRACE_MS < POLL_INTERVAL_MS,
	              "REMOTE_PROBE_CANCEL_GRACE_MS must be smaller than POLL_INTERVAL_MS");
	static_assert(REENUM_INTERVAL_MS > POLL_INTERVAL_MS,
	              "REENUM_INTERVAL_MS must be larger than POLL_INTERVAL_MS");

	// 桌面刷新使用的命令：IE 图标缓存刷新工具。
	// 以目标用户令牌跨会话执行，确保用户看到的桌面立即更新。
	inline constexpr std::wstring_view REFRESH_COMMAND = L"ie4uinit.exe";
	inline constexpr std::wstring_view REFRESH_ARGUMENTS = L"-show";
}
