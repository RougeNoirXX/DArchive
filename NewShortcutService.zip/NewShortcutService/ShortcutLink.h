#pragma once

#include <filesystem>
#include <memory>
#include <string>

// =============================================================================
// ShortcutLink.h
// -----------------------------------------------------------------------------
// 封装对 Windows 快捷方式（.lnk）文件的一次性读取。
//
// 背景 / 重构动机：
//   原实现中 is_special_shortcut() 与 has_empty_target() 各自独立地
//   CoCreateInstance + Load 一次 Shell Link，同一个 .lnk 被加载两遍，
//   既低效又存在两处失败语义不一致的问题。
//   这里合并为“加载一次，返回一个描述结构”，由上层依据结构统一决策。
//
// 前置条件：调用方所在线程必须已成功调用 CoInitializeEx。
// =============================================================================

namespace shortcut
{
	// 一次快捷方式读取的结果描述。
	struct LinkInfo
	{
		// COM 是否成功读取到该快捷方式。
		// false 表示读取失败（CoCreateInstance / Load / QueryInterface 出错）。
		// 上层应采取“安全策略”：读取不确定时既不移动也不删除。
		bool loaded = false;

		// 快捷方式解析出的目标路径（可能为空）。
		std::wstring target;

		// 快捷方式携带的启动参数（可能为空；读取失败时也为空）。
		// 用于搬运前去重：目标与参数都相同的快捷方式视为重复。
		std::wstring arguments;

		// 目标是否为空字符串。空目标通常代表指向已被卸载 / 移除的对象。
		bool empty_target = false;

		// 目标是否无法解析（COM 层读取失败，但链接本身已成功加载）。
		// 为 true 时目标内容不可知，上层应采取“安全策略”：不删除、不搬运。
		bool target_unknown = false;

		// 是否为“特殊”快捷方式：目标包含 CLSID（形如 ::{GUID}）或以 :: 开头，
		// 例如“此电脑”“回收站”等 shell 命名空间对象。这类不应搬运到公共桌面。
		bool special = false;

		// 目标文件 / 目录是否在磁盘上真实存在。
		// 仅当 loaded 为 true、且目标为普通文件系统路径（非空、非特殊）时才有意义。
		// 若为 false，说明快捷方式指向的对象已不存在（例如程序被卸载），属失效快捷方式。
		bool target_exists = false;

		// 是否为失效快捷方式：已成功读取，但目标为空、或目标文件不存在。
		// 上层据此判断是否应当删除。特殊快捷方式（如“此电脑”）不算失效。
		bool is_dangling = false;
	};

	// 读取指定 .lnk 文件，返回其信息。
	// 无论成功失败都返回一个 LinkInfo；失败时 loaded == false。
	// 便捷函数：内部创建一次性的 COM 对象。适用于偶发的单次读取。
	// [[nodiscard]]：返回值即全部意义，忽略几乎必为 Bug。
	[[nodiscard]]
	LinkInfo ReadLink(const std::filesystem::path& shortcut_path);

	// LinkReader：可复用的快捷方式读取器。
	// 背景 / 优化动机：
	//   ReadLink 每次都会 CoCreateInstance + 释放一个 ShellLink COM 对象。
	//   在全量扫描 / 批量清理这类需要连续读取大量 .lnk 的场景下，反复创建
	//   COM 对象是不必要的开销。LinkReader 只创建一次 IShellLink/IPersistFile，
	//   后续通过 Load 复用同一对象读取不同快捷方式。
	//
	// 线程约束：本类持有 COM 对象，必须在完成 CoInitializeEx 的同一线程内使用，
	//           不可跨线程共享。
	class LinkReader
	{
	public:
		LinkReader();
		~LinkReader();

		// 明确禁止拷贝与移动：本类独占持有 COM 对象，语义上不可复制、不可转移。
		// 显式写出（而非依赖 Rule of Five）以表达设计意图，便于后续维护者一眼理解。
		LinkReader(const LinkReader&) = delete;
		LinkReader& operator=(const LinkReader&) = delete;
		LinkReader(LinkReader&&) = delete;
		LinkReader& operator=(LinkReader&&) = delete;

		// 读取指定快捷方式；复用内部 COM 对象。语义与 ReadLink 一致。
		// [[nodiscard]]：读取器的返回值就是其全部意义，忽略几乎必为 Bug。
		[[nodiscard]]
		LinkInfo Read(const std::filesystem::path& shortcut_path);

	private:
		// PImpl：真实的 COM 对象（ComPtr<IShellLinkW> / ComPtr<IPersistFile>）
		// 定义在 .cpp 中，头文件因此无需引入任何 COM 头，同时 .cpp 内保持类型安全。
		struct Impl;
		std::unique_ptr<Impl> impl_;
	};

}
