#include "DesktopEnumerator.h"

#include "Constants.h"
#include "PathProbe.h"
#include "WinHandles.h"

#include <windows.h>

#include <cwctype>
#include <string>
#include <string_view>
#include <vector>

// =============================================================================
// DesktopEnumerator.cpp
// -----------------------------------------------------------------------------
// 三路来源合并收集桌面目录，任何一路出错都不影响其余来源（尽力而为）。
// =============================================================================

namespace fs = std::filesystem;

namespace desktop
{
	namespace
	{
		// ---------------------------------------------------------------------
		// 来源 1：扫描 C:\Users 下的真实用户目录。
		// 排除公共 / 系统 / 默认账户，仅保留存在 Desktop 子目录的普通用户。
		// ---------------------------------------------------------------------
		void CollectFromUsers(std::set<fs::path>& result)
		{
			// error_code 重载：该检查位于 try 块之外且处于周期重枚举路径，
			// 瞬时 IO 错误不应向上抛出（会击穿工作线程）。
			std::error_code ec;
			if (!fs::exists(constants::USERS_ROOT, ec) ||
				!fs::is_directory(constants::USERS_ROOT, ec))
			{
				return;
			}

			try
			{
				for (const auto& entry : fs::directory_iterator(constants::USERS_ROOT))
				{
					if (!entry.is_directory())
					{
						continue;
					}

					std::wstring name = entry.path().filename().wstring();

					// 跳过非用户目录：公共 / 管理员 / 全体用户 / 默认档案。
					// 注：C++17 无 wstring::starts_with，用 rfind(..., 0) 判断前缀。
					if (name == L"Public" ||
						name == L"Administrator" ||
						name == L"All Users" ||
						name.rfind(L"Default", 0) == 0)
					{
						continue;
					}

					fs::path desktop = entry.path() / L"Desktop";
					if (fs::is_directory(desktop))
					{
						result.insert(desktop);
					}
				}
			}
			catch (const fs::filesystem_error&)
			{
				// 枚举失败（权限 / IO）时忽略该来源，继续处理其余来源。
			}
		}

		// ---------------------------------------------------------------------
		// 来源 2：扫描 HarmonyOS 重定向根目录下每个子目录的 Desktop。
		//
		// 重要：C:\HarmonyOS\<用户> 这层是本地目录（枚举不阻塞），但其下的
		//       Desktop 是指向 UNC 共享的符号链接。共享可能宕机，因此这里
		//       绝不能对 Desktop 叶子调用 fs::is_directory（会阻塞至 SMB 超时）。
		//       按约定直接登记 <用户>\Desktop，其存在性 / 可达性交由上层
		//       “可达性门禁 + 轮询”阶段处理。
		// ---------------------------------------------------------------------
		void CollectFromRedirectRoot(std::set<fs::path>& result)
		{
			std::error_code ec;
			if (!fs::exists(constants::REDIRECT_ROOT, ec) ||
				!fs::is_directory(constants::REDIRECT_ROOT, ec))
			{
				return;
			}

			try
			{
				for (const auto& entry : fs::directory_iterator(constants::REDIRECT_ROOT))
				{
					if (!entry.is_directory())
					{
						continue;
					}

					// 不对远程叶子做存在性检查，直接登记。
					fs::path desktop = entry.path() / L"Desktop";
					fs::path cntDesktop = entry.path() / L"桌面"; // 兼容中文目录名
					result.insert(desktop);
					result.insert(cntDesktop);
				}
			}
			catch (const fs::filesystem_error&)
			{
				// 忽略该来源错误。
			}
		}

		// ---------------------------------------------------------------------
		// 来源 3：遍历 HKEY_USERS 下每个已加载用户配置单元，
		// 读取其 User Shell Folders\Desktop 项（可能含环境变量，需展开）。
		// 这样可覆盖桌面被重定向到自定义位置的场景。
		// ---------------------------------------------------------------------

		// 判断 HKEY_USERS 下的键是否为服务账户 / 系统配置单元：
		// .DEFAULT、S-1-5-18（SYSTEM）、S-1-5-19（LocalService）、
		// S-1-5-20（NetworkService）以及结尾为 _Classes 的镜像键。
		// 它们不是"用户桌面"来源，登记其系统配置目录只会造成错误搬运
		// 与无谓监控。
		bool IsServiceAccountHive(const std::wstring& sid)
		{
			if (sid == L".DEFAULT" ||
				sid == L"S-1-5-18" ||
				sid == L"S-1-5-19" ||
				sid == L"S-1-5-20")
			{
				return true;
			}
			constexpr std::wstring_view classesSuffix = L"_Classes";
			return sid.size() > classesSuffix.size() &&
				sid.compare(sid.size() - classesSuffix.size(),
					classesSuffix.size(), classesSuffix) == 0;
		}

		// 读取指定 SID 的配置文件根目录（ProfileList\<SID>\ProfileImagePath）。
		// 返回空串表示无法确定——此时不能安全展开用户级变量，调用方应跳过。
		std::wstring GetUserProfileRoot(const std::wstring& sid)
		{
			const std::wstring subkey =
				L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProfileList\\" + sid;

			winhandles::RegKey hk;
			if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, subkey.c_str(), 0, KEY_READ, &hk) != ERROR_SUCCESS)
			{
				return {};
			}

			// 先查询大小再动态分配读取（与 User Shell Folders 读取同模式）。
			DWORD type = 0;
			DWORD byteCount = 0;
			if (RegQueryValueExW(hk, L"ProfileImagePath", nullptr, &type, nullptr, &byteCount) != ERROR_SUCCESS)
			{
				return {};
			}
			if (type != REG_SZ && type != REG_EXPAND_SZ)
			{
				return {};
			}

			std::vector<wchar_t> value((byteCount / sizeof(wchar_t)) + 1, L'\0');
			DWORD byteCap = static_cast<DWORD>(value.size() * sizeof(wchar_t));
			if (RegQueryValueExW(hk, L"ProfileImagePath", nullptr, &type,
				reinterpret_cast<LPBYTE>(value.data()), &byteCap) != ERROR_SUCCESS)
			{
				return {};
			}

			std::wstring profile(value.data());
			if (profile.find(L'%') != std::wstring::npos)
			{
				profile = pathprobe::ExpandEnvironmentVariablesDynamic(profile);
				if (profile.find(L'%') != std::wstring::npos)
				{
					return {};
				}
			}
			return profile;
		}

		// 以目标用户的配置文件根目录为基准，展开 User Shell Folders 值中的
		// 用户级变量；系统级变量（%SystemDrive% 等）随后仍用
		// ExpandEnvironmentStringsW 展开（其值对所有用户一致）。
		// 返回空串表示存在无法解析的变量，调用方应跳过该条目。
		std::wstring ExpandShellFolderValue(const std::wstring& value, const std::wstring& profileRoot)
		{
			std::wstring result = value;

			// 大小写不敏感地查找子串。
			auto findNoCase = [](const std::wstring& s, std::wstring_view needle, size_t start) -> size_t
			{
				if (start > s.size() || needle.empty())
				{
					return std::wstring::npos;
				}
				for (size_t i = start; i + needle.size() <= s.size(); ++i)
				{
					size_t j = 0;
					for (; j < needle.size(); ++j)
					{
						if (static_cast<wchar_t>(std::towlower(s[i + j])) !=
							static_cast<wchar_t>(std::towlower(needle[j])))
						{
							break;
						}
					}
					if (j == needle.size())
					{
						return i;
					}
				}
				return std::wstring::npos;
			};

			// 替换所有 %NAME%（大小写不敏感）。
			auto replaceAll = [&](std::wstring_view name, const std::wstring& replacement)
			{
				if (replacement.empty())
				{
					// 空替换会导致死循环；保留原样，交由最终 '%' 检查跳过。
					return;
				}
				const std::wstring pattern = L"%" + std::wstring(name) + L"%";
				size_t pos = 0;
				while ((pos = findNoCase(result, pattern, pos)) != std::wstring::npos)
				{
					result.replace(pos, pattern.size(), replacement);
					pos += replacement.size();
				}
			};

			replaceAll(L"USERPROFILE", profileRoot);
			replaceAll(L"APPDATA", profileRoot + L"\\AppData\\Roaming");
			replaceAll(L"LOCALAPPDATA", profileRoot + L"\\AppData\\Local");

			// HOMEDRIVE / HOMEPATH 只能从本地盘符形式的配置目录推导；
			// UNC 配置目录不映射，交由最终 '%' 检查跳过。
			if (profileRoot.size() >= 2 && profileRoot[1] == L':')
			{
				replaceAll(L"HOMEDRIVE", profileRoot.substr(0, 2));
				replaceAll(L"HOMEPATH", profileRoot.substr(2));
			}

			result = pathprobe::ExpandEnvironmentVariablesDynamic(result);

			// 仍残留 '%' 说明存在无法解析的变量（如 %TEMP% / %USERNAME%）：
			// 无法可靠确定路径，返回空串跳过。
			if (result.find(L'%') != std::wstring::npos)
			{
				return {};
			}
			return result;
		}

		void CollectFromRegistry(std::set<fs::path>& result)
		{
			winhandles::RegKey hkUsers;
			if (RegOpenKeyExW(HKEY_USERS, nullptr, 0, KEY_READ, &hkUsers) != ERROR_SUCCESS)
			{
				return;
			}

			wchar_t sid[256];
			DWORD index = 0;
			while (RegEnumKeyW(hkUsers, index++, sid, 256) == ERROR_SUCCESS)
			{
				std::wstring sidStr(sid);

				// 跳过服务账户 / 系统配置单元（.DEFAULT、SYSTEM、
				// LocalService、NetworkService 及 _Classes 镜像键）。
				if (IsServiceAccountHive(sidStr))
				{
					continue;
				}

				std::wstring subkey = sidStr +
					L"\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders";

				winhandles::RegKey hkUser;
				if (RegOpenKeyExW(HKEY_USERS, subkey.c_str(), 0, KEY_READ, &hkUser) != ERROR_SUCCESS)
				{
					continue;
				}

				// User Shell Folders 中的值可能超过 MAX_PATH（长路径系统），
				// 先查询大小再动态分配读取；仅接受 REG_SZ / REG_EXPAND_SZ。
				DWORD type = 0;
				DWORD byteCount = 0;
				if (RegQueryValueExW(hkUser, L"Desktop", nullptr, &type, nullptr, &byteCount) != ERROR_SUCCESS)
				{
					continue;
				}
				if (type != REG_SZ && type != REG_EXPAND_SZ)
				{
					continue;
				}

				std::vector<wchar_t> value((byteCount / sizeof(wchar_t)) + 1, L'\0');
				DWORD byteCap = static_cast<DWORD>(value.size() * sizeof(wchar_t));
				if (RegQueryValueExW(hkUser, L"Desktop", nullptr, &type,
					reinterpret_cast<LPBYTE>(value.data()), &byteCap) != ERROR_SUCCESS)
				{
					continue;
				}

				// 展开路径。关键：用户级变量（%USERPROFILE% 等）在服务
				// （LocalSystem）上下文中的展开结果不是目标用户的环境——
				// 必须以该用户的配置文件根目录（ProfileList）为基准展开，
				// 否则每个用户的桌面都会被错误解析到系统配置目录。
				std::wstring desktopValue(value.data());
				std::wstring expanded;
				if (pathprobe::ContainsUserContextVariable(desktopValue))
				{
					std::wstring profileRoot = GetUserProfileRoot(sidStr);
					if (profileRoot.empty())
					{
						// 无法确定用户环境：宁可漏登，不可登错。
						continue;
					}
					expanded = ExpandShellFolderValue(desktopValue, profileRoot);
					if (expanded.empty())
					{
						continue;
					}
				}
				else
				{
					expanded = pathprobe::ExpandEnvironmentVariablesDynamic(desktopValue);
					if (expanded.find(L'%') != std::wstring::npos)
					{
						// 存在无法解析的变量。
						continue;
					}
				}

				fs::path desktop(expanded);
				// 排除 CLSID 形式的路径（以 "::" 开头）。
				if (desktop.wstring().find(L"::") == 0)
				{
					continue;
				}

				// 用带超时探测替代 fs::is_directory：目录可能位于短暂不可达的
				// 远程卷，直接检查会阻塞启动扫描；超时按“存在”保守处理，
				// 宁可登记（后续由可达性门禁 + 轮询过滤），不可漏登。
				if (!pathprobe::PathExistsWithTimeout(
					desktop.wstring(), constants::REMOTE_PROBE_TIMEOUT_MS))
				{
					continue;
				}
				result.insert(desktop);
			}
		}
	}

	std::set<fs::path> EnumerateDesktops()
	{
		std::set<fs::path> result;

		CollectFromUsers(result);
		CollectFromRedirectRoot(result);
		CollectFromRegistry(result);

		return result;
	}
}
