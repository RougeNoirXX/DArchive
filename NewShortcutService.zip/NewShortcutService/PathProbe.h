#pragma once

#include <string>

// =============================================================================
// PathProbe.h
// -----------------------------------------------------------------------------
// 带超时的路径存在性探测。
//
// 背景：
//   对死 UNC 直接调用 GetFileAttributesW 会阻塞至 SMB 层超时（数十秒甚至更久）。
//   凡是“判断某路径是否存在”的场景（快捷方式目标检查、注册表桌面目录登记）
//   都应走这里的带超时探测，避免工作线程被长时间阻塞。
//
// 关键语义：
//   超时 / 探测能力不可用时一律返回 true（视为存在）。
//   理由：探测失败意味着“状态不确定”，调用方在不确定时必须采取保守动作
//         （保留文件 / 登记目录），绝不因短暂故障做出删除或漏登记类决策。
// =============================================================================

namespace pathprobe
{
	// 展开路径中的环境变量（两阶段、动态缓冲，无固定长度截断）。
	// 无需展开或展开失败时返回原串。用于目标探测与去重键归一化。
	[[nodiscard]]
	std::wstring ExpandEnvironmentVariablesDynamic(const std::wstring& path);

	// 判断字符串中是否含有"用户级"环境变量引用（%VAR% 形式，大小写不敏感）。
	// 这类变量的取值因用户而异，服务进程（LocalSystem）中的展开结果不代表
	// 目标用户的真实环境；涉及"删除 / 登记"类判定时必须保守处理。
	[[nodiscard]]
	bool ContainsUserContextVariable(const std::wstring& path);

	// 判断路径在 timeoutMs 内是否可确认存在。
	// 超时或探测资源达到并发上限时返回 true（保守按存在处理）。
	[[nodiscard]]
	bool PathExistsWithTimeout(const std::wstring& path, unsigned long timeoutMs);
}
