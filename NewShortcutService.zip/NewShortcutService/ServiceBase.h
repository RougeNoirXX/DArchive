#pragma once

#include <windows.h>
#include <string>
#include <mutex>

// =============================================================================
// ServiceBase.h
// -----------------------------------------------------------------------------
// Windows 服务通用基类：封装与 SCM（服务控制管理器）交互的样板逻辑。
//   - 注册 ServiceMain / 控制处理回调；
//   - 维护并上报服务状态（启动 / 运行 / 停止 / 暂停等）；
//   - 提供事件日志写入辅助。
// 具体业务由派生类重写 OnStart / OnStop 等虚函数实现。
// =============================================================================

class CServiceBase
{
public:
	// 将服务注册到 SCM 并进入服务分发循环。阻塞直到服务停止。
	[[nodiscard]]
	static bool Run(CServiceBase& service);

	explicit CServiceBase(std::wstring serviceName,
	                      bool canStop = true,
	                      bool canShutdown = true,
	                      bool canPauseContinue = false);

	virtual ~CServiceBase() noexcept = default;

	CServiceBase(const CServiceBase&) = delete;
	CServiceBase& operator=(const CServiceBase&) = delete;
	CServiceBase(CServiceBase&&) = delete;
	CServiceBase& operator=(CServiceBase&&) = delete;

	// 停止服务（由控制处理回调触发，标记 noexcept 以在回调中安全调用）。
	void Stop() noexcept;

protected:
	// 派生类重写以实现启动逻辑。
	virtual void OnStart(DWORD argc, PWSTR* argv)
	{
	}

	// 派生类重写以实现停止逻辑。
	virtual void OnStop()
	{
	}

	virtual void OnPause()
	{
	}

	virtual void OnContinue()
	{
	}

	virtual void OnShutdown()
	{
	}

	// 向 SCM 上报当前状态。waitHint 为预计操作耗时（毫秒），供 SCM 判断是否卡死。
	void SetServiceStatus(DWORD currentState,
	                      DWORD win32ExitCode = NO_ERROR,
	                      DWORD waitHint = 0);

	// 在已持有 m_statusMutex 的前提下上报状态。
	// 供 Start 在"检查状态 + 上报 RUNNING"需要原子完成时使用，
	// 防止与工作线程的 STOPPED 上报交错导致状态被覆盖。
	void SetServiceStatusLocked(DWORD currentState,
	                            DWORD win32ExitCode = NO_ERROR,
	                            DWORD waitHint = 0);

	// 写入一条事件日志。
	void WriteEventLogEntry(PCWSTR message, WORD type);

	// 写入一条带错误码的错误日志。
	void WriteErrorLogEntry(PCWSTR function, DWORD error);

	void WriteErrorLogEntry(const PCWSTR function)
	{
		WriteErrorLogEntry(function, ::GetLastError());
	}

private:
	static void WINAPI ServiceMain(DWORD argc, LPWSTR* argv);
	static void WINAPI ServiceCtrlHandler(DWORD ctrl);

	void Start(DWORD argc, PWSTR* argv);
	void Pause();
	void Continue();
	void Shutdown();

private:
	// SCM 分发回调是全局的，需要一个静态指针指回当前服务实例。
	static CServiceBase* s_service;

	std::wstring m_name;
	SERVICE_STATUS m_status{};
	SERVICE_STATUS_HANDLE m_statusHandle{nullptr};

	bool m_canStop;
	bool m_canShutdown;
	bool m_canPauseContinue;

	DWORD m_checkpoint = 0;
	std::mutex m_statusMutex;
};
