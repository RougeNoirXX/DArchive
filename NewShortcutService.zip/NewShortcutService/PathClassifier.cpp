#include "PathClassifier.h"

#include "Constants.h"

#include <windows.h>

#include <atomic>
#include <chrono>
#include <memory>
#include <string>
#include <thread>
#include <vector>

// =============================================================================
// PathClassifier.cpp
// -----------------------------------------------------------------------------
// 本地 / 远程目录分类实现。
// =============================================================================

namespace fs = std::filesystem;

namespace pathcls
{
	namespace
	{
		// 分类探测线程的全局在途计数（含超时后 detach、仍卡死在死 UNC 上的线程）。
		// 达到上限后不再派发新探测线程，直接按 Unknown 处理，防僵尸线程累积。
		std::atomic<int> s_classifyProbeInFlight{0};

		// 探测线程并发配额的 RAII 预留：
		// CAS 占位成功后立即持有；未 Commit 时任何异常路径自动归还配额，
		// 杜绝“+1 已提交、线程构造失败、配额永久泄漏”的半提交状态。
		struct SlotReservation
		{
			std::atomic<int>& counter;
			bool committed{false};

			explicit SlotReservation(std::atomic<int>& c) noexcept : counter(c)
			{
			}

			~SlotReservation()
			{
				if (!committed)
				{
					counter.fetch_sub(1, std::memory_order_acq_rel);
				}
			}

			void Commit() noexcept
			{
				committed = true;
			}
		};

		// 转小写，用于大小写不敏感的前缀比较。
		std::wstring ToLower(std::wstring s)
		{
			for (auto& c : s)
			{
				c = static_cast<wchar_t>(::towlower(c));
			}
			return s;
		}

		// 带超时地解析目录“是否为远程”。
		// 由于共享宕机时 CreateFileW / GetFinalPathNameByHandleW / GetDriveTypeW
		// 都可能长时间阻塞，这里把探测放到一个独立线程中执行，主调在超时后放弃等待。
		// 一次性、低频（仅启动分类与周期重枚举时调用），故超时后线程 detach 即可，
		// 不会累积。
		//
		// 返回值：
		//   DirKind::Remote   -> 已确认为远程（UNC 或 DRIVE_REMOTE）
		//   DirKind::Local    -> 已确认为本地
		//   DirKind::Unknown  -> 探测超时 / 失败（上层按轮询保守处理，
		//                        因为真正的远程重定向已由 HarmonyOS 前缀主规则覆盖）
		DirKind ResolveIsRemoteWithTimeout(const fs::path& dir, DWORD timeoutMs)
		{
			// 共享结果与完成事件；用 shared_ptr 让 detach 的线程可安全独立持有。
			// doneEvent 的关闭放在 Shared 析构中，由最后一个持有者（主线程或
			// detach 的探测线程）负责，避免超时 detach 场景下的句柄泄漏或重复关闭。
			struct Shared
			{
				std::atomic<bool> isRemote{false};
				HANDLE doneEvent{nullptr};

				~Shared()
				{
					if (doneEvent)
					{
						CloseHandle(doneEvent);
					}
				}
			};
			auto shared = std::make_shared<Shared>();
			shared->doneEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
			if (shared->doneEvent == nullptr)
			{
				return DirKind::Unknown;
			}

			std::wstring pathStr = dir.wstring();

			// 原子限流（CAS 占位）：在途（含卡死 detach）探测线程达到上限时，
			// 不再派发新线程，直接按 Unknown 处理（上层走轮询，自带门禁）。
			{
				int current = s_classifyProbeInFlight.load(std::memory_order_acquire);
				for (;;)
				{
					if (current >= constants::CLASSIFY_PROBE_MAX_IN_FLIGHT)
					{
						return DirKind::Unknown;
					}
					if (s_classifyProbeInFlight.compare_exchange_weak(current, current + 1,
						std::memory_order_acq_rel, std::memory_order_acquire))
					{
						break;
					}
				}
			}

			// 占位成功：RAII 预留。以下任何异常（如 std::thread 构造失败）
			// 都通过预留析构自动归还配额。
			SlotReservation reservation{s_classifyProbeInFlight};

			std::thread worker([shared, pathStr]()
			{
				// 线程无论以何种方式结束（join / detach 后自行退出）都归还额度。
				struct SlotGuard
				{
					std::atomic<int>& counter;
					~SlotGuard() { counter.fetch_sub(1, std::memory_order_acq_rel); }
				} guard{s_classifyProbeInFlight};

				bool remote = false;

				// 主判断：原始路径本身是 UNC（\\server\share\...，排除 \\?\ 本地前缀）。
				// 即使后续最终路径解析失败（如超长路径被截断），也不应降级为本地。
				if (pathStr.rfind(L"\\\\", 0) == 0 && pathStr.rfind(L"\\\\?\\", 0) != 0)
				{
					remote = true;
				}

				// 打开目录句柄（跟随符号链接到达真实后端）。
				HANDLE h = CreateFileW(
					pathStr.c_str(),
					0,
					FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
					nullptr,
					OPEN_EXISTING,
					FILE_FLAG_BACKUP_SEMANTICS,
					nullptr);

				if (h != INVALID_HANDLE_VALUE)
				{
					// 两阶段动态缓冲获取最终路径：避免长路径（>1024 字符）
					// 被固定缓冲截断而漏判 UNC。
					DWORD required = GetFinalPathNameByHandleW(
						h, nullptr, 0, FILE_NAME_NORMALIZED);
					if (required > 0)
					{
						std::vector<wchar_t> finalBuffer(required);
						DWORD n = GetFinalPathNameByHandleW(
							h, finalBuffer.data(),
							static_cast<DWORD>(finalBuffer.size()), FILE_NAME_NORMALIZED);
						if (n > 0 && n < finalBuffer.size())
						{
							std::wstring fp(finalBuffer.data());
							// 形如 \\?\UNC\server\share\...（UNC）
							// 或裸 UNC \\server\share\...；排除本地 \\?\C:\ 前缀。
							if (fp.rfind(L"\\\\?\\UNC\\", 0) == 0)
							{
								remote = true;
							}
							else if (fp.rfind(L"\\\\", 0) == 0 && fp.rfind(L"\\\\?\\", 0) != 0)
							{
								remote = true;
							}
						}
					}
					CloseHandle(h);
				}

				// 兜底：按盘符判断卷类型是否为远程。
				if (!remote && pathStr.size() >= 2 && pathStr[1] == L':')
				{
					std::wstring root = pathStr.substr(0, 3); // 形如 "X:\"
					if (GetDriveTypeW(root.c_str()) == DRIVE_REMOTE)
					{
						remote = true;
					}
				}

				shared->isRemote.store(remote, std::memory_order_release);
				SetEvent(shared->doneEvent);
			});

			// 线程创建成功：配额转由线程退出时（SlotGuard）归还。
			reservation.Commit();

			DWORD wait = WaitForSingleObject(shared->doneEvent, timeoutMs);
			if (wait == WAIT_OBJECT_0)
			{
				bool result = shared->isRemote.load(std::memory_order_acquire);
				worker.join();
				return result ? DirKind::Remote : DirKind::Local;
			}

			// 超时：探测线程可能卡在死 UNC 上。
			// 先尝试取消其挂起的同步 IO；宽限窗口内若已退出则 join 回收，
			// 否则 detach（在途额度由线程自行退出时归还）。
			{
				HANDLE th = OpenThread(THREAD_TERMINATE, FALSE,
					GetThreadId(worker.native_handle()));
				if (th)
				{
					CancelSynchronousIo(th);
					CloseHandle(th);
				}
			}
			if (WaitForSingleObject(shared->doneEvent, constants::REMOTE_PROBE_CANCEL_GRACE_MS) == WAIT_OBJECT_0)
			{
				worker.join();
			}
			else
			{
				// 仍卡死：detach，shared 由该线程继续持有，
				// doneEvent 在最后一个持有者析构时关闭。
				worker.detach();
			}
			// 按 Unknown 保守处理（上层走轮询，自带可达性门禁）。
			return DirKind::Unknown;
		}
	}

	bool IsUnderRedirectRoot(const fs::path& dir)
	{
		std::wstring root = ToLower(std::wstring(constants::REDIRECT_ROOT));
		std::wstring path = ToLower(dir.wstring());

		// 归一化：去掉 root 末尾可能的分隔符后，判断 path 是否以 "root\" 开头。
		while (!root.empty() && (root.back() == L'\\' || root.back() == L'/'))
		{
			root.pop_back();
		}
		if (path.size() <= root.size())
		{
			return path == root;
		}
		return path.compare(0, root.size(), root) == 0 &&
			(path[root.size()] == L'\\' || path[root.size()] == L'/');
	}

	DirKind Classify(const fs::path& dir, unsigned long probeTimeoutMs)
	{
		// 主规则：HarmonyOS 前缀，确定且不触碰远程。
		if (IsUnderRedirectRoot(dir))
		{
			return DirKind::Remote;
		}

		// 显式 UNC 路径（\\server\share\...，排除 \\?\ 本地前缀）：确定为远程，
		// 零探测、零线程、零网络触碰——避免对死 UNC 的无谓探测与配额消耗。
		{
			std::wstring s = dir.wstring();
			if (s.rfind(L"\\\\", 0) == 0 && s.rfind(L"\\\\?\\", 0) != 0)
			{
				return DirKind::Remote;
			}
		}

		// 兜底规则：带超时地解析是否为 UNC / 远程卷；超时返回 Unknown。
		return ResolveIsRemoteWithTimeout(dir, static_cast<DWORD>(probeTimeoutMs));
	}
}
