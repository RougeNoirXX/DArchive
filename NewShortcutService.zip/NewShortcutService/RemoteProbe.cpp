#include "RemoteProbe.h"

#include "Constants.h"
#include "WinHandles.h"

#include <windows.h>

#include <algorithm>
#include <atomic>
#include <mutex>
#include <string>
#include <thread>
#include <utility>
#include <vector>

// =============================================================================
// RemoteProbe.cpp
// -----------------------------------------------------------------------------
// 可达性探测实现（自愈版）。
//
// 相较旧版的关键改进——修复“远程目录短暂不可达后再也不会被处理”的缺陷：
//   旧实现中探测线程一旦卡在死 UNC 的 GetFileAttributesW 上，在途标记永不
//   归零，后续所有探测被“防累积”短路，远程目录从此不再被处理。
//   新版提供两级恢复：
//     1. 超时后对探测线程调用 CancelSynchronousIo，直接中断挂起的同步 IO，
//        使线程尽快回到空闲状态（恢复耗时 ≈ 探测超时 + 宽限窗口）。
//     2. 若取消失败且探测仍卡死超过 REMOTE_PROBE_MAX_BLACKOUT_MS，
//        退役该线程（事务式切换：先备好新线程，再废弃旧线程）并重起新线程，
//        最坏情况下恢复耗时 ≤ 黑窗阈值 + 一个轮询周期。
//   探测结果带“代数”校验：被退役的旧线程迟到的结果会被丢弃，
//   不会再污染新探测的 doneEvent / reachable 状态。
//
// 实现细节：
//   - 每个“世代”的探测线程持有独立的状态块（事件 + 结果），
//     线程通过 shared_ptr 持有，退役（detach）后仍安全。
//   - 代数记录在状态块内；退役时对旧块递增代数并置位其退出事件，
//     旧线程完成当前探测后发现代数不匹配即丢弃结果，随后因退出事件返回。
//   - 退役流程事务式：先创建新事件块与新线程（失败则旧状态原样保留），
//     成功后才作废旧块并回收旧线程；旧线程可取消则 join（零泄漏），
//     不可取消则 detach 并记入“僵尸”清单。
//   - 僵尸线程上限（REMOTE_PROBE_MAX_ZOMBIE_THREADS）：达到上限后暂停
//     退役（保持旧状态一致），待僵尸线程自行退出（被收割）后再恢复，
//     避免网络异常期间无限创建线程。
// =============================================================================

struct RemoteProbe::Impl
{
	// 单个世代探测线程的状态块。
	struct Shared
	{
		HANDLE requestEvent{nullptr};   // 自动重置：有新探测请求
		HANDLE doneEvent{nullptr};      // 自动重置：本次探测完成
		HANDLE quitEvent{nullptr};      // 手动重置：请求线程退出
		std::wstring targetPath;        // 待探测路径（派发前由调用方写入）
		std::atomic<bool> reachable{false};
		std::atomic<unsigned long long> generation{0}; // 代数：退役时递增以作废结果

		Shared()
		{
			requestEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
			doneEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
			quitEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
		}

		~Shared()
		{
			if (requestEvent)
			{
				CloseHandle(requestEvent);
			}
			if (doneEvent)
			{
				CloseHandle(doneEvent);
			}
			if (quitEvent)
			{
				CloseHandle(quitEvent);
			}
		}

		bool valid() const noexcept
		{
			return requestEvent && doneEvent && quitEvent;
		}
	};

	// 探测线程主循环（静态，仅依赖状态块，与 Impl 生命周期解耦）。
	static void RunWorker(std::shared_ptr<Shared> st);

	// 当前世代的探测线程及其状态块。
	std::shared_ptr<Shared> shared;
	std::thread worker;
	winhandles::ScopedHandle workerHandle; // 由 OpenThread 取得，供 CancelSynchronousIo

	// 是否有探测在途（仅由调用方维护）。
	std::atomic<bool> inFlight{false};

	// 当前探测的派发时刻（tick），用于判断是否超过黑窗阈值。
	unsigned long long probeStartTick{0};

	// 上次派发探测的目标路径（仅调用方线程在锁内读写）。
	// 用于识别“迟到结果属于哪个目录”：结果归位时直接返回，
	// 避免同一轮中死目录的单飞行探测连带饿死其他健康目录。
	std::wstring lastProbePath;

	// 是否处于卡死告警中（每个卡死周期只记录一次诊断，避免每轮轮询刷屏）。
	std::atomic<bool> stuckLogged{false};

	// 无法取消而被迫 detach 的退役线程句柄（僵尸清单）。
	// 每次退役前先收割已退出的僵尸；达到上限后暂停退役。
	std::vector<winhandles::ScopedHandle> zombieThreads;

	bool started{false};

	// 保护派发 / 退役 / 停止等生命周期操作。
	std::mutex lock;

	RemoteProbe::DiagnosticCallback onDiagnostic;

	// 收割已退出的僵尸线程句柄。
	void ReapZombies()
	{
		zombieThreads.erase(
			std::remove_if(zombieThreads.begin(), zombieThreads.end(),
				[](winhandles::ScopedHandle& h)
				{
					DWORD code = 0;
					return !h.valid() ||
						(GetExitCodeThread(h.get(), &code) && code != STILL_ACTIVE);
				}),
			zombieThreads.end());
	}

	// 退役卡死的探测线程并重起新线程（事务式、自管理锁）。
	// 调用方不得持有 lock。成功返回 true；失败时旧状态原样保留。
	// 第一阶段（锁内）创建并一次性提交新世代；第二阶段（锁外）取消 /
	// 回收旧线程——Sleep 与 join 可能长时间阻塞，锁外执行避免拖住
	// Stop() 与诊断回调等锁操作。
	bool Retire()
	{
		// 供锁外使用的诊断回调副本（锁内读取，避免锁外访问被并发修改的回调）。
		DiagnosticCallback diag;

		std::thread oldWorker;
		winhandles::ScopedHandle oldCancelHandle;

		// ---- 第一阶段（锁内）：创建并一次性提交新世代 ----
		{
			// 注意：局部变量不得命名为 lock（会遮蔽成员 lock，导致
			// lock_guard 构造实参绑定到自身而编译失败）。
			std::lock_guard<std::mutex> guard(lock);

			// 锁内拷贝回调；所有诊断调用一律在锁外执行，避免持锁调用
			// 用户回调造成潜在重入 / 阻塞。
			diag = onDiagnostic;

			if (!started)
			{
				// 服务正在停止：无需退役。
				return false;
			}

			ReapZombies();

			// 僵尸上限保护：异常环境下暂停退役，保持旧状态一致；
			// 待僵尸线程自行退出被收割后恢复。
			if (zombieThreads.size() >= static_cast<size_t>(constants::REMOTE_PROBE_MAX_ZOMBIE_THREADS))
			{
				if (diag)
				{
					diag(L"RemoteProbe: zombie probe threads at cap, deferring retire.");
				}
				return false;
			}

			// 先备好新世代（失败则旧状态不受任何影响）。
			auto newShared = std::make_shared<Shared>();
			if (!newShared->valid())
			{
				if (diag)
				{
					diag(L"RemoteProbe: failed to create events for new probe thread.");
				}
				return false;
			}

			std::thread newWorker;
			try
			{
				newWorker = std::thread([st = newShared] { RunWorker(st); });
			}
			catch (const std::system_error&)
			{
				if (diag)
				{
					diag(L"RemoteProbe: failed to create new probe thread.");
				}
				return false;
			}

			// 一次性提交：作废旧块（旧线程迟到的结果将被丢弃）、
			// 通知旧线程退出，并切换 shared / worker / workerHandle 到新世代。
			shared->generation.fetch_add(1, std::memory_order_acq_rel);
			SetEvent(shared->quitEvent);

			oldWorker = std::move(worker);
			oldCancelHandle = std::move(workerHandle);

			shared = std::move(newShared);
			worker = std::move(newWorker);
			DWORD newTid = GetThreadId(worker.native_handle());
			workerHandle.reset(OpenThread(THREAD_TERMINATE, FALSE, newTid));

			inFlight.store(false, std::memory_order_release);
			probeStartTick = 0;
			stuckLogged.store(false, std::memory_order_release);

			if (diag)
			{
				diag(L"RemoteProbe: probe thread stuck too long, retiring and restarting it.");
			}
		}

		// ---- 第二阶段（锁外）：回收旧线程 ----
		if (oldWorker.joinable())
		{
			// 尝试取消卡死的同步 IO，令旧线程尽快退出。
			if (oldCancelHandle.valid())
			{
				CancelSynchronousIo(oldCancelHandle);
			}

			// 宽限窗口后判定旧线程是否已退出。
			Sleep(constants::REMOTE_PROBE_CANCEL_GRACE_MS);

			HANDLE native = oldWorker.native_handle();
			DWORD exitCode = 0;
			if (native && GetExitCodeThread(native, &exitCode) && exitCode != STILL_ACTIVE)
			{
				// 已退出：直接 join 回收，零泄漏。
				oldWorker.join();
			}
			else
			{
				// 仍卡死：detach 并登记僵尸句柄，由后续 ReapZombies 收割。
				DWORD tid = GetThreadId(native);
				winhandles::ScopedHandle zombieHandle(
					OpenThread(THREAD_QUERY_LIMITED_INFORMATION, FALSE, tid));
				oldWorker.detach();
				if (zombieHandle.valid())
				{
					std::lock_guard<std::mutex> guard(lock);
					zombieThreads.push_back(std::move(zombieHandle));
				}
				if (diag)
				{
					diag(L"RemoteProbe: stuck probe thread could not be cancelled; registered as zombie.");
				}
			}
		}

		return true;
	}
};

void RemoteProbe::Impl::RunWorker(std::shared_ptr<RemoteProbe::Impl::Shared> st)
{
	HANDLE waits[2] = {st->quitEvent, st->requestEvent};
	for (;;)
	{
		DWORD r = WaitForMultipleObjects(2, waits, FALSE, INFINITE);
		if (r == WAIT_OBJECT_0)
		{
			// 收到退出信号。
			return;
		}
		if (r != WAIT_OBJECT_0 + 1)
		{
			// 异常返回，退出以免忙等。
			return;
		}

		// 执行探测：对死 UNC，GetFileAttributesW 会阻塞至底层超时
		// （或由调用方的 CancelSynchronousIo 中断）。
		unsigned long long gen = st->generation.load(std::memory_order_acquire);
		DWORD attrs = GetFileAttributesW(st->targetPath.c_str());
		bool ok = (attrs != INVALID_FILE_ATTRIBUTES);

		// 代数校验：若探测期间发生过退役，本线程的块已废弃，结果直接丢弃，
		// 不写 reachable / doneEvent，避免污染新世代的探测。
		if (st->generation.load(std::memory_order_acquire) == gen)
		{
			st->reachable.store(ok, std::memory_order_release);
			SetEvent(st->doneEvent);
		}
	}
}

RemoteProbe::RemoteProbe() : impl_(std::make_unique<Impl>())
{
	impl_->shared = std::make_shared<Impl::Shared>();
	if (impl_->shared->valid())
	{
		auto st = impl_->shared;
		impl_->worker = std::thread([st] { Impl::RunWorker(st); });
		DWORD tid = GetThreadId(impl_->worker.native_handle());
		impl_->workerHandle.reset(OpenThread(THREAD_TERMINATE, FALSE, tid));
		impl_->started = true;
	}
}

RemoteProbe::~RemoteProbe()
{
	Stop();
}

void RemoteProbe::SetDiagnosticCallback(DiagnosticCallback callback)
{
	if (!impl_)
	{
		return;
	}
	std::lock_guard<std::mutex> lock(impl_->lock);
	impl_->onDiagnostic = std::move(callback);
}

void RemoteProbe::Stop() noexcept
{
	if (!impl_)
	{
		return;
	}

	std::lock_guard<std::mutex> lock(impl_->lock);
	if (!impl_->started)
	{
		return;
	}
	impl_->started = false;

	// 通知当前探测线程退出。
	if (impl_->shared)
	{
		SetEvent(impl_->shared->quitEvent);
	}

	// 若探测正卡在死 UNC 上，尝试取消以加速其退出。
	if (impl_->workerHandle.valid())
	{
		CancelSynchronousIo(impl_->workerHandle);
	}

	if (impl_->worker.joinable())
	{
		if (!impl_->inFlight.load(std::memory_order_acquire))
		{
			// 线程空闲或即将空闲：等待其退出。
			impl_->worker.join();
		}
		else
		{
			// 探测在途且可能卡死：detach，让进程退出时由系统回收。
			impl_->worker.detach();
		}
	}
}

bool RemoteProbe::IsReachable(const std::filesystem::path& dir, unsigned long timeoutMs)
{
	if (!impl_)
	{
		return false;
	}

	// 本次探测使用的状态块与取消句柄：派发时在锁内一并捕获，
	// 之后的等待 / 取消 / 结果读取仅使用局部副本，
	// 与后续可能发生的退役（shared 替换）彻底解耦。
	std::shared_ptr<Impl::Shared> probeState;
	HANDLE cancelHandle = nullptr;
	bool needRetire = false;

	// ---- 派发阶段（锁内）----
	{
		std::lock_guard<std::mutex> lock(impl_->lock);

		if (!impl_->started || !impl_->shared || !impl_->shared->valid())
		{
			return false;
		}

		if (impl_->inFlight.load(std::memory_order_acquire))
		{
			// 上一次探测是否已完成但调用方尚未取走结果？
			// 非阻塞地取一次完成信号。
			if (WaitForSingleObject(impl_->shared->doneEvent, 0) == WAIT_OBJECT_0)
			{
				impl_->inFlight.store(false, std::memory_order_release);

				// 迟到结果属于同一目录：直接返回，不重复派发。
				// 若结果虽旧但仍准确（死目录通常维持死态），下一轮自然重新探测；
				// 关键收益：在途标记即时归零，同轮中后续的健康目录得以派发探测，
				// 不被死目录的单飞行探测连带跳过。
				if (impl_->lastProbePath == dir.wstring())
				{
					return impl_->shared->reachable.load(std::memory_order_acquire);
				}
				// 路径不同：结果与本次请求无关，落入下方派发新探测。
			}
			else
			{
				// 仍在途：未超黑窗阈值则快速判否（防累积）；超过则退役重起。
				unsigned long long stuckMs =
					GetTickCount64() - impl_->probeStartTick;
				if (stuckMs < constants::REMOTE_PROBE_MAX_BLACKOUT_MS)
				{
					return false;
				}
				// 退役在锁外执行（其内部包含 Sleep / join，持锁执行会阻塞
				// Stop() 等操作）；无论成败本轮都判否：成功的退役把新线程
				// 留给同轮健康目录，失败则保持旧状态一致，下一轮重试。
				needRetire = true;
			}
		}

		if (!needRetire)
		{
			// 派发本次探测。
			impl_->lastProbePath = dir.wstring();
			impl_->shared->targetPath = dir.wstring();
			// 清除可能残留的完成信号（上一次探测完成后调用方未取走的情形）。
			ResetEvent(impl_->shared->doneEvent);
			// 先记录派发时刻、再置在途标记：任何观察到 inFlight 的代码
			// 路径拿到的 probeStartTick 都是本次派发的有效时间戳，
			// 不会以过期时间戳误判卡死时长。
			impl_->probeStartTick = GetTickCount64();
			impl_->inFlight.store(true, std::memory_order_release);
			impl_->stuckLogged.store(false, std::memory_order_release);
			SetEvent(impl_->shared->requestEvent);

			probeState = impl_->shared;
			cancelHandle = impl_->workerHandle.get();
		}
	}

	if (needRetire)
	{
		impl_->Retire();
		return false;
	}

	// ---- 等待阶段（锁外）----
	DWORD wait = WaitForSingleObject(probeState->doneEvent, static_cast<DWORD>(timeoutMs));
	if (wait == WAIT_OBJECT_0)
	{
		// 探测已完成。
		impl_->inFlight.store(false, std::memory_order_release);
		return probeState->reachable.load(std::memory_order_acquire);
	}

	// ---- 超时恢复阶段 ----
	// 尝试取消卡在死 UNC 上的同步 IO，使探测线程尽快回到空闲。
	if (cancelHandle)
	{
		CancelSynchronousIo(cancelHandle);
	}

	// 宽限等待：探测可能刚被取消 / 恰好完成，取回其结果。
	if (WaitForSingleObject(probeState->doneEvent, constants::REMOTE_PROBE_CANCEL_GRACE_MS) == WAIT_OBJECT_0)
	{
		impl_->inFlight.store(false, std::memory_order_release);
		return probeState->reachable.load(std::memory_order_acquire);
	}

	// 仍无结果：探测确实卡死，在途标记保持 true。
	// 每个卡死周期仅记录一次诊断，避免每轮轮询重复刷屏。
	// 回调在锁外调用：锁内只做状态判断与回调拷贝，避免持锁调用用户
	// 回调造成潜在重入 / 阻塞。
	{
		DiagnosticCallback diag;
		bool logStuck = false;
		{
			std::lock_guard<std::mutex> lock(impl_->lock);
			if (!impl_->stuckLogged.exchange(true, std::memory_order_acq_rel))
			{
				diag = impl_->onDiagnostic;
				logStuck = true;
			}
		}
		if (logStuck && diag)
		{
			diag(L"RemoteProbe: remote path unreachable, probe is stuck. Will retry automatically.");
		}
	}

	// 在其自行返回或被退役前，后续 IsReachable 都会因在途标记而快速判否。
	return false;
}
