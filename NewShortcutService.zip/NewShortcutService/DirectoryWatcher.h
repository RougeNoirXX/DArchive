#pragma once

#include <filesystem>
#include <functional>
#include <set>
#include <vector>

#include <windows.h>

#include "WinHandles.h"

// =============================================================================
// DirectoryWatcher.h
// -----------------------------------------------------------------------------
// 混合式多目录监控器：事件驱动（本地）+ 定时轮询（远程 / 重定向）。
//
// 工作方式：
//   - 本地目录（watchDirs）：为每个目录打开句柄并发起异步 ReadDirectoryChangesW，
//     变更时经去抖后回调 onChange。
//   - 远程目录（pollDirs）：这类目录（如 C:\HarmonyOS 下指向 UNC 的符号链接）后端
//     不支持目录更改通知，不建立监控句柄，改为每隔 POLL_INTERVAL_MS 回调 onPoll
//     由上层重扫。进入循环前会先立即触发一次 onPoll，使远程桌面开机即被处理。
//   - 若某本地目录建立监控失败，则自动降级并入轮询集合。
//   - 运行中监控重发失败：该目录自动降级为轮询，保证仍被处理；
//     周期重枚举（onRefresh）时会再次尝试恢复事件监控（降级可逆）。
//   - 变更缓冲溢出（无法得知具体文件）：回调 onRescan 由上层整目录重扫，
//     避免批量变更被静默漏掉。
//   - 若提供了 onRefresh，则每隔 REENUM_INTERVAL_MS 调用一次，返回新发现的
//     目录集合；新目录会被增量登记（watch 失败仍降级轮询）。
//   - 停止事件保证 Run 即时退出。
//
// 线程模型：Run() 在调用线程内阻塞运行，直到 Stop() 被调用。
//           Stop() 可由任意线程安全调用。onChange / onPoll / onRescan / onRefresh
//           均在 Run 线程中调用。
// =============================================================================

class DirectoryWatcher
{
public:
	// 变更回调：参数为本批（经去抖合并、去重后）发生变更的文件路径集合。
	using ChangeCallback = std::function<void(const std::set<std::filesystem::path>&)>;

	// 轮询回调：参数为需轮询的目录集合。上层据此重扫这些目录。
	using PollCallback = std::function<void(const std::set<std::filesystem::path>&)>;

	// 重扫回调：参数为需要整目录重扫的目录集合。
	// 用于变更缓冲溢出（RDCW 返回 0 字节）时兜底处理，避免静默漏处理。
	using RescanCallback = std::function<void(const std::set<std::filesystem::path>&)>;

	// 目录刷新结果：新发现 / 重新分类的目录集合。
	struct DirSets
	{
		std::set<std::filesystem::path> watchDirs;     // 新增的本地（事件监控）目录
		std::set<std::filesystem::path> pollDirs;      // 新增的远程（轮询）目录
		std::set<std::filesystem::path> removePollDirs; // 从轮询集合移除的目录
		                                               // （重新分类为本地，转事件监控）
	};

	// 目录刷新回调：周期性调用，返回新发现的目录集合。
	using DirRefreshCallback = std::function<DirSets()>;

	DirectoryWatcher();
	~DirectoryWatcher();

	DirectoryWatcher(const DirectoryWatcher&) = delete;
	DirectoryWatcher& operator=(const DirectoryWatcher&) = delete;

	// 开始监控并阻塞运行，直到 Stop() 被调用。
	//   watchDirs : 本地目录，走事件驱动。
	//   pollDirs  : 远程 / 重定向目录，走定时轮询。
	//   onChange  : 本地目录变更回调。
	//   onPoll    : 轮询回调（进入循环前先触发一次，之后每 POLL_INTERVAL_MS 一次）。
	//   onRescan  : 变更缓冲溢出时的整目录重扫回调（可为空）。
	//   onRefresh : 周期性目录刷新回调（可为空；提供后每 REENUM_INTERVAL_MS 调用一次）。
	void Run(const std::set<std::filesystem::path>& watchDirs,
	         const std::set<std::filesystem::path>& pollDirs,
	         const ChangeCallback& onChange,
	         const PollCallback& onPoll,
	         const RescanCallback& onRescan = {},
	         const DirRefreshCallback& onRefresh = {});

	// 请求停止监控。可从其他线程调用；Run() 将尽快返回。
	void Stop() noexcept;

private:
	// 单个被监控目录的上下文。
	struct WatchContext
	{
		std::filesystem::path directory;         // 目录路径
		winhandles::ScopedHandle dirHandle;      // 目录句柄
		OVERLAPPED overlapped{};                 // 异步 IO 上下文
		std::vector<BYTE> buffer;                // 接收变更记录的缓冲区
		bool active = true;                      // 是否仍参与事件监控（降级后置 false）
		bool readPending = false;                // 是否有在途异步读取（内核仍引用 overlapped）。
		                                         // 取消后未获确认完成的上下文永久保留该标记
		                                         //（退役）：其 OVERLAPPED 不得再被复用。
	};

	// 对指定上下文发起一次异步读取，成功返回 true。
	bool IssueRead(WatchContext& ctx);

	// 处理某次读取完成捕获的通知数据（快照），经去抖后回调。
	// snapshot 为读取缓冲区的拷贝：调用方在重挂监控后处理快照，
	// 使处理窗口内产生的变更被新的 pending IO 捕获。
	void HandleNotifications(WatchContext& ctx, const std::vector<BYTE>& snapshot,
	                         const ChangeCallback& callback);

	// 停止事件：手动重置，触发后所有等待立即返回。
	winhandles::ScopedHandle m_stopEvent;

	// 退役上下文（取消未被确认完成的在途读取）：OVERLAPPED 仍可能被内核
	// 引用，其内存保留至进程生命周期结束（与 RemoteProbe 僵尸线程、
	// 服务对象进程级生命周期同一策略）——宁可小量泄漏，绝不释放仍可能
	// 被内核写入的内存。正常完成 / 取消已确认的上下文不会进入此集合。
	std::vector<std::unique_ptr<WatchContext>> m_retiredContexts;
};
