#include "ShortcutLink.h"

#include "Constants.h"
#include "PathProbe.h"

#include <windows.h>
#include <shlobj.h>
#include <objbase.h>
#include <wrl/client.h>
#include <utility>

#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")

// =============================================================================
// ShortcutLink.cpp
// -----------------------------------------------------------------------------
// 使用 IShellLinkW + IPersistFile 一次性加载 .lnk 并解析目标路径，
// 由目标路径推断“空目标”“特殊快捷方式”“目标是否存在”“是否失效”等标记。
// =============================================================================

namespace shortcut
{
	namespace
	{
		// 大小写不敏感的前缀判断（使用系统排序规则，与文件系统语义一致）。
		bool StartsWithIgnoreCase(std::wstring_view s, std::wstring_view prefix)
		{
			if (s.size() < prefix.size())
			{
				return false;
			}
			return ::CompareStringOrdinal(
				s.data(), static_cast<int>(prefix.size()),
				prefix.data(), static_cast<int>(prefix.size()),
				TRUE) == CSTR_EQUAL;
		}

		// 判断目标是否为 URL / shell 命名空间形式。
		// 这类目标不是普通文件系统路径，绝不能按“文件不存在”判定失效删除。
		bool IsUrlLike(std::wstring_view v)
		{
			return v.find(L"://") != std::wstring_view::npos ||
				StartsWithIgnoreCase(v, L"http:") ||
				StartsWithIgnoreCase(v, L"https:") ||
				StartsWithIgnoreCase(v, L"ftp:") ||
				StartsWithIgnoreCase(v, L"file:") ||
				StartsWithIgnoreCase(v, L"shell:") ||
				StartsWithIgnoreCase(v, L"mailto:") ||
				StartsWithIgnoreCase(v, L"tel:");
		}

		// 从已加载的 IShellLinkW 中解析出 LinkInfo（不含 loaded 标记的设置）。
		// 调用方需保证 psl 已成功 Load 某个 .lnk 文件。
		void ParseLoadedLink(IShellLinkW* psl, LinkInfo& info)
		{
			// 使用足够大的缓冲读取目标路径，避免长路径（>MAX_PATH）被截断
			// 导致“目标不存在”的误判。快捷方式目标最长可达约 32K 字符
			// （\\?\ 扩展长度前缀），此处按上限分配。
			std::wstring buffer(32768, L'\0');
			HRESULT hr = psl->GetPath(
				buffer.data(), static_cast<int>(buffer.size()), nullptr, SLGP_RAWPATH);
			if (FAILED(hr))
			{
				// 目标不可解析（链接本身已加载但取不到目标）：状态未知。
				// 安全策略：不删除、不搬运，保留原位。
				info.target_unknown = true;
				info.is_dangling = false;
				return;
			}

			// 以 NUL 截断，去掉多余填充。
			std::wstring target(buffer.c_str());
			info.target = target;

			// 读取启动参数（用于去重比对）。缓冲同样按上限分配；失败留空。
			std::wstring argsBuffer(32768, L'\0');
			HRESULT hrArgs = psl->GetArguments(
				argsBuffer.data(), static_cast<int>(argsBuffer.size()));
			if (SUCCEEDED(hrArgs))
			{
				info.arguments.assign(argsBuffer.c_str());
			}

			// 判定空目标。
			info.empty_target = target.empty();

			// 判定特殊快捷方式：目标为空、包含 "::{" 或以 "::" 开头（shell 命名空间
			// 对象，如“此电脑”“回收站”），以及 URL / shell: 等非文件系统目标。
			// 这些均视为不可搬运项，且不能按“文件不存在”判定失效。
			// 注：C++17 无 wstring_view::starts_with，用 rfind(..., 0) 等价判断前缀。
			std::wstring_view view(info.target);
			info.special =
				view.empty() ||
				view.find(L"::{") != std::wstring_view::npos ||
				view.rfind(L"::", 0) == 0 ||
				IsUrlLike(view);

			// 判定目标是否真实存在于磁盘。
			// 仅对普通文件系统路径检查；特殊 / 空目标无需检查（也无法检查）。
			// 使用带超时探测：目标位于短暂不可达的远程卷时不会长时间阻塞，
			// 且超时按“存在”保守处理——绝不因探测失败误删快捷方式。
			if (!info.special && !info.empty_target)
			{
				info.target_exists = pathprobe::PathExistsWithTimeout(
					info.target, constants::REMOTE_PROBE_TIMEOUT_MS);
			}

			// 判定是否为失效快捷方式：
			//   - 目标为空                       -> 失效
			//   - 目标为普通路径但文件不存在      -> 失效（例如程序被卸载）
			//   - 特殊快捷方式（如“此电脑”）      -> 不算失效
			if (info.special)
			{
				info.is_dangling = info.empty_target;
			}
			else
			{
				info.is_dangling = info.empty_target || !info.target_exists;
			}
		}
	}

	LinkInfo ReadLink(const std::filesystem::path& shortcut_path)
	{
		LinkReader reader;
		return reader.Read(shortcut_path);
	}

	// PImpl：持有真实的 COM 对象。定义在 .cpp 中，头文件无需引入 COM 头，
	// 同时此处保持完全的类型安全（ComPtr 自动管理引用计数与释放）。
	struct LinkReader::Impl
	{
		Microsoft::WRL::ComPtr<IShellLinkW> shell_link;
		Microsoft::WRL::ComPtr<IPersistFile> persist_file;

		// 确保内部 COM 对象已创建，成功返回 true。首次调用时惰性创建。
		bool EnsureCreated()
		{
			if (shell_link && persist_file)
			{
				return true;
			}

			// 创建 ShellLink COM 对象。
			Microsoft::WRL::ComPtr<IShellLinkW> psl;
			HRESULT hr = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER,
			                              IID_PPV_ARGS(&psl));
			if (FAILED(hr))
			{
				return false;
			}

			// 获取 IPersistFile 接口用于从磁盘加载 .lnk 文件。
			Microsoft::WRL::ComPtr<IPersistFile> ppf;
			hr = psl.As(&ppf);
			if (FAILED(hr))
			{
				return false;
			}

			shell_link = std::move(psl);
			persist_file = std::move(ppf);
			return true;
		}
	};

	LinkReader::LinkReader() : impl_(std::make_unique<Impl>())
	{
	}

	// 析构定义在此处（.cpp）：Impl 此时为完整类型，unique_ptr 可正确销毁。
	LinkReader::~LinkReader() = default;

	LinkInfo LinkReader::Read(const std::filesystem::path& shortcut_path)
	{
		LinkInfo info;

		if (!impl_->EnsureCreated())
		{
			// COM 创建失败：loaded 保持 false，交由上层按安全策略处理。
			return info;
		}

		// 以只读方式加载快捷方式文件。
		HRESULT hr = impl_->persist_file->Load(shortcut_path.c_str(), STGM_READ);
		if (FAILED(hr))
		{
			return info;
		}

		// 加载成功，解析内容。
		info.loaded = true;
		ParseLoadedLink(impl_->shell_link.Get(), info);
		return info;
	}
}
