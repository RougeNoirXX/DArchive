#pragma once

#include "ServiceBase.h"
#include "DirectoryWatcher.h"
#include "RemoteProbe.h"

#include <atomic>
#include <thread>
#include <windows.h>

// =============================================================================
// WindowsServiceImpl.h
// -----------------------------------------------------------------------------
// 具体服务实现，串联各功能模块：
//   启动 -> 工作线程执行全量扫描 -> 进入目录实时监控 ->
//   收到变更处理单个快捷方式 -> 有变更则刷新桌面。
//   停止时通过监控器的停止事件即时唤醒工作线程退出。
//
// 相较原版：移除了 ThreadPool（单循环无需线程池），改用一个 std::thread；
//           轮询改为事件驱动，停止响应从最长 60 秒降为即时。
// =============================================================================

class CWindowsServiceImpl : public CServiceBase
{
public:
	explicit CWindowsServiceImpl(const wchar_t* serviceName,
	                             bool canStop = true,
	                             bool canShutdown = true,
	                             bool canPauseContinue = false);
	~CWindowsServiceImpl() noexcept override;

protected:
	void OnStart(DWORD argc, wchar_t** argv) override;
	void OnStop() override;
	void OnShutdown() override;

private:
	// 工作线程主体：全量扫描 + 进入实时监控循环。
	// 由 ServiceWorkerThread 包裹异常防护后调用。
	void ServiceWorkerThreadBody();

	// 工作线程入口：为线程体提供顶层异常防护。
	// 任何异常都不得逃出线程入口（否则 std::terminate 会终止整个服务进程）。
	void ServiceWorkerThread();

	// 有界地停止工作线程：先取消其同步 IO，宽限窗口内轮询退出状态，
	// 已退出则 join；超时仍存活则 detach 并告警（进程即将退出，安全）。
	void StopWorkerWithGrace();

	// 工作线程异常退出后的收尾：停止监控与探测器，并向 SCM 报告服务
	// 已停止——避免“SCM 显示运行中、实际已不工作”的静默停摆。
	void ShutdownAfterWorkerFailure();

	// 处理一次操作报告：有变更时写日志并刷新桌面。
	void HandleReport(const struct OperationReport& report);

	DirectoryWatcher m_watcher;   // 目录监控器
	RemoteProbe m_probe;          // 远程可达性探测器
	std::thread m_worker;         // 工作线程
	std::atomic<bool> m_stopping{false};
};
