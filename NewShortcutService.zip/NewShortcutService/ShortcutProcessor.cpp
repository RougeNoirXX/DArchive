#include "ShortcutProcessor.h"

#include "Constants.h"
#include "PathProbe.h"
#include "ShortcutLink.h"
#include "WinHandles.h"

#include <windows.h>
#include <cstring>
#include <cwctype>
#include <iterator>
#include <vector>

// =============================================================================
// ShortcutProcessor.cpp
// -----------------------------------------------------------------------------
// 核心处理逻辑实现。所有文件系统异常在方法内部被吞掉（尽力而为），
// 单个文件 / 目录出错不影响整体流程。
// =============================================================================

namespace fs = std::filesystem;

namespace
{
	// 判断路径扩展名是否为 .lnk（大小写不敏感）。
	bool IsShortcutFile(const fs::path& p)
	{
		std::wstring ext = p.extension().wstring();
		for (auto& c : ext)
		{
			c = static_cast<wchar_t>(std::towlower(c));
		}
		return ext == constants::SHORTCUT_EXTENSION;
	}

	// 路径键归一化：展开环境变量、去掉 \\?\ 前缀、统一分隔符、
	// 去尾分隔符、转小写。用于目标 / 参数的比对键。
	std::wstring NormalizePathPart(std::wstring path)
	{
		// 目标可能包含环境变量（如 %ProgramFiles%），先展开再比对
		//（两阶段动态缓冲，避免固定缓冲截断导致去重键不一致）。
		// 用户级变量（%USERPROFILE% 等）在服务上下文中的展开结果是
		// 错误值：此时保持原始形式，使"原始目标相同"的两个快捷方式
		// 仍能命中同一条去重键——错误的展开反而会制造键不一致。
		if (!pathprobe::ContainsUserContextVariable(path))
		{
			path = pathprobe::ExpandEnvironmentVariablesDynamic(path);
		}

		// 去掉 \\?\ 扩展长度前缀。
		if (path.rfind(L"\\\\?\\", 0) == 0)
		{
			path.erase(0, 4);
		}

		for (auto& c : path)
		{
			if (c == L'/')
			{
				c = L'\\';
			}
			else
			{
				c = static_cast<wchar_t>(std::towlower(c));
			}
		}

		// 去掉尾部多余分隔符（保留盘符根）。
		while (path.size() > 1 && path.back() == L'\\')
		{
			path.pop_back();
		}
		return path;
	}

	// 去重键：归一化目标 + 分隔符 + 归一化参数。
	std::wstring BuildDedupeKey(const std::wstring& target, const std::wstring& args)
	{
		return NormalizePathPart(target) + L"|" + NormalizePathPart(args);
	}

	// 文件名同族判断（大小写不敏感）：
	// 去掉 .lnk 扩展名与尾部 _N 后缀后比较基名。
	// 覆盖“公共桌面上的 AppA_1.lnk 与用户桌面的 AppA.lnk 实为同一快捷方式”
	// （早期搬运因重名被追加了后缀）的情形。
	bool SameNameFamily(const std::wstring& a, const std::wstring& b)
	{
		auto base = [](std::wstring name)
		{
			// 去掉扩展名。
			if (name.size() >= constants::SHORTCUT_EXTENSION.size())
			{
				std::wstring tail = name.substr(name.size() - constants::SHORTCUT_EXTENSION.size());
				for (auto& c : tail)
				{
					c = static_cast<wchar_t>(std::towlower(c));
				}
				if (tail == constants::SHORTCUT_EXTENSION)
				{
					name.resize(name.size() - constants::SHORTCUT_EXTENSION.size());
				}
			}

			// 剥掉尾部 _N（数字后缀）。
			size_t pos = name.find_last_of(L'_');
			if (pos != std::wstring::npos && pos + 1 < name.size())
			{
				bool digits = true;
				for (size_t i = pos + 1; i < name.size(); ++i)
				{
					if (!iswdigit(name[i]))
					{
						digits = false;
						break;
					}
				}
				if (digits)
				{
					name.resize(pos);
				}
			}

			for (auto& c : name)
			{
				c = static_cast<wchar_t>(std::towlower(c));
			}
			return name;
		};

		return base(a) == base(b);
	}

	// 生成唯一目标路径：若目标已存在，则依次尝试 name_1.lnk、name_2.lnk……
	// 最多尝试 1000 次，超出则返回原始路径（由上层的搬运操作决定成败）。
	fs::path MakeUniquePath(const fs::path& desired)
	{
		// 存在性检查使用 error_code 重载：瞬时 IO / 权限错误不应向上抛出
		// （事件回调路径上无捕获，异常会击穿整个服务）。检查失败按
		// "未确认存在"返回候选名，真正的防覆盖由 CopyFileW(..., TRUE)
		// 保证——即使此处误判也不会覆盖他人文件。
		std::error_code ec;
		if (!fs::exists(desired, ec))
		{
			return desired;
		}

		fs::path stem = desired.stem();
		fs::path ext = desired.extension();
		fs::path parent = desired.parent_path();

		constexpr int MAX_ATTEMPTS = 1000;
		for (int attempt = 1; attempt <= MAX_ATTEMPTS; ++attempt)
		{
			fs::path candidate = parent /
				(stem.wstring() + L"_" + std::to_wstring(attempt) + ext.wstring());
			std::error_code ecCandidate;
			if (!fs::exists(candidate, ecCandidate))
			{
				return candidate;
			}
		}

		return desired;
	}

	// 判断两个目录是否为同一路径（用于避免把公共桌面上的文件搬到它自己）。
	bool IsSamePath(const fs::path& a, const fs::path& b)
	{
		std::error_code ec;
		return fs::equivalent(a, b, ec);
	}

	// 生成一个当前不存在的服务专属临时路径（在原文件同目录下）。
	// 命名带服务标记（.lnk.svc.tmp[<N>]），便于后续孤儿清理精确识别
	// 本服务的残留；且仍非 .lnk，保持规避针对 .lnk 外部监控的语义。
	fs::path MakeUniqueTmpPath(const fs::path& original)
	{
		constexpr int MAX_ATTEMPTS = 1000;
		for (int attempt = 0; attempt < MAX_ATTEMPTS; ++attempt)
		{
			fs::path candidate = original;
			if (attempt == 0)
			{
				candidate += L".svc.tmp";
			}
			else
			{
				candidate += (L".svc.tmp" + std::to_wstring(attempt));
			}
			// 同 MakeUniquePath：error_code 重载防止瞬时错误击穿服务；
			// 误判时由句柄改名 ReplaceIfExists=FALSE 兜底，绝不覆盖他人文件。
			std::error_code ec;
			if (!fs::exists(candidate, ec))
			{
				return candidate;
			}
		}
		// 极端情况：全部名称被占。后续句柄改名会因 ReplaceIfExists=FALSE 失败，
		// 操作安全失败，由下一轮重试。
		return original;
	}

	// 判断文件名是否为本服务的临时孤儿（<name>.lnk.svc.tmp[<N>]）。
	bool IsServiceTmpFile(const std::wstring& name)
	{
		const std::wstring marker = L".lnk.svc.tmp";
		size_t pos = name.rfind(marker);
		if (pos == std::wstring::npos || pos == 0)
		{
			return false;
		}
		// 标记之后必须为空或纯数字（.svc.tmp2 等形式）。
		for (size_t i = pos + marker.size(); i < name.size(); ++i)
		{
			if (!iswdigit(name[i]))
			{
				return false;
			}
		}
		return true;
	}

	// ---------------------------------------------------------------------
	// 待清理清单（注册表持久化）：
	// 改名生成 .svc.tmp 时登记“临时路径 + 文件身份（卷序列号:索引高低位）”，
	// 清理时校验身份一致才删除。文件名格式匹配不足以证明所有权，
	// 清单 + 文件 ID 双重校验确保绝不误删用户自建的同格式文件，
	// 且跨服务重启仍有效（覆盖崩溃残留）。
	// ---------------------------------------------------------------------

	// 待清理清单注册表键路径（HKLM 下）。
	std::wstring PendingCleanupKeyPath()
	{
		return L"SOFTWARE\\" + std::wstring(constants::SERVICE_NAME) + L"\\PendingCleanup";
	}

	// 打开待清理清单键；create 为 true 时不存在则创建。
	// 打不开时返回空键（调用方视为清单不可用，退化为“不清理”）。
	winhandles::RegKey OpenPendingCleanupKey(bool create)
	{
		HKEY raw = nullptr;
		std::wstring keyPath = PendingCleanupKeyPath();
		LONG r = RegOpenKeyExW(HKEY_LOCAL_MACHINE, keyPath.c_str(), 0,
			KEY_READ | KEY_WRITE, &raw);
		if (r != ERROR_SUCCESS && create)
		{
			r = RegCreateKeyExW(HKEY_LOCAL_MACHINE, keyPath.c_str(), 0, nullptr, 0,
				KEY_READ | KEY_WRITE, nullptr, &raw, nullptr);
		}
		return winhandles::RegKey(raw);
	}

	// 由文件元信息生成不可伪造的“当前文件对象”身份串。
	std::wstring MakeFileIdentity(const BY_HANDLE_FILE_INFORMATION& id)
	{
		return std::to_wstring(id.dwVolumeSerialNumber) + L":" +
			std::to_wstring(id.nFileIndexHigh) + L":" +
			std::to_wstring(id.nFileIndexLow);
	}

	// 登记待清理临时文件：值名 = 完整路径，数据 = 文件身份。
	void RecordPendingCleanup(const fs::path& tmpPath, const BY_HANDLE_FILE_INFORMATION& id)
	{
		winhandles::RegKey key = OpenPendingCleanupKey(true);
		if (!key)
		{
			return;
		}
		std::wstring identity = MakeFileIdentity(id);
		RegSetValueExW(key, tmpPath.wstring().c_str(), 0, REG_SZ,
			reinterpret_cast<const BYTE*>(identity.c_str()),
			static_cast<DWORD>((identity.size() + 1) * sizeof(wchar_t)));
	}

	// 移除登记记录（文件已删除 / 已恢复原名）。
	void RemovePendingCleanup(const fs::path& tmpPath)
	{
		winhandles::RegKey key = OpenPendingCleanupKey(false);
		if (!key)
		{
			return;
		}
		RegDeleteValueW(key, tmpPath.wstring().c_str());
	}

	// 校验候选文件是否为本服务登记的孤儿：路径与文件身份同时匹配。
	bool VerifyPendingCleanup(const fs::path& tmpPath, const BY_HANDLE_FILE_INFORMATION& id)
	{
		winhandles::RegKey key = OpenPendingCleanupKey(false);
		if (!key)
		{
			return false;
		}
		wchar_t buffer[128] = {0};
		DWORD size = sizeof(buffer);
		if (RegQueryValueExW(key, tmpPath.wstring().c_str(), nullptr, nullptr,
			reinterpret_cast<LPBYTE>(buffer), &size) != ERROR_SUCCESS)
		{
			return false;
		}
		return MakeFileIdentity(id) == std::wstring(buffer);
	}

	// 清理一个候选孤儿临时文件：
	//   1) 句柄绑定打开（DELETE 权限、不含 FILE_SHARE_DELETE）；
	//   2) 登记记录存在且文件身份一致（否则绝不删除——可能为用户文件）；
	//   3) 同句柄 FileDispositionInfo 标记删除（不经过路径删除，杜绝 TOCTOU）；
	//   4) 成功后移除登记记录。
	void SweepPendingTmp(const fs::path& tmpPath)
	{
		winhandles::ScopedHandle h(CreateFileW(
			tmpPath.c_str(),
			DELETE | FILE_READ_ATTRIBUTES,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			nullptr,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			nullptr));
		if (!h.valid())
		{
			// 不存在或不可访问：登记记录保留，下轮重试（绝不误删）。
			return;
		}

		BY_HANDLE_FILE_INFORMATION id{};
		if (!GetFileInformationByHandle(h.get(), &id))
		{
			return;
		}

		// 所有权验证：无登记记录或身份不符 → 非本服务文件，跳过。
		if (!VerifyPendingCleanup(tmpPath, id))
		{
			return;
		}

		FILE_DISPOSITION_INFO disposition{};
		disposition.DeleteFile = TRUE;
		if (SetFileInformationByHandle(
			h.get(), FileDispositionInfo, &disposition, sizeof(disposition)))
		{
			RemovePendingCleanup(tmpPath);
		}
		// 标记失败（如文件被他人占用）：记录保留，下轮重试。
	}

	// 清理登记记录中文件已不存在的陈旧条目，防止清单无限增长。
	void PrunePendingCleanup()
	{
		winhandles::RegKey key = OpenPendingCleanupKey(false);
		if (!key)
		{
			return;
		}

		wchar_t name[4096];
		DWORD index = 0;
		for (;;)
		{
			DWORD nameSize = static_cast<DWORD>(std::size(name));
			LONG r = RegEnumValueW(key, index, name, &nameSize,
				nullptr, nullptr, nullptr, nullptr);
			if (r == ERROR_NO_MORE_ITEMS)
			{
				break;
			}
			if (r == ERROR_MORE_DATA)
			{
				// 名称超长（极端路径）：跳过该条。
				++index;
				continue;
			}
			if (r != ERROR_SUCCESS)
			{
				break;
			}

			// 文件已不存在 → 陈旧记录，删除后索引前移。
			// 用带超时探测替代 fs::exists：登记路径可能位于远程桌面，
			// 共享宕机时直接检查会把工作线程阻塞在 SMB 超时上。探测
			// 超时按"存在"保守处理（保留记录、下轮重试）——宁可记录
			// 滞留，不可卡死线程。
			if (!pathprobe::PathExistsWithTimeout(
				std::wstring(name), constants::REMOTE_PROBE_TIMEOUT_MS))
			{
				RegDeleteValueW(key, name);
			}
			else
			{
				++index;
			}
		}
	}

	// 基于已打开的句柄将文件改名为唯一 .tmp 名并标记删除。
	// “改名 → 删除”全程绑定同一文件对象：即使路径被其他进程替换，
	// 也绝不会误删新文件（杜绝“路径重定位”方式的 TOCTOU 数据破坏）。
	// 注意：句柄需以 DELETE 权限、且不含 FILE_SHARE_DELETE 打开
	//（SetFileInformationByHandle 的 FileRenameInfo 要求）。
	// 函数接管句柄所有权，任何返回路径都会释放。
	// 返回 true 表示文件已被成功清除。
	bool RenameByHandleAndDelete(HANDLE h, const fs::path& original)
	{
		winhandles::ScopedHandle owner(h);

		// 第一步：基于句柄改名（绑定同一文件对象）。
		// 采用“原子尝试”而非“先 exists 检查后改名”：目标名被抢占
		// （ERROR_ALREADY_EXISTS / ERROR_FILE_EXISTS）时换名重试，
		// ReplaceIfExists=FALSE 保证绝不覆盖他人文件。
		constexpr int MAX_RENAME_RETRY = 8;
		fs::path tmp;
		bool renamed = false;
		for (int attempt = 0; attempt < MAX_RENAME_RETRY; ++attempt)
		{
			tmp = MakeUniqueTmpPath(original);

			// FileRenameInfo 要求完整路径（含盘符）。
			std::wstring tmpFull = tmp.wstring();
			std::vector<BYTE> buffer(
				sizeof(FILE_RENAME_INFO) + tmpFull.size() * sizeof(wchar_t));
			auto* renameInfo = reinterpret_cast<FILE_RENAME_INFO*>(buffer.data());
			renameInfo->ReplaceIfExists = FALSE;
			renameInfo->RootDirectory = nullptr;
			renameInfo->FileNameLength = static_cast<DWORD>(tmpFull.size() * sizeof(wchar_t));
			memcpy(renameInfo->FileName, tmpFull.c_str(), tmpFull.size() * sizeof(wchar_t));

			if (SetFileInformationByHandle(
				owner.get(), FileRenameInfo, buffer.data(), static_cast<DWORD>(buffer.size())))
			{
				renamed = true;
				break;
			}

			DWORD err = GetLastError();
			if (err != ERROR_ALREADY_EXISTS && err != ERROR_FILE_EXISTS)
			{
				// 非重名类错误：放弃（本轮不删除，下一轮重试）。
				return false;
			}
			// 重名被抢占：换名重试。
		}
		if (!renamed)
		{
			return false;
		}

		// 改名成功后立即登记待清理清单：跨重启的孤儿清理依赖
		// “路径 + 文件身份”双重验证，绝不误删用户自建的同格式文件。
		{
			BY_HANDLE_FILE_INFORMATION id{};
			if (GetFileInformationByHandle(owner.get(), &id))
			{
				RecordPendingCleanup(tmp, id);
			}
		}

		// 第二步：对同一句柄标记删除（FileDispositionInfo），不经过任何
		// 路径操作——消除“改名后关闭句柄再按路径删除”的第二次 TOCTOU。
		FILE_DISPOSITION_INFO disposition{};
		disposition.DeleteFile = TRUE;
		if (!SetFileInformationByHandle(
			owner.get(), FileDispositionInfo, &disposition, sizeof(disposition)))
		{
			// 标记删除失败：先基于句柄改回原名；若句柄改名也失败，
			// 关闭句柄后用路径级 MoveFileW 兜底，尽力避免残留孤儿。
			std::wstring origFull = original.wstring();
			std::vector<BYTE> restore(
				sizeof(FILE_RENAME_INFO) + origFull.size() * sizeof(wchar_t));
			auto* restoreInfo = reinterpret_cast<FILE_RENAME_INFO*>(restore.data());
			restoreInfo->ReplaceIfExists = FALSE;
			restoreInfo->RootDirectory = nullptr;
			restoreInfo->FileNameLength = static_cast<DWORD>(origFull.size() * sizeof(wchar_t));
			memcpy(restoreInfo->FileName, origFull.c_str(), origFull.size() * sizeof(wchar_t));

			bool restoredByHandle = SetFileInformationByHandle(
				owner.get(), FileRenameInfo, restore.data(), static_cast<DWORD>(restore.size())) != FALSE;
			if (restoredByHandle)
			{
				// 已恢复原名：登记记录随之失效。
				RemovePendingCleanup(tmp);
			}
			else
			{
				// 关闭句柄后再路径级恢复（持有不含 FILE_SHARE_DELETE 的
				// 句柄时路径级改名会被共享冲突拒绝）。不覆盖任何已存在的
				// 同名文件；若仍失败，孤儿交由后续扫描清理（登记记录保留）。
				owner.reset();
				if (MoveFileW(tmp.c_str(), original.c_str()))
				{
					RemovePendingCleanup(tmp);
				}
			}
			return false;
		}

		// 第三步：返回时 ScopedHandle 关闭最后一个句柄，文件随即被删除。
		// 删除成功：登记记录一并移除。
		RemovePendingCleanup(tmp);
		return true;
	}

	// 读取句柄的全部内容并计算 FNV-1a 64 位哈希。
	// .lnk 文件通常极小（数 KB），成本可忽略。用于复制前后的内容稳定性校验。
	bool HashFileByHandle(HANDLE h, unsigned long long& hash)
	{
		hash = 14695981039346656037ull;
		BYTE buffer[4096];
		for (;;)
		{
			DWORD read = 0;
			if (!ReadFile(h, buffer, sizeof(buffer), &read, nullptr))
			{
				return false;
			}
			if (read == 0)
			{
				return true;
			}
			for (DWORD i = 0; i < read; ++i)
			{
				hash ^= buffer[i];
				hash *= 1099511628211ull;
			}
		}
	}

	// 安全删除：不直接 DeleteFileW（会被外部监控服务捕获并送入回收站）。
	// 步骤：1) 基于句柄将原文件改名为 .tmp 后缀；2) 删除该 .tmp 文件。
	// 通过先改名规避针对 .lnk 的监控，同时句柄绑定身份避免误删被替换的文件。
	// 返回 true 表示文件已被成功清除。
	bool SafeDelete(const fs::path& target)
	{
		// 打开源文件：DELETE 权限供句柄改名；不含 FILE_SHARE_DELETE，
		// 保证改名操作期间该文件对象不会被其他进程删除替换。
		winhandles::ScopedHandle h(CreateFileW(
			target.c_str(),
			DELETE | FILE_READ_ATTRIBUTES,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			nullptr,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			nullptr));
		if (!h.valid())
		{
			return false;
		}

		return RenameByHandleAndDelete(h.release(), target);
	}

	// 安全移动：不直接 MoveFileW（会被外部监控服务捕获并把源文件送入回收站）。
	// 步骤：1) 复制到目标目录；2) 基于句柄将源文件改名为 .tmp；3) 删除该 .tmp。
	// 返回 true 表示已成功搬运（目标已就位且源已清除）。
	//
	// 说明：dest 由调用方经 MakeUniquePath 生成，但在“检查—复制”之间仍可能有其他
	// 进程抢先创建同名文件（TOCTOU）。故此处用 CopyFileW(..., TRUE) 要求目标不存在，
	// 若冲突则重新生成唯一名重试，避免直接覆盖他人文件。
	bool SafeMove(const fs::path& src, const fs::path& dest)
	{
		// 打开源文件并记录其身份：后续清除源时只允许操作同一文件对象，
		// 防止“复制完成 → 源被替换”窗口内误删新文件。
		// 同时需要读权限：复制前后对内容做哈希，校验复制期间未发生变化。
		winhandles::ScopedHandle hSrc(CreateFileW(
			src.c_str(),
			DELETE | FILE_READ_ATTRIBUTES | FILE_READ_DATA,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			nullptr,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			nullptr));
		if (!hSrc.valid())
		{
			return false;
		}

		BY_HANDLE_FILE_INFORMATION idBefore{};
		if (!GetFileInformationByHandle(hSrc.get(), &idBefore))
		{
			return false;
		}

		// 复制前内容快照（哈希）。
		unsigned long long hashBefore = 0;
		if (!HashFileByHandle(hSrc.get(), hashBefore))
		{
			return false;
		}

		fs::path target = dest;

		bool copied = false;
		constexpr int MAX_RETRY = 1000;
		for (int attempt = 0; attempt < MAX_RETRY; ++attempt)
		{
			// bFailIfExists = TRUE：目标已存在则失败，杜绝覆盖。
			if (CopyFileW(src.c_str(), target.c_str(), TRUE))
			{
				copied = true;
				break;
			}

			DWORD err = GetLastError();
			if (err == ERROR_FILE_EXISTS || err == ERROR_ALREADY_EXISTS)
			{
				// 目标被抢占：重新生成一个唯一名再试。
				target = MakeUniquePath(dest);
				continue;
			}

			// 其他错误：复制失败，放弃。
			return false;
		}

		// 极端情况：全部重试均被抢占，复制并未成功。
		// 此时绝不允许进入删源阶段——否则目标没有副本而源已丢失。
		if (!copied)
		{
			return false;
		}

		// 复制后校验源：文件身份（file ID）+ 大小 + 最后写入时间 + 内容哈希
		// 四重校验。路径上的文件若已不是复制时的对象、或复制期间内容被
		// 修改——回滚目标副本并放弃，下一轮重新处理，
		// 避免“副本与源最终状态不一致”或误删新文件。
		{
			winhandles::ScopedHandle hVerify(CreateFileW(
				src.c_str(),
				FILE_READ_DATA,
				FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
				nullptr,
				OPEN_EXISTING,
				FILE_ATTRIBUTE_NORMAL,
				nullptr));
			BY_HANDLE_FILE_INFORMATION idNow{};
			unsigned long long hashAfter = 0;
			bool same = hVerify.valid() &&
				GetFileInformationByHandle(hVerify.get(), &idNow) &&
				idNow.dwVolumeSerialNumber == idBefore.dwVolumeSerialNumber &&
				idNow.nFileIndexHigh == idBefore.nFileIndexHigh &&
				idNow.nFileIndexLow == idBefore.nFileIndexLow &&
				idNow.nFileSizeHigh == idBefore.nFileSizeHigh &&
				idNow.nFileSizeLow == idBefore.nFileSizeLow &&
				idNow.ftLastWriteTime.dwLowDateTime == idBefore.ftLastWriteTime.dwLowDateTime &&
				idNow.ftLastWriteTime.dwHighDateTime == idBefore.ftLastWriteTime.dwHighDateTime &&
				HashFileByHandle(hVerify.get(), hashAfter) &&
				hashAfter == hashBefore;
			if (!same)
			{
				SafeDelete(target);
				return false;
			}
		}

		// 第二步 + 第三步：基于句柄清除源文件（与复制对象同一身份）。
		if (!RenameByHandleAndDelete(hSrc.release(), src))
		{
			// 源文件清除失败：回滚删除刚复制的目标，保持原状。
			SafeDelete(target);
			return false;
		}

		return true;
	}
}

void ShortcutProcessor::ProcessShortcut(const fs::path& shortcut,
                                        const fs::path& dest_root,
                                        shortcut::LinkReader& reader,
                                        OperationReport& report)
{
	// 读取快捷方式信息（复用 reader 内部 COM 对象）。
	shortcut::LinkInfo info = reader.Read(shortcut);

	// 安全策略：读取失败时状态不确定，既不删除也不移动。
	if (!info.loaded)
	{
		return;
	}

	// 目标无法解析（状态未知）：保留原位，不删除也不搬运。
	if (info.target_unknown)
	{
		return;
	}

	// 失效快捷方式：目标为空、或目标文件已不存在（如程序被卸载）。
	// 这类应当删除，不搬运。特殊有效项（如“此电脑”）不属失效，会被保留。
	if (info.is_dangling)
	{
		if (SafeDelete(shortcut))
		{
			++report.deleted_count;
			report.deleted_files.push_back(shortcut.filename().wstring());
		}
		return;
	}

	// 特殊快捷方式（shell 命名空间对象 / CLSID，且目标有效）：保留原位，不搬运。
	if (info.special)
	{
		return;
	}

	// ---- 搬运前去重 ----
	// 应用升级等场景会再次在用户桌面重建已被搬走的快捷方式。
	// 若公共桌面已有“同目标 + 同参数 + 文件名同族”的快捷方式，
	// 直接移除源副本而不搬运，避免公共桌面累积 _N 后缀的重复图标。
	std::wstring key = BuildDedupeKey(info.target, info.arguments);
	auto it = m_publicIndex.find(key);
	if (it != m_publicIndex.end() &&
		SameNameFamily(it->second, shortcut.filename().wstring()))
	{
		if (SafeDelete(shortcut))
		{
			++report.deduped_count;
			report.deduped_files.push_back(shortcut.filename().wstring());
		}
		return;
	}

	// 普通有效快捷方式：搬运到公共桌面，重名自动追加后缀。
	fs::path dest = MakeUniquePath(dest_root / shortcut.filename());
	if (SafeMove(shortcut, dest))
	{
		++report.moved_count;
		report.moved_files.push_back(shortcut.filename().wstring());
		// 同步登记索引，使同批 / 后续的同目标快捷方式也能命中去重。
		m_publicIndex.emplace(std::move(key), dest.filename().wstring());
	}
}

void ShortcutProcessor::ProcessDesktop(const fs::path& desktop,
                                       shortcut::LinkReader& reader,
                                       OperationReport& report)
{
	fs::path public_desktop(constants::PUBLIC_DESKTOP);

	// 公共桌面本身不作为“源”处理（它是搬运目标）。
	if (IsSamePath(desktop, public_desktop))
	{
		return;
	}

	try
	{
		for (const auto& entry : fs::directory_iterator(desktop))
		{
			if (!entry.is_regular_file())
			{
				continue;
			}

			// 清理本服务此前删除操作遗留的孤儿临时文件（登记 + 身份验证 + 句柄删除）。
			if (IsServiceTmpFile(entry.path().filename().wstring()))
			{
				SweepPendingTmp(entry.path());
				continue;
			}

			if (!IsShortcutFile(entry.path()))
			{
				continue;
			}

			ProcessShortcut(entry.path(), public_desktop, reader, report);
		}
	}
	catch (const fs::filesystem_error&)
	{
		// 单个桌面目录处理失败时忽略，继续处理其他桌面。
	}
}

void ShortcutProcessor::RefreshPublicIndex()
{
	m_publicIndex.clear();

	// 顺带清理清单中文件已不存在的陈旧记录，防止无限增长。
	PrunePendingCleanup();

	fs::path public_desktop(constants::PUBLIC_DESKTOP);
	std::error_code ec;
	if (!fs::exists(public_desktop, ec) || !fs::is_directory(public_desktop, ec))
	{
		return;
	}

	shortcut::LinkReader reader;
	try
	{
		for (const auto& entry : fs::directory_iterator(public_desktop))
		{
			if (!entry.is_regular_file())
			{
				continue;
			}

			// 清理本服务此前删除操作遗留的孤儿临时文件（登记 + 身份验证 + 句柄删除）。
			if (IsServiceTmpFile(entry.path().filename().wstring()))
			{
				SweepPendingTmp(entry.path());
				continue;
			}

			if (!IsShortcutFile(entry.path()))
			{
				continue;
			}

			shortcut::LinkInfo info = reader.Read(entry.path());
			// 仅收录成功读取的非特殊项。
			// dangling 项同样收录：若其目标字符串与源副本相同，仍需命中
			// 去重（删除源副本），随后由公共桌面清理将其收敛，最终仅存一份。
			if (info.loaded && !info.special && !info.target_unknown)
			{
				m_publicIndex.emplace(
					BuildDedupeKey(info.target, info.arguments),
					entry.path().filename().wstring());
			}
		}
	}
	catch (const fs::filesystem_error&)
	{
		// 索引构建失败时按空索引处理：去重不命中，仅影响重复项收敛，
		// 不影响正常搬运主流程。
	}
}

void ShortcutProcessor::CleanupPublicDesktop(shortcut::LinkReader& reader,
                                             OperationReport& report)
{
	fs::path public_desktop(constants::PUBLIC_DESKTOP);

	try
	{
		if (!fs::exists(public_desktop) || !fs::is_directory(public_desktop))
		{
			return;
		}

		for (const auto& entry : fs::directory_iterator(public_desktop))
		{
			if (!entry.is_regular_file())
			{
				continue;
			}
			if (!IsShortcutFile(entry.path()))
			{
				continue;
			}

			shortcut::LinkInfo info = reader.Read(entry.path());
			// 仅当成功读取且确认为失效快捷方式（空目标 / 目标不存在）时才删除。
			if (info.loaded && info.is_dangling)
			{
				if (SafeDelete(entry.path()))
				{
					++report.deleted_count;
					report.deleted_files.push_back(entry.path().filename().wstring());
					// 同步移除索引条目（仅当其在索引中，erase 幂等）。
					m_publicIndex.erase(BuildDedupeKey(info.target, info.arguments));
				}
			}
		}
	}
	catch (const fs::filesystem_error&)
	{
		// 忽略清理过程中的错误。
	}
}

OperationReport ShortcutProcessor::ScanAll(const std::set<fs::path>& localDesktops)
{
	OperationReport report;

	// 复用同一个读取器处理整轮扫描，避免逐文件重建 COM 对象。
	shortcut::LinkReader reader;

	// 先重建公共桌面索引，供搬运前去重比对。
	RefreshPublicIndex();

	// 遍历给定的本地桌面并处理。
	for (const auto& desktop : localDesktops)
	{
		ProcessDesktop(desktop, reader, report);
	}

	// 最后清理公共桌面中残留的失效快捷方式。
	CleanupPublicDesktop(reader, report);

	return report;
}

OperationReport ShortcutProcessor::ScanDirectories(const std::set<fs::path>& desktops)
{
	OperationReport report;

	// 复用同一个读取器处理本轮所有目录。
	shortcut::LinkReader reader;

	// 先重建公共桌面索引，供搬运前去重比对。
	RefreshPublicIndex();

	for (const auto& desktop : desktops)
	{
		ProcessDesktop(desktop, reader, report);
	}

	// 最后清理公共桌面中残留的失效快捷方式。
	CleanupPublicDesktop(reader, report);

	return report;
}

OperationReport ShortcutProcessor::ProcessSingle(const fs::path& shortcut_path)
{
	OperationReport report;

	// 仅处理 .lnk 文件。
	if (!IsShortcutFile(shortcut_path))
	{
		return report;
	}

	// 文件可能在去抖等待期间已被删除 / 移动，需再次确认存在。
	std::error_code ec;
	if (!fs::exists(shortcut_path, ec) || !fs::is_regular_file(shortcut_path, ec))
	{
		return report;
	}

	shortcut::LinkReader reader;
	fs::path public_desktop(constants::PUBLIC_DESKTOP);
	fs::path parent = shortcut_path.parent_path();

	// 若变更发生在公共桌面自身：只做失效快捷方式清理，不搬运。
	if (IsSamePath(parent, public_desktop))
	{
		shortcut::LinkInfo info = reader.Read(shortcut_path);
		if (info.loaded && info.is_dangling)
		{
			if (SafeDelete(shortcut_path))
			{
				++report.deleted_count;
				report.deleted_files.push_back(shortcut_path.filename().wstring());
				// 同步移除索引条目（仅当其在索引中，erase 幂等）。
				m_publicIndex.erase(BuildDedupeKey(info.target, info.arguments));
			}
		}
		return report;
	}

	// 其他桌面上的快捷方式：走标准处理逻辑。
	ProcessShortcut(shortcut_path, public_desktop, reader, report);

	return report;
}
