#pragma once

#include <filesystem>
#include <functional>
#include <memory>

// =============================================================================
// RemoteProbe.h
// -----------------------------------------------------------------------------
// 远程目录可达性探测器（带超时 + 自愈 + 防线程累积）。
//
// 用途：
//   共享服务存在低概率宕机的可能。轮询远程桌面前，先用本探测器确认其可达，
//   避免直接对死 UNC 发起文件操作而使工作线程被 SMB 超时（数十秒）长时间阻塞。
//
// 设计要点：
//   - 常驻一个探测工作线程，通过“请求 / 完成”事件与调用方握手执行探测动作。
//   - IsReachable 带超时：超时即视为不可达，立即返回，绝不阻塞调用线程超过超时值。
//   - 自愈（关键）：探测线程卡在死 UNC 时不再永久失明——
//       1) 超时后对探测线程调用 CancelSynchronousIo 中断挂起的同步 IO；
//       2) 若取消失败且卡死超过 REMOTE_PROBE_MAX_BLACKOUT_MS，强制“退役”
//          该线程（置退出事件后 detach）并重起新线程。
//     探测结果带“代数”校验：被退役的旧线程迟到的结果会被丢弃，不污染新探测。
//   - 迟到结果归位：上一次探测完成但调用方未取走时，若其属于同一目录则直接
//     返回该结果（不重复派发），使同轮中后续的健康目录得以正常探测，
//     避免死目录的单飞行探测连带饿死其他目录。
//   - 防累积：同一时刻只允许一个探测在途。若上一次探测仍卡在死 UNC 上未返回，
//     后续 IsReachable 直接返回 false（不可达），不会再派发新探测，
//     因此最多只有一个被卡住的探测动作，不会随轮询次数增长。
//   - 关机保护：Stop() 通知线程退出并短暂等待；若线程仍卡死则 detach，
//     不使 OnStop 挂起。
//
// 线程安全：IsReachable 与 Stop 可被不同线程调用（派发与线程生命周期操作
//           由内部互斥锁保护；等待完成事件不在锁内，二者不会互相阻塞）。
// =============================================================================

class RemoteProbe
{
public:
	// 诊断日志回调（可选）：探测线程卡死 / 退役等异常事件发生时调用。
	// 应在服务启动、首次调用 IsReachable 之前设置。
	using DiagnosticCallback = std::function<void(const wchar_t* message)>;

	RemoteProbe();
	~RemoteProbe();

	RemoteProbe(const RemoteProbe&) = delete;
	RemoteProbe& operator=(const RemoteProbe&) = delete;
	RemoteProbe(RemoteProbe&&) = delete;
	RemoteProbe& operator=(RemoteProbe&&) = delete;

	// 设置诊断日志回调。可传空以禁用。
	void SetDiagnosticCallback(DiagnosticCallback callback);

	// 探测目录是否在 timeoutMs 内可达。可达返回 true。
	// 若已有探测在途（上次卡死未归）则立即返回 false。
	bool IsReachable(const std::filesystem::path& dir, unsigned long timeoutMs);

	// 停止探测线程（关机时调用）。可安全多次调用。
	void Stop() noexcept;

private:
	struct Impl;
	std::unique_ptr<Impl> impl_;
};
