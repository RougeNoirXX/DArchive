#pragma once

#include <filesystem>

// =============================================================================
// PathClassifier.h
// -----------------------------------------------------------------------------
// 判定某个桌面目录属于“本地”还是“远程 / 重定向”。
//
// 背景：
//   C:\HarmonyOS\<用户>\Desktop 是指向自实现 UNC 共享的符号链接，该后端不支持
//   目录更改通知（ReadDirectoryChangesW 会静默永不触发），且共享可能宕机。
//   这类目录必须走“定时轮询 + 可达性门禁”，而非事件监控。
//
// 判定策略（两级）：
//   1. 主规则（不触碰远程、零本地误判）：路径位于 REDIRECT_ROOT(C:\HarmonyOS) 前缀下。
//   2. 兜底规则（覆盖其他远程重定向）：解析最终路径为 UNC(\\...) 或所在卷为
//      DRIVE_REMOTE。为避免共享宕机时兜底探测本身阻塞，兜底判定使用带超时的探测。
//
// 三态结果：
//   探测超时 / 无法判定时返回 Unknown（而非勉强归为本地）。
//   上层对 Unknown 目录按“轮询”处理：轮询自带可达性门禁且不会对死 UNC
//   打开监控句柄，宁可轮询，不可漏登，也绝不在启动阶段阻塞。
// =============================================================================

namespace pathcls
{
	// 目录分类结果。
	enum class DirKind
	{
		Local,    // 已确认为本地目录：走事件监控
		Remote,   // 已确认为远程 / 重定向目录：走轮询
		Unknown   // 探测超时 / 无法判定：按轮询处理（宁可轮询，不可漏登）
	};

	// 分类给定桌面目录。
	// probeTimeoutMs 仅用于兜底规则中的最终路径探测；主规则命中时不会触碰远程。
	// 探测超时返回 DirKind::Unknown。
	DirKind Classify(const std::filesystem::path& dir, unsigned long probeTimeoutMs);

	// 判断路径是否位于 REDIRECT_ROOT 前缀之下（纯字符串判断，不触碰文件系统）。
	bool IsUnderRedirectRoot(const std::filesystem::path& dir);
}
