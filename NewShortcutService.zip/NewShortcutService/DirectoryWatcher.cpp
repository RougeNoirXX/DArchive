#include "DirectoryWatcher.h"

#include "Constants.h"

#include <algorithm>
#include <memory>
#include <stdexcept>
#include <cwctype>

// =============================================================================
// DirectoryWatcher.cpp
// -----------------------------------------------------------------------------
// 多目录异步监控实现。使用 WaitForMultipleObjects 同时等待“停止事件”与
// 各目录的完成事件，避免使用 IOCP 的额外复杂度（受监控目录数量有限）。
// =============================================================================

namespace fs = std::filesystem;

namespace
{
	// 单目录接收缓冲区大小（字节）。足够容纳一批变更记录。
	constexpr DWORD NOTIFY_BUFFER_SIZE = 64 * 1024;

	// 关注的变更类型：文件名（新增 / 删除 / 改名）与最后写入时间（内容写完）。
	constexpr DWORD NOTIFY_FILTER =
		FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE;

	// 判断文件名是否以 .lnk 结尾（大小写不敏感）。
	bool IsShortcutName(const std::wstring& name)
	{
		constexpr std::wstring_view ext = L".lnk";
		if (name.size() < ext.size())
		{
			return false;
		}
		std::wstring tail = name.substr(name.size() - ext.size());
		for (auto& c : tail)
		{
			c = static_cast<wchar_t>(std::towlower(c));
		}
		return tail == ext;
	}
}

DirectoryWatcher::DirectoryWatcher()
{
	// 创建手动重置、初始未触发的停止事件。
	m_stopEvent.reset(CreateEventW(nullptr, TRUE, FALSE, nullptr));
	if (!m_stopEvent.valid())
	{
		throw std::runtime_error("Failed to create stop event for DirectoryWatcher");
	}
}

DirectoryWatcher::~DirectoryWatcher() = default;

void DirectoryWatcher::Stop() noexcept
{
	if (m_stopEvent.valid())
	{
		SetEvent(m_stopEvent);
	}
}

bool DirectoryWatcher::IssueRead(WatchContext& ctx)
{
	// 发起异步目录变更读取；结果通过 ctx.overlapped.hEvent 通知。
	bool ok = ReadDirectoryChangesW(
		ctx.dirHandle,
		ctx.buffer.data(),
		static_cast<DWORD>(ctx.buffer.size()),
		FALSE,              // 不递归监控子目录（桌面为平铺结构）
		NOTIFY_FILTER,
		nullptr,
		&ctx.overlapped,
		nullptr) != FALSE;

	if (ok)
	{
		// 读取成功发起：OVERLAPPED 自此被内核引用，
		// 直至该次读取完成（或取消完成）前不得关闭 / 复用。
		ctx.readPending = true;
	}
	return ok;
}

void DirectoryWatcher::HandleNotifications(WatchContext& ctx,
                                           const std::vector<BYTE>& snapshot,
                                           const ChangeCallback& callback)
{
	// 去重：同一批通知里同一文件可能出现多次。
	std::set<fs::path> touched;

	const BYTE* base = snapshot.data();
	DWORD offset = 0;
	for (;;)
	{
		// 防御：确保偏移始终在快照范围内。
		if (offset >= snapshot.size())
		{
			break;
		}
		auto* info = reinterpret_cast<const FILE_NOTIFY_INFORMATION*>(base + offset);

		// 仅关注新增 / 改名到本目录 / 内容修改这几类动作。
		if (info->Action == FILE_ACTION_ADDED ||
			info->Action == FILE_ACTION_RENAMED_NEW_NAME ||
			info->Action == FILE_ACTION_MODIFIED)
		{
			// 文件名非以 NUL 结尾，长度以字节记，需换算为字符数。
			std::wstring name(info->FileName, info->FileNameLength / sizeof(wchar_t));
			if (IsShortcutName(name))
			{
				touched.insert(ctx.directory / name);
			}
		}

		if (info->NextEntryOffset == 0)
		{
			break;
		}
		offset += info->NextEntryOffset;
	}

	// 去抖：变更发生后短暂等待，避免处理仍在写入中的 .lnk，
	// 同时让连续多条通知合并（此处对本批已去重，延迟主要防写入未完成）。
	if (!touched.empty())
	{
		// 等待期间若收到停止信号则提前返回，不再处理。
		if (WaitForSingleObject(m_stopEvent, constants::DEBOUNCE_DELAY_MS) == WAIT_OBJECT_0)
		{
			return;
		}

		// 以整批为单位回调，交由上层统一处理并在处理后仅刷新一次桌面。
		callback(touched);
	}
}

void DirectoryWatcher::Run(const std::set<fs::path>& watchDirs,
                           const std::set<fs::path>& pollDirs,
                           const ChangeCallback& onChange,
                           const PollCallback& onPoll,
                           const RescanCallback& onRescan,
                           const DirRefreshCallback& onRefresh)
{
	// 轮询目录集合：初始为传入的 pollDirs，本地目录建立监控失败时会降级并入，
	// 运行中监控重发失败时也会动态并入。
	std::set<fs::path> pollSet = pollDirs;

	// 各目录监控上下文。
	std::vector<std::unique_ptr<WatchContext>> contexts;
	contexts.reserve(watchDirs.size() + 8);

	// 当前活跃（参与事件监控）的上下文数量。
	auto activeContextCount = [&]()
	{
		size_t n = 0;
		for (const auto& ctx : contexts)
		{
			if (ctx->active)
			{
				++n;
			}
		}
		return n;
	};

	// 尝试为上下文建立事件监控：打开目录句柄 + 创建完成事件 + 发起读取。
	// 成功返回 true，并同步将该目录从轮询集合移除——恢复 / 建立事件监控
	// 后无需再轮询，避免双通道重复处理。
	auto tryActivate = [&](WatchContext& ctx) -> bool
	{
		// 退役上下文（取消未被确认完成、readPending 恒为 true）：其
		// OVERLAPPED 仍可能被内核引用，绝不复用。
		if (ctx.readPending)
		{
			return false;
		}

		// 以 FILE_FLAG_BACKUP_SEMANTICS 打开目录句柄（目录必需），
		// 并以 OVERLAPPED 方式进行异步读取。
		HANDLE h = CreateFileW(
			ctx.directory.c_str(),
			FILE_LIST_DIRECTORY,
			FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
			nullptr,
			OPEN_EXISTING,
			FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED,
			nullptr);
		if (h == INVALID_HANDLE_VALUE)
		{
			return false;
		}
		ctx.dirHandle.reset(h);

		// 为该目录的异步 IO 创建独立的自动重置事件。
		// 恢复场景：旧读取已完成（readPending 为 false），重置 OVERLAPPED
		// 后复用是安全的。
		ctx.overlapped = OVERLAPPED{};
		ctx.overlapped.hEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
		if (ctx.overlapped.hEvent == nullptr)
		{
			ctx.dirHandle.reset();
			return false;
		}

		if (!IssueRead(ctx))
		{
			// 发起监控失败：保持降级（轮询），由后续重枚举再次尝试恢复。
			CloseHandle(ctx.overlapped.hEvent);
			ctx.overlapped.hEvent = nullptr;
			ctx.dirHandle.reset();
			return false;
		}

		ctx.active = true;
		pollSet.erase(ctx.directory);
		return true;
	};

	// 为目录建立监控上下文；失败或超出手柄上限时降级为轮询。
	// 目录已在监控中则跳过（供周期刷新去重）；已降级（active=false）的
	// 目录在此恢复事件监控——降级不再是一去不回。
	auto addWatchDir = [&](const fs::path& dir)
	{
		for (const auto& ctx : contexts)
		{
			if (ctx->directory != dir)
			{
				continue;
			}
			if (ctx->active)
			{
				return;
			}
			if (ctx->readPending)
			{
				// 退役上下文（取消未被确认完成）：OVERLAPPED 不可复用，
				// 无法恢复事件监控，目录保持轮询。
				return;
			}
			// 已降级目录：句柄名额充足时恢复事件监控；否则保持轮询，
			// 待名额释放 / 下次重枚举时再次尝试。
			if (activeContextCount() >= MAXIMUM_WAIT_OBJECTS - 1)
			{
				return;
			}
			tryActivate(*ctx);
			return;
		}

		// WaitForMultipleObjects 上限 64，其中 1 个为停止事件，最多监控 63 个目录。
		// 超出上限的目录降级轮询，避免静默丢弃。
		if (activeContextCount() >= MAXIMUM_WAIT_OBJECTS - 1)
		{
			pollSet.insert(dir);
			return;
		}

		auto ctx = std::make_unique<WatchContext>();
		ctx->directory = dir;
		ctx->buffer.resize(NOTIFY_BUFFER_SIZE);

		if (!tryActivate(*ctx))
		{
			// 无法建立监控：降级为轮询，保证该目录仍被处理，不影响其他目录。
			pollSet.insert(dir);
			return;
		}

		contexts.push_back(std::move(ctx));
	};

	for (const auto& dir : watchDirs)
	{
		addWatchDir(dir);
	}

	const bool refreshEnabled = static_cast<bool>(onRefresh);
	const ULONGLONG base = GetTickCount64();

	// 轮询调度：采用“绝对截止时刻”而非每轮固定超时，原因有二：
	//   1. 避免周期漂移：若某次轮询本身耗时（如 20s），固定 60s 超时会让实际周期
	//      变成 80s。用截止时刻推进（deadline += 间隔）可保持稳定的 60s 节拍。
	//   2. 避免文件事件重置轮询计时：本地事件频繁触发时，固定超时会不断重新计时，
	//      可能使轮询迟迟不发生；用截止时刻则不受事件影响。
	bool hasPoll = !pollSet.empty();
	ULONGLONG nextPollTick = hasPoll ? (base + constants::POLL_INTERVAL_MS) : 0;

	// 目录刷新调度：与轮询同理使用绝对截止时刻。
	ULONGLONG nextRefreshTick = refreshEnabled
		? (base + constants::REENUM_INTERVAL_MS) : 0;

	// 轮询集合由空转非空时，确保轮询调度立即生效。
	auto ensurePollScheduled = [&]()
	{
		if (!hasPoll && !pollSet.empty())
		{
			hasPoll = true;
			nextPollTick = GetTickCount64() + constants::POLL_INTERVAL_MS;
		}
	};
	ensurePollScheduled();

	// 运行中监控失效时的降级动作：该目录转入轮询，保证仍被处理。
	// 句柄数组每轮重建，此处无需同步修改等待数组。
	auto downgradeToPoll = [&](WatchContext& ctx)
	{
		ctx.active = false;
		pollSet.insert(ctx.directory);
		ensurePollScheduled();

		// 先取消挂起的异步 IO（若有），并有界确认其完成，再关闭句柄 / 事件。
		// 正常流程下本函数仅在"上一次异步读取已完成"后调用（GetOverlappedResult
		// 已取回结果、readPending 为 false，OVERLAPPED 已不被内核引用）；
		// 防御性地保留在途分支：CancelIo 只是"请求取消"，确认完成前不得
		// 关闭 / 复用 OVERLAPPED（微软文档要求）。
		if (ctx.dirHandle.valid())
		{
			CancelIo(ctx.dirHandle);
		}

		if (ctx.readPending && ctx.overlapped.hEvent)
		{
			if (WaitForSingleObject(ctx.overlapped.hEvent,
				constants::WATCH_CANCEL_COMPLETE_TIMEOUT_MS) == WAIT_OBJECT_0)
			{
				// 取消已确认完成：OVERLAPPED 可安全关闭 / 复用。
				ctx.readPending = false;
			}
			else
			{
				// 超时：provider 未确认取消完成 → 上下文退役。OVERLAPPED
				// 整体（含 hEvent 字段）与句柄一律不再修改，等待 Run 退出
				// 时由 CleanupGuard 统一收口（届时仍超时则原样移交
				// m_retiredContexts，保留至进程退出）。目录继续走轮询，
				// 重枚举时 addWatchDir 会跳过退役上下文。
				return;
			}
		}

		if (ctx.dirHandle.valid())
		{
			ctx.dirHandle.reset();
		}
		if (ctx.overlapped.hEvent)
		{
			CloseHandle(ctx.overlapped.hEvent);
			ctx.overlapped.hEvent = nullptr;
		}
	};

	// 清理守卫：正常返回或任何异常退出路径（含回调异常）都会执行清理——
	// 取消未完成的 IO 并关闭各目录事件句柄，避免事件句柄泄漏与挂起的
	// 异步 IO 无人回收。异常本身继续向上传播，由工作线程顶层防护
	// 走 ShutdownAfterWorkerFailure 上报 SERVICE_STOPPED。
	//
	// 每个上下文按"取消 + 有界确认"决定处置：
	//   - 确认完成（正常情况，本地文件系统下取消在 CancelIo 内同步完成，
	//     事件立即置位）→ OVERLAPPED 已不被内核引用，关闭句柄 / 事件后
	//     上下文随 contexts 析构正常释放；
	//   - 超时未确认（provider 不响应取消）→ 上下文"原样退役"：其
	//     OVERLAPPED（含 hEvent 字段）仍可能被内核引用，不得再做任何
	//     修改，完整上下文（含句柄）移交 m_retiredContexts 保留至进程
	//     生命周期结束。宁可小量泄漏，绝不把内核仍可能写入的内存当作
	//     普通内存释放。
	struct CleanupGuard
	{
		std::vector<std::unique_ptr<WatchContext>>& contexts;
		std::vector<std::unique_ptr<WatchContext>>& retiredContexts;

		~CleanupGuard()
		{
			for (auto& ctx : contexts)
			{
				if (ctx->dirHandle.valid())
				{
					CancelIo(ctx->dirHandle);
				}

				bool confirmed = !ctx->readPending;
				if (ctx->readPending && ctx->overlapped.hEvent)
				{
					// 有界确认：CancelIo 只是"请求取消"，被取消的读取
					// 仍需完成；确认完成前不得释放其 OVERLAPPED。
					confirmed = WaitForSingleObject(ctx->overlapped.hEvent,
						constants::WATCH_CANCEL_COMPLETE_TIMEOUT_MS) == WAIT_OBJECT_0;
				}

				if (!confirmed)
				{
					// 退役：I/O 仍可能 pending——OVERLAPPED 整体不得再被
					// 修改（含 hEvent 字段），句柄亦保留，完整上下文原样
					// 移交，内存存活至进程退出，由操作系统回收。
					// 先 release 再入容器：若 push_back 因分配失败抛出
					//（vector 对 noexcept 移动类型保证失败时元素未被移动），
					// raw 在此有意不释放，进入进程级泄漏——宁可泄漏，
					// 不可释放仍可能被内核引用的 OVERLAPPED。
					WatchContext* raw = ctx.release();
					try
					{
						retiredContexts.push_back(
							std::unique_ptr<WatchContext>(raw));
					}
					catch (...)
					{
						// 极端 OOM 下的有意泄漏（见上）。
					}
					continue;
				}

				// 已确认完成：OVERLAPPED 不再被内核引用，可安全关闭
				// 句柄 / 事件并随 contexts 析构释放。
				if (ctx->dirHandle.valid())
				{
					ctx->dirHandle.reset();
				}
				if (ctx->overlapped.hEvent)
				{
					CloseHandle(ctx->overlapped.hEvent);
					ctx->overlapped.hEvent = nullptr;
				}
			}
		}
	} cleanupGuard{contexts, m_retiredContexts};

	// 进入循环前先立即执行一次轮询，使远程桌面开机即被处理（而非等一个周期）。
	if (hasPoll && onPoll)
	{
		onPoll(pollSet);
	}

	// 主等待循环。
	for (;;)
	{
		// 每轮重建等待句柄数组：索引 0 固定为停止事件，其后为活跃上下文的事件。
		// 重建成本 O(目录数)，可忽略；同时天然支持运行中降级 / 新增目录。
		std::vector<HANDLE> waitHandles;
		waitHandles.reserve(contexts.size() + 1);
		waitHandles.push_back(m_stopEvent);
		std::vector<WatchContext*> active;
		active.reserve(contexts.size());
		for (const auto& ctx : contexts)
		{
			if (ctx->active && waitHandles.size() < MAXIMUM_WAIT_OBJECTS)
			{
				waitHandles.push_back(ctx->overlapped.hEvent);
				active.push_back(ctx.get());
			}
		}

		// 计算本次等待时长：取轮询 / 刷新截止时刻中更近者。
		// 显式判断 now >= tick 后再计算差值，防御式写法，
		// 避免后续维护修改调度逻辑时出现无符号下溢。
		DWORD waitTimeout = INFINITE;
		{
			ULONGLONG now = GetTickCount64();
			if (hasPoll)
			{
				DWORD pollWait = (now >= nextPollTick)
					? 0 : static_cast<DWORD>(nextPollTick - now);
				waitTimeout = (std::min)(waitTimeout, pollWait);
			}
			if (refreshEnabled)
			{
				DWORD refreshWait = (now >= nextRefreshTick)
					? 0 : static_cast<DWORD>(nextRefreshTick - now);
				waitTimeout = (std::min)(waitTimeout, refreshWait);
			}
		}

		DWORD count = static_cast<DWORD>(waitHandles.size());
		DWORD result = WaitForMultipleObjects(count, waitHandles.data(), FALSE, waitTimeout);

		// 停止事件触发 -> 退出循环。
		if (result == WAIT_OBJECT_0)
		{
			break;
		}

		// 截止时刻到达 -> 触发对应的轮询 / 刷新，并推进下一个截止时刻。
		if (result == WAIT_TIMEOUT)
		{
			ULONGLONG now = GetTickCount64();

			if (hasPoll && now >= nextPollTick)
			{
				if (onPoll)
				{
					onPoll(pollSet);
				}

				// 按固定间隔推进截止时刻，保持稳定节拍。
				// 若处理耗时超过一个间隔（截止时刻已落后于当前时间），
				// 则以当前时间为基准重设，避免连续补偿式的突发。
				nextPollTick += constants::POLL_INTERVAL_MS;
				if (nextPollTick <= now)
				{
					nextPollTick = now + constants::POLL_INTERVAL_MS;
				}
			}

			if (refreshEnabled && now >= nextRefreshTick)
			{
				// 周期重枚举：登记新发现的目录（已存在的自动去重 / 跳过），
				// 并处理重新分类（轮询 → 事件监控）的目录迁移。
				DirSets sets = onRefresh();
				for (const auto& d : sets.watchDirs)
				{
					addWatchDir(d);
				}
				for (const auto& d : sets.removePollDirs)
				{
					pollSet.erase(d);
				}
				for (const auto& d : sets.pollDirs)
				{
					pollSet.insert(d);
				}
				if (pollSet.empty())
				{
					hasPoll = false;
				}
				ensurePollScheduled();

				nextRefreshTick += constants::REENUM_INTERVAL_MS;
				if (nextRefreshTick <= now)
				{
					nextRefreshTick = now + constants::REENUM_INTERVAL_MS;
				}
			}
			continue;
		}

		// 某个目录事件触发。换算为活跃上下文索引（减去停止事件占位）。
		if (result > WAIT_OBJECT_0 && result < WAIT_OBJECT_0 + count)
		{
			size_t idx = result - WAIT_OBJECT_0 - 1;
			if (idx >= active.size())
			{
				continue;
			}

			WatchContext& ctx = *active[idx];

			// 取回本次异步读取的结果。
			DWORD bytesReturned = 0;
			bool haveResult =
				GetOverlappedResult(ctx.dirHandle, &ctx.overlapped, &bytesReturned, FALSE) != FALSE;

			// 该次读取已结束（无论成败，事件已置位）：OVERLAPPED 不再被
			// 内核引用，允许后续关闭 / 复用。（防御：ERROR_IO_INCOMPLETE
			// 表示仍在途，保留 readPending 标记避免误复用。）
			if (haveResult || GetLastError() != ERROR_IO_INCOMPLETE)
			{
				ctx.readPending = false;
			}

			// 关键时序：先重新挂载监控、再执行去抖 / 业务处理。
			// 若反过来，去抖与处理窗口内产生的变更没有 pending IO 承接，
			// 会加重溢出风险、拖慢事件可见性。通知数据先拷贝到快照，
			// 避免与新发起的读取共用缓冲区。
			if (haveResult && bytesReturned > 0)
			{
				std::vector<BYTE> snapshot(
					ctx.buffer.begin(), ctx.buffer.begin() + bytesReturned);

				if (!IssueRead(ctx))
				{
					// 重挂失败：降级为轮询；已捕获的快照仍会被处理。
					downgradeToPoll(ctx);
				}

				HandleNotifications(ctx, snapshot, onChange);
			}
			else if (haveResult)
			{
				// 变更过多导致缓冲溢出，无法得知具体文件。
				// 先重挂监控，再回调整目录重扫，避免批量变更被静默漏掉。
				if (!IssueRead(ctx))
				{
					downgradeToPoll(ctx);
				}
				if (onRescan)
				{
					onRescan(std::set<fs::path>{ctx.directory});
				}
			}
			else
			{
				// 读取结果失败。主流实现（NTFS 等）中缓冲溢出以
				// STATUS_NOTIFY_ENUM_DIR（成功状态）+ 0 字节完成，即
				// GetOverlappedResult 返回 TRUE，落入上面的 onRescan 分支；
				// 但个别文件系统 provider 可能以失败 + ERROR_NOTIFY_ENUM_DIR
				// 形式返回。两种形态都必须整目录重扫，否则溢出期间发生的
				// 批量变更会被静默漏掉。
				DWORD error = GetLastError();
				if (error == ERROR_NOTIFY_ENUM_DIR)
				{
					if (!IssueRead(ctx))
					{
						downgradeToPoll(ctx);
					}
					if (onRescan)
					{
						onRescan(std::set<fs::path>{ctx.directory});
					}
				}
				else
				{
					// 其他错误：保持监控续挂。
					if (!IssueRead(ctx))
					{
						downgradeToPoll(ctx);
					}
				}
			}
		}
		else
		{
			// WAIT_FAILED 或异常返回：等待句柄数组已损坏（正常单线程
			// 流程不应发生）。抛出异常交由工作线程顶层防护统一上报
			// SERVICE_STOPPED，避免服务静默"假活"。
			throw std::runtime_error(
				"DirectoryWatcher: WaitForMultipleObjects failed unexpectedly.");
		}
	}

	// （清理逻辑已移至 CleanupGuard 析构：正常返回与异常退出路径都会执行。）
}
