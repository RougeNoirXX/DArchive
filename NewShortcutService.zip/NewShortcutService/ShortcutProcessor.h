#pragma once

#include "OperationReport.h"
#include "ShortcutLink.h"

#include <filesystem>
#include <map>
#include <set>
#include <string>

// =============================================================================
// ShortcutProcessor.h
// -----------------------------------------------------------------------------
// 服务的核心业务逻辑：处理桌面上的快捷方式。
//
// 两种入口：
//   - ScanAll()      : 启动时的全量扫描，遍历所有桌面并处理，最后清理公共桌面。
//   - ProcessSingle(): 实时监控回调，处理单个新增 / 变更的 .lnk 文件。
//
// 处理规则（对每个 .lnk）：
//   - 读取失败（COM 出错）      -> 安全起见不做任何操作。
//   - 目标无法解析（未知）      -> 保留原位。
//   - 特殊快捷方式（CLSID 等）  -> 若目标为空则删除，否则保留原位。
//   - 普通快捷方式             -> 搬运到公共桌面（重名自动追加 _N 后缀）。
//   - 公共桌面上的空目标快捷方式 -> 删除。
//
// 搬运前去重：
//   应用升级等场景会再次在用户桌面重建已被搬走的快捷方式，若不处理会
//   在公共桌面累积多个同目标副本（_N 后缀）。搬运前先比对公共桌面索引，
//   命中“同目标 + 同参数 + 文件名同族”的条目时直接移除源副本而不搬运。
//
// COM 说明：本类方法内部不负责 CoInitialize / CoUninitialize，
//           要求调用线程已完成 COM 初始化（由工作线程统一管理）。
// =============================================================================

class ShortcutProcessor
{
public:
	// 处理给定的一组本地桌面目录并清理公共桌面（启动全量扫描用）。
	// 仅接收“本地”桌面；远程 / 重定向桌面由 ScanDirectories 经轮询处理。
	OperationReport ScanAll(const std::set<std::filesystem::path>& localDesktops);

	// 扫描指定的一组桌面目录并处理其中的 .lnk（复用单个 LinkReader）。
	// 用于远程 / 重定向桌面的定时轮询：调用方负责在调用前完成可达性门禁。
	// 包含公共桌面清理
	OperationReport ScanDirectories(const std::set<std::filesystem::path>& desktops);

	// 处理单个快捷方式文件（供目录监控回调使用）。
	// 若该文件不是 .lnk、已不存在或位于公共桌面本身，则不处理。
	OperationReport ProcessSingle(const std::filesystem::path& shortcut_path);

	// 重建公共桌面快捷方式索引（去重比对用）。
	// 批量处理（ScanAll / ScanDirectories）内部自动调用；
	// 事件驱动的整批处理（onChange）应在批次开始前调用一次。
	void RefreshPublicIndex();

private:
	// 处理某个桌面目录下的全部 .lnk，结果写入 report。
	// reader 为复用的快捷方式读取器，避免逐个文件重建 COM 对象。
	void ProcessDesktop(const std::filesystem::path& desktop,
	                    shortcut::LinkReader& reader,
	                    OperationReport& report);

	// 处理单个 .lnk 的核心逻辑（移动 / 删除判定），结果写入 report。
	// dest_root 为搬运目标根目录（公共桌面）。
	void ProcessShortcut(const std::filesystem::path& shortcut,
	                     const std::filesystem::path& dest_root,
	                     shortcut::LinkReader& reader,
	                     OperationReport& report);

	// 清理公共桌面中失效的快捷方式，结果写入 report。
	void CleanupPublicDesktop(shortcut::LinkReader& reader, OperationReport& report);

	// 公共桌面快捷方式索引：归一化去重键（目标|参数）-> 公共桌面上的文件名。
	// 由 RefreshPublicIndex 重建；搬运 / 删除时增量维护。
	std::map<std::wstring, std::wstring> m_publicIndex;
};
