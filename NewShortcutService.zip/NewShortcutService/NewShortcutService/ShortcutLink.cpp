#include "ShortcutLink.h"

#include <windows.h>
#include <shlobj.h>
#include <objbase.h>
#include <wrl/client.h>
#include <utility>

#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")

// =============================================================================
// ShortcutLink.cpp
// -----------------------------------------------------------------------------
// 使用 IShellLinkW + IPersistFile 一次性加载 .lnk 并解析目标路径，
// 由目标路径推断“空目标”“特殊快捷方式”“目标是否存在”“是否失效”等标记。
// =============================================================================

namespace shortcut
{
	namespace
	{
		// 判断给定路径在磁盘上是否存在（文件或目录均可）。
		bool PathExistsOnDisk(const std::wstring& path)
		{
			if (path.empty())
			{
				return false;
			}

			// 目标可能包含环境变量（如 %ProgramFiles%），需先展开再判断。
			// 优化：仅当路径中出现 '%' 时才调用 ExpandEnvironmentStringsW，
			//       绝大多数快捷方式目标为绝对路径，可省去一次字符串处理。
			const wchar_t* check = path.c_str();
			wchar_t expanded[MAX_PATH * 2] = {0};
			if (path.find(L'%') != std::wstring::npos)
			{
				DWORD n = ExpandEnvironmentStringsW(
					path.c_str(), expanded, static_cast<DWORD>(std::size(expanded)));
				if (n > 0 && n <= std::size(expanded))
				{
					check = expanded;
				}
			}

			DWORD attrs = GetFileAttributesW(check);
			return attrs != INVALID_FILE_ATTRIBUTES;
		}

		// 从已加载的 IShellLinkW 中解析出 LinkInfo（不含 loaded 标记的设置）。
		// 调用方需保证 psl 已成功 Load 某个 .lnk 文件。
		void ParseLoadedLink(IShellLinkW* psl, LinkInfo& info)
		{
			// 读取目标路径（原始路径，不做自动解析 / 修复，避免误改）。
			// 注意：即便 GetPath 返回失败，target 缓冲也可能保持为空，视为“空目标”。
			wchar_t target[MAX_PATH] = {0};
			psl->GetPath(target, MAX_PATH, nullptr, SLGP_RAWPATH);

			info.target = target;

			// 判定空目标。
			info.empty_target = (target[0] == L'\0');

			// 判定特殊快捷方式：目标为空、包含 "::{" 或以 "::" 开头，
			// 均视为 shell 命名空间对象 / 不可搬运项。
			// 注：C++17 无 wstring_view::starts_with，用 rfind(..., 0) 等价判断前缀。
			std::wstring_view view(info.target);
			info.special =
				view.empty() ||
				view.find(L"::{") != std::wstring_view::npos ||
				view.rfind(L"::", 0) == 0;

			// 判定目标是否真实存在于磁盘。
			// 仅对普通文件系统路径检查；特殊 / 空目标无需检查（也无法检查）。
			if (!info.special && !info.empty_target)
			{
				info.target_exists = PathExistsOnDisk(info.target);
			}

			// 判定是否为失效快捷方式：
			//   - 目标为空                       -> 失效
			//   - 目标为普通路径但文件不存在      -> 失效（例如程序被卸载）
			//   - 特殊快捷方式（如“此电脑”）      -> 不算失效
			if (info.special)
			{
				info.is_dangling = info.empty_target;
			}
			else
			{
				info.is_dangling = info.empty_target || !info.target_exists;
			}
		}
	}

	LinkInfo ReadLink(const std::filesystem::path& shortcut_path)
	{
		LinkReader reader;
		return reader.Read(shortcut_path);
	}

	// PImpl：持有真实的 COM 对象。定义在 .cpp 中，头文件无需引入 COM 头，
	// 同时此处保持完全的类型安全（ComPtr 自动管理引用计数与释放）。
	struct LinkReader::Impl
	{
		Microsoft::WRL::ComPtr<IShellLinkW> shell_link;
		Microsoft::WRL::ComPtr<IPersistFile> persist_file;

		// 确保内部 COM 对象已创建，成功返回 true。首次调用时惰性创建。
		bool EnsureCreated()
		{
			if (shell_link && persist_file)
			{
				return true;
			}

			// 创建 ShellLink COM 对象。
			Microsoft::WRL::ComPtr<IShellLinkW> psl;
			HRESULT hr = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER,
			                              IID_PPV_ARGS(&psl));
			if (FAILED(hr))
			{
				return false;
			}

			// 获取 IPersistFile 接口用于从磁盘加载 .lnk 文件。
			Microsoft::WRL::ComPtr<IPersistFile> ppf;
			hr = psl.As(&ppf);
			if (FAILED(hr))
			{
				return false;
			}

			shell_link = std::move(psl);
			persist_file = std::move(ppf);
			return true;
		}
	};

	LinkReader::LinkReader() : impl_(std::make_unique<Impl>())
	{
	}

	// 析构定义在此处（.cpp）：Impl 此时为完整类型，unique_ptr 可正确销毁。
	LinkReader::~LinkReader() = default;

	LinkInfo LinkReader::Read(const std::filesystem::path& shortcut_path)
	{
		LinkInfo info;

		if (!impl_->EnsureCreated())
		{
			// COM 创建失败：loaded 保持 false，交由上层按安全策略处理。
			return info;
		}

		// 以只读方式加载快捷方式文件。
		HRESULT hr = impl_->persist_file->Load(shortcut_path.c_str(), STGM_READ);
		if (FAILED(hr))
		{
			return info;
		}

		// 加载成功，解析内容。
		info.loaded = true;
		ParseLoadedLink(impl_->shell_link.Get(), info);
		return info;
	}
}
