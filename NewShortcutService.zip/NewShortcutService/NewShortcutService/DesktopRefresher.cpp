#include "DesktopRefresher.h"

#include "Constants.h"
#include "WinHandles.h"

#include <windows.h>
#include <wtsapi32.h>
#include <userenv.h>
#include <string>
#include <vector>

#pragma comment(lib, "wtsapi32.lib")
#pragma comment(lib, "userenv.lib")
#pragma comment(lib, "advapi32.lib")

// =============================================================================
// DesktopRefresher.cpp
// -----------------------------------------------------------------------------
// 跨会话执行桌面刷新命令的具体实现。
// =============================================================================

namespace refresh
{
	namespace
	{
		// WTS 会话信息数组的 RAII 封装（需用 WTSFreeMemory 释放）。
		class WtsSessionInfo
		{
		public:
			WtsSessionInfo() = default;

			~WtsSessionInfo()
			{
				if (info_)
				{
					WTSFreeMemory(info_);
				}
			}

			WtsSessionInfo(const WtsSessionInfo&) = delete;
			WtsSessionInfo& operator=(const WtsSessionInfo&) = delete;

			// 枚举会话，成功返回 true。
			bool Enumerate()
			{
				return WTSEnumerateSessionsW(
					WTS_CURRENT_SERVER_HANDLE, 0, 1, &info_, &count_) != FALSE;
			}

			PWTS_SESSION_INFOW data() const noexcept { return info_; }
			DWORD count() const noexcept { return count_; }

		private:
			PWTS_SESSION_INFOW info_ = nullptr;
			DWORD count_ = 0;
		};

		// 环境块的 RAII 封装（需用 DestroyEnvironmentBlock 释放）。
		class EnvironmentBlock
		{
		public:
			explicit EnvironmentBlock(HANDLE token)
			{
				// 基于用户令牌创建环境块，确保 %PATH% 等能正确解析 ie4uinit.exe。
				if (!CreateEnvironmentBlock(&block_, token, FALSE))
				{
					block_ = nullptr;
				}
			}

			~EnvironmentBlock()
			{
				if (block_)
				{
					DestroyEnvironmentBlock(block_);
				}
			}

			EnvironmentBlock(const EnvironmentBlock&) = delete;
			EnvironmentBlock& operator=(const EnvironmentBlock&) = delete;

			LPVOID get() const noexcept { return block_; }

		private:
			LPVOID block_ = nullptr;
		};

		// 在指定会话中以其用户身份运行一次刷新命令。
		void RefreshOneSession(DWORD sessionId)
		{
			// 取该会话登录用户的主令牌。LocalSystem 才有权限调用此 API。
			HANDLE rawUserToken = nullptr;
			if (!WTSQueryUserToken(sessionId, &rawUserToken))
			{
				return;
			}
			winhandles::ScopedHandle userToken(rawUserToken);

			// 复制为可用于 CreateProcessAsUser 的主令牌。
			HANDLE rawDupToken = nullptr;
			if (!DuplicateTokenEx(userToken, MAXIMUM_ALLOWED, nullptr,
			                      SecurityImpersonation, TokenPrimary, &rawDupToken))
			{
				return;
			}
			winhandles::ScopedHandle dupToken(rawDupToken);

			// 创建用户环境块。
			EnvironmentBlock env(dupToken);

			// 构造命令行：ie4uinit.exe -show。
			// CreateProcessAsUserW 的命令行参数需可写缓冲，故拷贝到 vector。
			std::wstring cmdline = std::wstring(constants::REFRESH_COMMAND) +
				L" " + std::wstring(constants::REFRESH_ARGUMENTS);
			std::vector<wchar_t> cmdBuf(cmdline.begin(), cmdline.end());
			cmdBuf.push_back(L'\0');

			STARTUPINFOW si{};
			si.cb = sizeof(si);
			// 指定目标交互桌面，确保进程运行在用户的可见桌面上。
			wchar_t desktopName[] = L"winsta0\\default";
			si.lpDesktop = desktopName;

			PROCESS_INFORMATION pi{};

			DWORD creationFlags = CREATE_UNICODE_ENVIRONMENT | CREATE_NO_WINDOW;

			BOOL created = CreateProcessAsUserW(
				dupToken,           // 用户令牌
				nullptr,            // 应用名（从命令行解析）
				cmdBuf.data(),      // 命令行
				nullptr,            // 进程安全属性
				nullptr,            // 线程安全属性
				FALSE,              // 不继承句柄
				creationFlags,      // 创建标志
				env.get(),          // 环境块（可能为 nullptr）
				nullptr,            // 当前目录
				&si,
				&pi);

			if (created)
			{
				// 立即关闭进程 / 线程句柄，无需等待刷新进程结束。
				winhandles::ScopedHandle process(pi.hProcess);
				winhandles::ScopedHandle thread(pi.hThread);
			}
		}
	}

	void RefreshActiveSessions()
	{
		WtsSessionInfo sessions;
		if (!sessions.Enumerate())
		{
			return;
		}

		PWTS_SESSION_INFOW list = sessions.data();
		for (DWORD i = 0; i < sessions.count(); ++i)
		{
			// 仅对活动（已登录并处于连接状态）会话执行刷新。
			if (list[i].State == WTSActive)
			{
				RefreshOneSession(list[i].SessionId);
			}
		}
	}
}
