#include "WindowsServiceImpl.h"

#include "Constants.h"
#include "DesktopEnumerator.h"
#include "DesktopRefresher.h"
#include "OperationReport.h"
#include "ShortcutProcessor.h"

#include <objbase.h>
#include <string>

// =============================================================================
// WindowsServiceImpl.cpp
// -----------------------------------------------------------------------------
// 服务实现的编排逻辑。
// =============================================================================

CWindowsServiceImpl::CWindowsServiceImpl(const wchar_t* serviceName,
                                         bool canStop,
                                         bool canShutdown,
                                         bool canPauseContinue)
	: CServiceBase(serviceName, canStop, canShutdown, canPauseContinue)
{
}

CWindowsServiceImpl::~CWindowsServiceImpl() noexcept
{
	// 保险起见：析构时确保监控停止、工作线程结束。
	// （正常路径下 OnStop 已完成清理，这里是兜底。）
	m_stopping.store(true, std::memory_order_release);
	m_watcher.Stop();

	// std::thread 不会在析构时自动 join，必须显式 join，否则析构会 std::terminate。
	if (m_worker.joinable())
	{
		m_worker.join();
	}
}

void CWindowsServiceImpl::OnStart(DWORD, wchar_t**)
{
	// 启动工作线程，OnStart 需尽快返回以便 SCM 收到 RUNNING 状态。
	m_worker = std::thread([this] { ServiceWorkerThread(); });
}

void CWindowsServiceImpl::HandleReport(const OperationReport& report)
{
	if (!report.HasChanges())
	{
		return;
	}

	// 写入事件日志摘要。
	std::wstring summary;
	report.BuildSummary(summary);
	WriteEventLogEntry(summary.c_str(), EVENTLOG_INFORMATION_TYPE);

	// 注意：桌面刷新不在此处触发，改由调用方在“整轮 / 整批”处理完成后统一刷新一次，
	// 避免批量处理时反复 spawn ie4uinit.exe。
}

void CWindowsServiceImpl::ServiceWorkerThread()
{
	// 工作线程内统一初始化 COM（快捷方式读取依赖 COM）。
	// 使用多线程套间以适配后续在同一线程中的多次 COM 调用。
	HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
	bool comInitialized = SUCCEEDED(hr);

	struct CoGuard
	{
		bool active;
		~CoGuard() { if (active) CoUninitialize(); }
	} guard{comInitialized};

	ShortcutProcessor processor;

	// ---- 阶段一：启动时全量扫描 ----
	{
		OperationReport report = processor.ScanAll();
		HandleReport(report);
		// 全量扫描后若有变更，统一刷新一次桌面（而非每个文件刷新一次）。
		if (report.HasChanges())
		{
			refresh::RefreshActiveSessions();
		}
	}

	// 若已请求停止，则不再进入监控。
	if (m_stopping.load(std::memory_order_acquire))
	{
		return;
	}

	// ---- 阶段二：进入实时监控 ----
	// 仅监控启动时已存在的桌面目录（新用户需重启服务）。
	auto desktops = desktop::EnumerateDesktops();

	// 额外把公共桌面纳入监控：直接向 C:\Users\Public\Desktop 拷贝失效快捷方式时，
	// 也需要触发清理。EnumerateDesktops 出于“不把它当搬运源”的目的排除了公共桌面，
	// 这里显式补上，由 ProcessSingle 内部对公共桌面只做失效清理、不搬运。
	{
		std::filesystem::path public_desktop(constants::PUBLIC_DESKTOP);
		std::error_code ec;
		if (std::filesystem::is_directory(public_desktop, ec))
		{
			desktops.insert(public_desktop);
		}
	}

	// 变更回调：处理本批所有 .lnk，最后仅刷新一次桌面。
	auto callback = [this, &processor](const std::set<std::filesystem::path>& paths)
	{
		bool anyChange = false;
		for (const auto& path : paths)
		{
			OperationReport report = processor.ProcessSingle(path);
			HandleReport(report);
			if (report.HasChanges())
			{
				anyChange = true;
			}
		}

		// 整批处理完成后，若确有变更，统一刷新一次桌面。
		if (anyChange)
		{
			refresh::RefreshActiveSessions();
		}
	};

	// Run 阻塞运行，直到 OnStop 调用 m_watcher.Stop()。
	m_watcher.Run(desktops, callback);
}

void CWindowsServiceImpl::OnStop()
{
	// 标记停止并即时唤醒监控循环。
	m_stopping.store(true, std::memory_order_release);
	m_watcher.Stop();

	// 等待工作线程退出，保证 OnStop 返回后线程确已结束。
	if (m_worker.joinable())
	{
		m_worker.join();
	}
}
