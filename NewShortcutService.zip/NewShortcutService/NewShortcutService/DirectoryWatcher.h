#pragma once

#include <filesystem>
#include <functional>
#include <set>
#include <vector>

#include <windows.h>

#include "WinHandles.h"

// =============================================================================
// DirectoryWatcher.h
// -----------------------------------------------------------------------------
// 基于 ReadDirectoryChangesW 的多目录实时监控器。
//
// 工作方式：
//   - 为每个被监控目录打开一个目录句柄，发起异步 ReadDirectoryChangesW。
//   - 用一个手动重置的“停止事件”与各目录的 OVERLAPPED 事件一起，
//     交给 WaitForMultipleObjects 等待。
//   - 某目录有变更时，取出变更项，对新增 / 改名 / 修改的 .lnk 文件，
//     经去抖后回调上层处理函数。
//   - 收到停止事件立即退出（停止响应即时，不再有 60 秒轮询延迟）。
//
// 线程模型：Run() 在调用线程内阻塞运行，直到 Stop() 被调用。
//           Stop() 可由任意线程安全调用。
// =============================================================================

class DirectoryWatcher
{
public:
	// 变更回调：参数为本批（经去抖合并、去重后）发生变更的文件路径集合。
	// 以“批”为单位回调，便于上层对整批处理完成后仅执行一次后续动作（如刷新桌面）。
	using ChangeCallback = std::function<void(const std::set<std::filesystem::path>&)>;

	DirectoryWatcher();
	~DirectoryWatcher();

	DirectoryWatcher(const DirectoryWatcher&) = delete;
	DirectoryWatcher& operator=(const DirectoryWatcher&) = delete;

	// 开始监控给定目录集合并阻塞运行，直到 Stop() 被调用。
	// callback 会在本函数所在线程中被调用。
	void Run(const std::set<std::filesystem::path>& directories,
	         const ChangeCallback& callback);

	// 请求停止监控。可从其他线程调用；Run() 将尽快返回。
	void Stop() noexcept;

private:
	// 单个被监控目录的上下文。
	struct WatchContext
	{
		std::filesystem::path directory;         // 目录路径
		winhandles::ScopedHandle dirHandle;      // 目录句柄
		OVERLAPPED overlapped{};                 // 异步 IO 上下文
		std::vector<BYTE> buffer;                // 接收变更记录的缓冲区
	};

	// 对指定上下文发起一次异步读取，成功返回 true。
	bool IssueRead(WatchContext& ctx);

	// 处理某个目录读取完成后缓冲区中的变更记录。
	void HandleNotifications(WatchContext& ctx, DWORD bytesReturned,
	                         const ChangeCallback& callback);

	// 停止事件：手动重置，触发后所有等待立即返回。
	winhandles::ScopedHandle m_stopEvent;
};
