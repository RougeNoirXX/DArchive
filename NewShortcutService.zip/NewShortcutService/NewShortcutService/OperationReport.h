#pragma once

#include <string>
#include <vector>

// =============================================================================
// OperationReport.h
// -----------------------------------------------------------------------------
// 记录一次处理（扫描或单文件处理）所产生的操作结果，
// 用于汇总后写入 Windows 事件日志，并判断是否需要刷新桌面。
// =============================================================================

struct OperationReport
{
	// 被搬运到公共桌面的快捷方式数量。
	int moved_count = 0;

	// 被删除的（空目标）快捷方式数量。
	int deleted_count = 0;

	// 被搬运的文件名列表（仅文件名，用于日志展示）。
	std::vector<std::wstring> moved_files;

	// 被删除的文件名列表。
	std::vector<std::wstring> deleted_files;

	// 是否发生了任何实际变更（决定是否触发桌面刷新 / 写日志）。
	bool HasChanges() const noexcept
	{
		return moved_count > 0 || deleted_count > 0;
	}

	// 合并另一份报告（用于把多个桌面的处理结果汇总到一起）。
	void Merge(const OperationReport& other)
	{
		moved_count += other.moved_count;
		deleted_count += other.deleted_count;
		moved_files.insert(moved_files.end(),
		                   other.moved_files.begin(), other.moved_files.end());
		deleted_files.insert(deleted_files.end(),
		                     other.deleted_files.begin(), other.deleted_files.end());
	}

	// 构造用于事件日志的可读摘要文本。
	void BuildSummary(std::wstring& out) const
	{
		out.clear();

		// 预估容量并预留，减少拼接过程中的多次重分配。
		// 每个文件名行约 40 个宽字符，加上少量头部文字。
		const size_t estimated =
			(moved_files.size() + deleted_files.size()) * 40 + 64;
		out.reserve(estimated);

		if (moved_count > 0)
		{
			out += L"Moved " + std::to_wstring(moved_count) + L" shortcut(s):\r\n";
			for (const auto& f : moved_files)
			{
				out += L"  -> " + f + L"\r\n";
			}
		}

		if (deleted_count > 0)
		{
			out += L"Deleted " + std::to_wstring(deleted_count) + L" empty-target shortcut(s):\r\n";
			for (const auto& f : deleted_files)
			{
				out += L"  x  " + f + L"\r\n";
			}
		}
	}
};
