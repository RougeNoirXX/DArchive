#pragma once

#include "ServiceBase.h"
#include "DirectoryWatcher.h"

#include <atomic>
#include <thread>
#include <windows.h>

// =============================================================================
// WindowsServiceImpl.h
// -----------------------------------------------------------------------------
// 具体服务实现，串联各功能模块：
//   启动 -> 工作线程执行全量扫描 -> 进入目录实时监控 ->
//   收到变更处理单个快捷方式 -> 有变更则刷新桌面。
//   停止时通过监控器的停止事件即时唤醒工作线程退出。
//
// 相较原版：移除了 ThreadPool（单循环无需线程池），改用一个 std::thread；
//           轮询改为事件驱动，停止响应从最长 60 秒降为即时。
// =============================================================================

class CWindowsServiceImpl : public CServiceBase
{
public:
	explicit CWindowsServiceImpl(const wchar_t* serviceName,
	                             bool canStop = true,
	                             bool canShutdown = true,
	                             bool canPauseContinue = false);
	~CWindowsServiceImpl() noexcept override;

protected:
	void OnStart(DWORD argc, wchar_t** argv) override;
	void OnStop() override;

private:
	// 工作线程主体：全量扫描 + 进入实时监控循环。
	void ServiceWorkerThread();

	// 处理一次操作报告：有变更时写日志并刷新桌面。
	void HandleReport(const struct OperationReport& report);

	DirectoryWatcher m_watcher;   // 目录监控器
	std::thread m_worker;         // 工作线程
	std::atomic<bool> m_stopping{false};
};
