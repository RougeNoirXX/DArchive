#include "DesktopEnumerator.h"

#include "Constants.h"
#include "WinHandles.h"

#include <windows.h>

// =============================================================================
// DesktopEnumerator.cpp
// -----------------------------------------------------------------------------
// 三路来源合并收集桌面目录，任何一路出错都不影响其余来源（尽力而为）。
// =============================================================================

namespace fs = std::filesystem;

namespace desktop
{
	namespace
	{
		// ---------------------------------------------------------------------
		// 来源 1：扫描 C:\Users 下的真实用户目录。
		// 排除公共 / 系统 / 默认账户，仅保留存在 Desktop 子目录的普通用户。
		// ---------------------------------------------------------------------
		void CollectFromUsers(std::set<fs::path>& result)
		{
			if (!fs::exists(constants::USERS_ROOT) || !fs::is_directory(constants::USERS_ROOT))
			{
				return;
			}

			try
			{
				for (const auto& entry : fs::directory_iterator(constants::USERS_ROOT))
				{
					if (!entry.is_directory())
					{
						continue;
					}

					std::wstring name = entry.path().filename().wstring();

					// 跳过非用户目录：公共 / 管理员 / 全体用户 / 默认档案。
					// 注：C++17 无 wstring::starts_with，用 rfind(..., 0) 判断前缀。
					if (name == L"Public" ||
						name == L"Administrator" ||
						name == L"All Users" ||
						name.rfind(L"Default", 0) == 0)
					{
						continue;
					}

					fs::path desktop = entry.path() / L"Desktop";
					if (fs::is_directory(desktop))
					{
						result.insert(desktop);
					}
				}
			}
			catch (const fs::filesystem_error&)
			{
				// 枚举失败（权限 / IO）时忽略该来源，继续处理其余来源。
			}
		}

		// ---------------------------------------------------------------------
		// 来源 2：扫描 HarmonyOS 重定向根目录下每个子目录的 Desktop。
		// ---------------------------------------------------------------------
		void CollectFromRedirectRoot(std::set<fs::path>& result)
		{
			if (!fs::exists(constants::REDIRECT_ROOT) || !fs::is_directory(constants::REDIRECT_ROOT))
			{
				return;
			}

			try
			{
				for (const auto& entry : fs::directory_iterator(constants::REDIRECT_ROOT))
				{
					if (!entry.is_directory())
					{
						continue;
					}

					fs::path desktop = entry.path() / L"Desktop";
					if (fs::is_directory(desktop))
					{
						result.insert(desktop);
					}
				}
			}
			catch (const fs::filesystem_error&)
			{
				// 忽略该来源错误。
			}
		}

		// ---------------------------------------------------------------------
		// 来源 3：遍历 HKEY_USERS 下每个已加载用户配置单元，
		// 读取其 User Shell Folders\Desktop 项（可能含环境变量，需展开）。
		// 这样可覆盖桌面被重定向到自定义位置的场景。
		// ---------------------------------------------------------------------
		void CollectFromRegistry(std::set<fs::path>& result)
		{
			winhandles::RegKey hkUsers;
			if (RegOpenKeyExW(HKEY_USERS, nullptr, 0, KEY_READ, &hkUsers) != ERROR_SUCCESS)
			{
				return;
			}

			wchar_t sid[256];
			DWORD index = 0;
			while (RegEnumKeyW(hkUsers, index++, sid, 256) == ERROR_SUCCESS)
			{
				std::wstring subkey = std::wstring(sid) +
					L"\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders";

				winhandles::RegKey hkUser;
				if (RegOpenKeyExW(HKEY_USERS, subkey.c_str(), 0, KEY_READ, &hkUser) != ERROR_SUCCESS)
				{
					continue;
				}

				wchar_t value[MAX_PATH];
				DWORD size = sizeof(value);
				if (RegQueryValueExW(hkUser, L"Desktop", nullptr, nullptr,
				                     reinterpret_cast<LPBYTE>(value), &size) != ERROR_SUCCESS)
				{
					continue;
				}

				// User Shell Folders 中的值通常含 %USERPROFILE% 等环境变量，需展开。
				wchar_t expanded[MAX_PATH];
				if (ExpandEnvironmentStringsW(value, expanded, MAX_PATH) == 0)
				{
					continue;
				}

				fs::path desktop(expanded);
				// 排除 CLSID 形式的路径（以 "::" 开头），仅接受真实存在的目录。
				if (desktop.wstring().find(L"::") != 0 && fs::is_directory(desktop))
				{
					result.insert(desktop);
				}
			}
		}
	}

	std::set<fs::path> EnumerateDesktops()
	{
		std::set<fs::path> result;

		CollectFromUsers(result);
		CollectFromRedirectRoot(result);
		CollectFromRegistry(result);

		return result;
	}
}
