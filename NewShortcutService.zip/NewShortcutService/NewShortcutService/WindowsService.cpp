#include <windows.h>

#include <iostream>
#include <stdexcept>
#include <string_view>

#include "Constants.h"
#include "ServiceBase.h"
#include "ServiceInstaller.h"
#include "WindowsServiceImpl.h"

// =============================================================================
// WindowsService.cpp
// -----------------------------------------------------------------------------
// 程序入口。支持三种运行方式：
//   ShortcutService -install   安装并启动服务
//   ShortcutService -remove    停止并卸载服务
//   （无参数）                 作为服务被 SCM 拉起时进入服务分发循环
// =============================================================================

namespace
{
	// 打印命令行用法。
	void PrintUsage()
	{
		std::wcout << L"Parameters:\n"
			<< L"  -install  install and start the service.\n"
			<< L"  -remove   stop and remove the service.\n";
	}
}

int wmain(int argc, wchar_t* argv[])
{
	try
	{
		// 解析命令行参数（支持 - 或 / 前缀）。
		if (argc > 1 && argv[1] != nullptr)
		{
			std::wstring_view arg = argv[1];
			if (arg.size() > 1 && (arg[0] == L'-' || arg[0] == L'/'))
			{
				arg = arg.substr(1);

				if (arg == L"install")
				{
					if (!InstallService(
						constants::SERVICE_NAME.data(),
						constants::SERVICE_DISPLAY_NAME.data(),
						constants::SERVICE_START_TYPE,
						nullptr,                                 // 无依赖
						constants::SERVICE_ACCOUNT.data(),
						nullptr,                                 // LocalSystem 无需密码
						constants::SERVICE_DESCRIPTION.data()))
					{
						throw std::runtime_error("Service installation failed. (Run as Administrator?)");
					}
					std::wcout << L"Service installed successfully.\n";
					return 0;
				}

				if (arg == L"remove")
				{
					if (!UninstallService(constants::SERVICE_NAME.data()))
					{
						throw std::runtime_error("Service removal failed. (Run as Administrator?)");
					}
					std::wcout << L"Service removed successfully.\n";
					return 0;
				}
			}

			// 无法识别的参数：给出用法后退出。
			PrintUsage();
			return 0;
		}

		// 无参数：作为服务运行，进入 SCM 分发循环。
		CWindowsServiceImpl service(constants::SERVICE_NAME.data());
		if (!CServiceBase::Run(service))
		{
			DWORD error = GetLastError();
			// 若不是被 SCM 拉起（例如直接双击运行），会得到
			// ERROR_FAILED_SERVICE_CONTROLLER_CONNECT，此时提示用法。
			std::wcerr << L"Service failed to run. Error code: 0x"
				<< std::hex << error << std::dec << L"\n";
			PrintUsage();
			return static_cast<int>(error);
		}
		return 0;
	}
	catch (const std::exception& e)
	{
		std::wcerr << L"Exception: " << e.what() << L"\n";
		return 1;
	}
	catch (...)
	{
		std::wcerr << L"Unknown exception occurred.\n";
		return 1;
	}
}
