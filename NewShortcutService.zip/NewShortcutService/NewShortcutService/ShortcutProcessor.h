#pragma once

#include "OperationReport.h"
#include "ShortcutLink.h"

#include <filesystem>

// =============================================================================
// ShortcutProcessor.h
// -----------------------------------------------------------------------------
// 服务的核心业务逻辑：处理桌面上的快捷方式。
//
// 两种入口：
//   - ScanAll()      : 启动时的全量扫描，遍历所有桌面并处理，最后清理公共桌面。
//   - ProcessSingle(): 实时监控回调，处理单个新增 / 变更的 .lnk 文件。
//
// 处理规则（对每个 .lnk）：
//   - 读取失败（COM 出错）      -> 安全起见不做任何操作。
//   - 特殊快捷方式（CLSID 等）  -> 若目标为空则删除，否则保留原位。
//   - 普通快捷方式             -> 搬运到公共桌面（重名自动追加 _N 后缀）。
//   - 公共桌面上的空目标快捷方式 -> 删除。
//
// COM 说明：本类方法内部不负责 CoInitialize / CoUninitialize，
//           要求调用线程已完成 COM 初始化（由工作线程统一管理）。
// =============================================================================

class ShortcutProcessor
{
public:
	// 全量扫描：枚举所有桌面并处理其中的 .lnk，随后清理公共桌面的空目标项。
	// 返回本次所有操作的汇总报告。
	OperationReport ScanAll();

	// 处理单个快捷方式文件（供目录监控回调使用）。
	// 若该文件不是 .lnk、已不存在或位于公共桌面本身，则不处理。
	OperationReport ProcessSingle(const std::filesystem::path& shortcut_path);

private:
	// 处理某个桌面目录下的全部 .lnk，结果写入 report。
	// reader 为复用的快捷方式读取器，避免逐个文件重建 COM 对象。
	void ProcessDesktop(const std::filesystem::path& desktop,
	                    shortcut::LinkReader& reader,
	                    OperationReport& report);

	// 处理单个 .lnk 的核心逻辑（移动 / 删除判定），结果写入 report。
	// dest_root 为搬运目标根目录（公共桌面）。
	void ProcessShortcut(const std::filesystem::path& shortcut,
	                     const std::filesystem::path& dest_root,
	                     shortcut::LinkReader& reader,
	                     OperationReport& report);

	// 清理公共桌面中失效的快捷方式，结果写入 report。
	void CleanupPublicDesktop(shortcut::LinkReader& reader, OperationReport& report);
};
