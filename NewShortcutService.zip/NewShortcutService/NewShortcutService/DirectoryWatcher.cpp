#include "DirectoryWatcher.h"

#include "Constants.h"

#include <memory>
#include <stdexcept>
#include <cwctype>

// =============================================================================
// DirectoryWatcher.cpp
// -----------------------------------------------------------------------------
// 多目录异步监控实现。使用 WaitForMultipleObjects 同时等待“停止事件”与
// 各目录的完成事件，避免使用 IOCP 的额外复杂度（受监控目录数量有限）。
// =============================================================================

namespace fs = std::filesystem;

namespace
{
	// 单目录接收缓冲区大小（字节）。足够容纳一批变更记录。
	constexpr DWORD NOTIFY_BUFFER_SIZE = 64 * 1024;

	// 关注的变更类型：文件名（新增 / 删除 / 改名）与最后写入时间（内容写完）。
	constexpr DWORD NOTIFY_FILTER =
		FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE;

	// 判断文件名是否以 .lnk 结尾（大小写不敏感）。
	bool IsShortcutName(const std::wstring& name)
	{
		constexpr std::wstring_view ext = L".lnk";
		if (name.size() < ext.size())
		{
			return false;
		}
		std::wstring tail = name.substr(name.size() - ext.size());
		for (auto& c : tail)
		{
			c = static_cast<wchar_t>(std::towlower(c));
		}
		return tail == ext;
	}
}

DirectoryWatcher::DirectoryWatcher()
{
	// 创建手动重置、初始未触发的停止事件。
	m_stopEvent.reset(CreateEventW(nullptr, TRUE, FALSE, nullptr));
	if (!m_stopEvent.valid())
	{
		throw std::runtime_error("Failed to create stop event for DirectoryWatcher");
	}
}

DirectoryWatcher::~DirectoryWatcher() = default;

void DirectoryWatcher::Stop() noexcept
{
	if (m_stopEvent.valid())
	{
		SetEvent(m_stopEvent);
	}
}

bool DirectoryWatcher::IssueRead(WatchContext& ctx)
{
	// 发起异步目录变更读取；结果通过 ctx.overlapped.hEvent 通知。
	return ReadDirectoryChangesW(
		ctx.dirHandle,
		ctx.buffer.data(),
		static_cast<DWORD>(ctx.buffer.size()),
		FALSE,              // 不递归监控子目录（桌面为平铺结构）
		NOTIFY_FILTER,
		nullptr,
		&ctx.overlapped,
		nullptr) != FALSE;
}

void DirectoryWatcher::HandleNotifications(WatchContext& ctx, DWORD bytesReturned,
                                           const ChangeCallback& callback)
{
	// bytesReturned == 0 表示变更过多导致缓冲溢出，此时无法得知具体文件。
	// 作为兜底，直接回调整个目录（上层可选择重扫）；这里对每个 .lnk 无信息，
	// 故忽略，等待后续单独事件。简单起见此处仅处理有明确记录的情况。
	if (bytesReturned == 0)
	{
		return;
	}

	// 去重：同一批通知里同一文件可能出现多次。
	std::set<fs::path> touched;

	const BYTE* base = ctx.buffer.data();
	DWORD offset = 0;
	for (;;)
	{
		auto* info = reinterpret_cast<const FILE_NOTIFY_INFORMATION*>(base + offset);

		// 仅关注新增 / 改名到本目录 / 内容修改这几类动作。
		if (info->Action == FILE_ACTION_ADDED ||
			info->Action == FILE_ACTION_RENAMED_NEW_NAME ||
			info->Action == FILE_ACTION_MODIFIED)
		{
			// 文件名非以 NUL 结尾，长度以字节记，需换算为字符数。
			std::wstring name(info->FileName, info->FileNameLength / sizeof(wchar_t));
			if (IsShortcutName(name))
			{
				touched.insert(ctx.directory / name);
			}
		}

		if (info->NextEntryOffset == 0)
		{
			break;
		}
		offset += info->NextEntryOffset;
	}

	// 去抖：变更发生后短暂等待，避免处理仍在写入中的 .lnk，
	// 同时让连续多条通知合并（此处对本批已去重，延迟主要防写入未完成）。
	if (!touched.empty())
	{
		// 等待期间若收到停止信号则提前返回，不再处理。
		if (WaitForSingleObject(m_stopEvent, constants::DEBOUNCE_DELAY_MS) == WAIT_OBJECT_0)
		{
			return;
		}

		// 以整批为单位回调，交由上层统一处理并在处理后仅刷新一次桌面。
		callback(touched);
	}
}

void DirectoryWatcher::Run(const std::set<fs::path>& directories,
                           const ChangeCallback& callback)
{
	// 为每个目录建立监控上下文。
	std::vector<std::unique_ptr<WatchContext>> contexts;
	contexts.reserve(directories.size());

	for (const auto& dir : directories)
	{
		auto ctx = std::make_unique<WatchContext>();
		ctx->directory = dir;
		ctx->buffer.resize(NOTIFY_BUFFER_SIZE);

		// 以 FILE_FLAG_BACKUP_SEMANTICS 打开目录句柄（目录必需），
		// 并以 OVERLAPPED 方式进行异步读取。
		HANDLE h = CreateFileW(
			dir.c_str(),
			FILE_LIST_DIRECTORY,
			FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
			nullptr,
			OPEN_EXISTING,
			FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED,
			nullptr);
		if (h == INVALID_HANDLE_VALUE)
		{
			// 无法打开的目录跳过（可能权限不足），不影响其他目录。
			continue;
		}
		ctx->dirHandle.reset(h);

		// 为该目录的异步 IO 创建独立的自动重置事件。
		ctx->overlapped.hEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
		if (ctx->overlapped.hEvent == nullptr)
		{
			continue;
		}

		if (!IssueRead(*ctx))
		{
			CloseHandle(ctx->overlapped.hEvent);
			continue;
		}

		contexts.push_back(std::move(ctx));
	}

	// 构造等待句柄数组：索引 0 固定为停止事件，其后依次为各目录事件。
	// 注意：WaitForMultipleObjects 上限为 MAXIMUM_WAIT_OBJECTS(64)，
	// 其中含 1 个停止事件，故最多监控 63 个目录（桌面数量通常远小于此）。
	std::vector<HANDLE> waitHandles;
	waitHandles.push_back(m_stopEvent);
	for (const auto& ctx : contexts)
	{
		if (waitHandles.size() >= MAXIMUM_WAIT_OBJECTS)
		{
			break;
		}
		waitHandles.push_back(ctx->overlapped.hEvent);
	}

	// 主等待循环。
	for (;;)
	{
		DWORD count = static_cast<DWORD>(waitHandles.size());
		DWORD result = WaitForMultipleObjects(count, waitHandles.data(), FALSE, INFINITE);

		// 停止事件触发 -> 退出循环。
		if (result == WAIT_OBJECT_0)
		{
			break;
		}

		// 某个目录事件触发。换算为 contexts 索引（减去停止事件占位）。
		if (result > WAIT_OBJECT_0 && result < WAIT_OBJECT_0 + count)
		{
			size_t idx = result - WAIT_OBJECT_0 - 1;
			if (idx >= contexts.size())
			{
				continue;
			}

			WatchContext& ctx = *contexts[idx];

			// 取回本次异步读取的结果。
			DWORD bytesReturned = 0;
			if (GetOverlappedResult(ctx.dirHandle, &ctx.overlapped, &bytesReturned, FALSE))
			{
				HandleNotifications(ctx, bytesReturned, callback);
			}

			// 处理完再次发起监控读取，保持持续监控。
			if (!IssueRead(ctx))
			{
				// 重新发起失败：该目录后续不再触发，但不影响其他目录。
			}
		}
		else
		{
			// WAIT_FAILED 或异常返回：退出以避免忙等。
			break;
		}
	}

	// 清理：取消未完成的 IO 并关闭各目录事件句柄。
	for (auto& ctx : contexts)
	{
		if (ctx->dirHandle.valid())
		{
			CancelIo(ctx->dirHandle);
		}
		if (ctx->overlapped.hEvent)
		{
			CloseHandle(ctx->overlapped.hEvent);
			ctx->overlapped.hEvent = nullptr;
		}
	}
}
