#include "ServiceBase.h"

#include <array>
#include <string>
#include <cwchar>
#include <system_error>
#include <mutex>
#include <vector>

// =============================================================================
// ServiceBase.cpp
// -----------------------------------------------------------------------------
// CServiceBase 的实现。相较原版的关键改进：
//   - 各“*_PENDING”状态上报时提供合理的 waitHint，避免 SCM 因 waitHint=0
//     而误判服务无响应（尤其是停止阶段）。
// =============================================================================

namespace
{
	// “挂起”状态的默认预计耗时（毫秒）。停止 / 启动通常很快完成，
	// 给 SCM 一个宽裕的等待提示即可。
	constexpr DWORD PENDING_WAIT_HINT_MS = 30000;

	// 事件日志源句柄的 RAII 封装。
	class EventSourceHandle
	{
	public:
		explicit EventSourceHandle(PCWSTR name) noexcept
			: m_handle(::RegisterEventSourceW(nullptr, name))
		{
		}

		~EventSourceHandle()
		{
			if (m_handle)
			{
				::DeregisterEventSource(m_handle);
			}
		}

		EventSourceHandle(const EventSourceHandle&) = delete;
		EventSourceHandle& operator=(const EventSourceHandle&) = delete;

		HANDLE get() const noexcept { return m_handle; }

	private:
		HANDLE m_handle{nullptr};
	};

	// 判断某状态是否属于“挂起中”，用于决定是否附带 waitHint。
	bool IsPendingState(DWORD state) noexcept
	{
		return state == SERVICE_START_PENDING ||
			state == SERVICE_STOP_PENDING ||
			state == SERVICE_PAUSE_PENDING ||
			state == SERVICE_CONTINUE_PENDING;
	}
}

CServiceBase* CServiceBase::s_service = nullptr;

bool CServiceBase::Run(CServiceBase& service)
{
	s_service = &service;

	// 服务表要求可写的名称缓冲。
	std::vector<wchar_t> nameBuffer(service.m_name.size() + 1);
	wcscpy_s(nameBuffer.data(), nameBuffer.size(), service.m_name.c_str());

	std::array<SERVICE_TABLE_ENTRYW, 2> serviceTable{{
		{nameBuffer.data(), ServiceMain},
		{nullptr, nullptr}
	}};

	return ::StartServiceCtrlDispatcherW(serviceTable.data()) != FALSE;
}

void WINAPI CServiceBase::ServiceMain(DWORD argc, PWSTR* argv)
{
	if (!s_service)
	{
		return;
	}

	const auto handle = ::RegisterServiceCtrlHandlerW(
		s_service->m_name.c_str(),
		ServiceCtrlHandler);

	if (!handle)
	{
		return;
	}

	s_service->m_statusHandle = handle;

	try
	{
		s_service->Start(argc, argv);
	}
	catch (...)
	{
		s_service->SetServiceStatus(SERVICE_STOPPED, ERROR_EXCEPTION_IN_SERVICE);
	}
}

void WINAPI CServiceBase::ServiceCtrlHandler(DWORD ctrl)
{
	if (!s_service)
	{
		return;
	}

	switch (ctrl)
	{
	case SERVICE_CONTROL_STOP:
		s_service->Stop();
		break;
	case SERVICE_CONTROL_PAUSE:
		s_service->Pause();
		break;
	case SERVICE_CONTROL_CONTINUE:
		s_service->Continue();
		break;
	case SERVICE_CONTROL_SHUTDOWN:
		s_service->Shutdown();
		break;
	default:
		break;
	}
}

CServiceBase::CServiceBase(std::wstring serviceName,
                           bool canStop,
                           bool canShutdown,
                           bool canPauseContinue)
	: m_name(std::move(serviceName)),
	  m_canStop(canStop),
	  m_canShutdown(canShutdown),
	  m_canPauseContinue(canPauseContinue)
{
	m_statusHandle = nullptr;

	m_status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	m_status.dwCurrentState = SERVICE_START_PENDING;

	DWORD controlsAccepted = 0;
	if (canStop)
	{
		controlsAccepted |= SERVICE_ACCEPT_STOP;
	}
	if (canShutdown)
	{
		controlsAccepted |= SERVICE_ACCEPT_SHUTDOWN;
	}
	if (canPauseContinue)
	{
		controlsAccepted |= SERVICE_ACCEPT_PAUSE_CONTINUE;
	}

	m_status.dwControlsAccepted = controlsAccepted;
	m_status.dwWin32ExitCode = NO_ERROR;
	m_status.dwServiceSpecificExitCode = 0;
	m_status.dwCheckPoint = 0;
	m_status.dwWaitHint = 0;
}

void CServiceBase::Start(DWORD argc, PWSTR* argv)
{
	try
	{
		SetServiceStatus(SERVICE_START_PENDING);
		OnStart(argc, argv);
		SetServiceStatus(SERVICE_RUNNING);
	}
	catch (const std::system_error& e)
	{
		DWORD error = (e.code().category() == std::system_category())
			? static_cast<DWORD>(e.code().value())
			: ERROR_UNHANDLED_EXCEPTION;
		WriteErrorLogEntry(L"Service Start", error);
		SetServiceStatus(SERVICE_STOPPED, error);
	}
	catch (const std::exception&)
	{
		WriteEventLogEntry(L"Standard exception during start.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(SERVICE_STOPPED, ERROR_UNHANDLED_EXCEPTION);
	}
	catch (...)
	{
		WriteEventLogEntry(L"Service failed to start.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(SERVICE_STOPPED, ERROR_UNHANDLED_EXCEPTION);
	}
}

void CServiceBase::Stop() noexcept
{
	DWORD originalState = m_status.dwCurrentState;
	try
	{
		SetServiceStatus(SERVICE_STOP_PENDING);
		OnStop();
		SetServiceStatus(SERVICE_STOPPED);
	}
	catch (const std::system_error& e)
	{
		DWORD error = (e.code().category() == std::system_category())
			? static_cast<DWORD>(e.code().value())
			: ERROR_UNHANDLED_EXCEPTION;
		WriteErrorLogEntry(L"Service Stop", error);
		SetServiceStatus(originalState == SERVICE_RUNNING ? SERVICE_STOP_PENDING : originalState, error);
	}
	catch (const std::exception&)
	{
		WriteEventLogEntry(L"Standard exception during stop.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(originalState == SERVICE_RUNNING ? SERVICE_STOP_PENDING : originalState, ERROR_UNHANDLED_EXCEPTION);
	}
	catch (...)
	{
		WriteEventLogEntry(L"Service failed to stop.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(originalState == SERVICE_RUNNING ? SERVICE_STOP_PENDING : originalState, ERROR_UNHANDLED_EXCEPTION);
	}
}

void CServiceBase::Pause()
{
	try
	{
		SetServiceStatus(SERVICE_PAUSE_PENDING);
		OnPause();
		SetServiceStatus(SERVICE_PAUSED);
	}
	catch (const std::system_error& e)
	{
		DWORD error = (e.code().category() == std::system_category())
			? static_cast<DWORD>(e.code().value())
			: ERROR_UNHANDLED_EXCEPTION;
		WriteErrorLogEntry(L"Service Pause", error);
		SetServiceStatus(SERVICE_RUNNING, error);
	}
	catch (const std::exception&)
	{
		WriteEventLogEntry(L"Standard exception during pause.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(SERVICE_RUNNING, ERROR_UNHANDLED_EXCEPTION);
	}
	catch (...)
	{
		WriteEventLogEntry(L"Service failed to pause.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(SERVICE_RUNNING, ERROR_UNHANDLED_EXCEPTION);
	}
}

void CServiceBase::Continue()
{
	try
	{
		SetServiceStatus(SERVICE_CONTINUE_PENDING);
		OnContinue();
		SetServiceStatus(SERVICE_RUNNING);
	}
	catch (const std::system_error& e)
	{
		DWORD error = (e.code().category() == std::system_category())
			? static_cast<DWORD>(e.code().value())
			: ERROR_UNHANDLED_EXCEPTION;
		WriteErrorLogEntry(L"Service Continue", error);
		SetServiceStatus(SERVICE_PAUSED, error);
	}
	catch (const std::exception&)
	{
		WriteEventLogEntry(L"Standard exception during continue.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(SERVICE_PAUSED, ERROR_UNHANDLED_EXCEPTION);
	}
	catch (...)
	{
		WriteEventLogEntry(L"Service failed to resume.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(SERVICE_PAUSED, ERROR_UNHANDLED_EXCEPTION);
	}
}

void CServiceBase::Shutdown()
{
	if (m_status.dwCurrentState == SERVICE_STOPPED)
	{
		return;
	}

	try
	{
		OnShutdown();
		SetServiceStatus(SERVICE_STOPPED);
	}
	catch (const std::system_error& e)
	{
		DWORD error = (e.code().category() == std::system_category())
			? static_cast<DWORD>(e.code().value())
			: ERROR_UNHANDLED_EXCEPTION;
		WriteErrorLogEntry(L"Service Shutdown", error);
		SetServiceStatus(SERVICE_STOPPED, error);
	}
	catch (const std::exception&)
	{
		WriteEventLogEntry(L"Standard exception during shutdown.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(SERVICE_STOPPED, ERROR_UNHANDLED_EXCEPTION);
	}
	catch (...)
	{
		WriteEventLogEntry(L"Service failed to shut down.", EVENTLOG_ERROR_TYPE);
		SetServiceStatus(SERVICE_STOPPED, ERROR_UNHANDLED_EXCEPTION);
	}
}

void CServiceBase::SetServiceStatus(DWORD currentState,
                                    DWORD win32ExitCode,
                                    DWORD waitHint)
{
	std::lock_guard<std::mutex> lock(m_statusMutex);

	m_status.dwCurrentState = currentState;
	m_status.dwWin32ExitCode = win32ExitCode;

	// 对“挂起中”状态若调用方未显式给出 waitHint，则填入默认值，
	// 防止 SCM 因 waitHint=0 而认为服务失去响应。
	if (waitHint == 0 && IsPendingState(currentState))
	{
		waitHint = PENDING_WAIT_HINT_MS;
	}
	m_status.dwWaitHint = waitHint;

	// 进入稳定状态时清零检查点；挂起状态则递增，向 SCM 表明仍在推进。
	if (currentState == SERVICE_RUNNING || currentState == SERVICE_STOPPED)
	{
		m_checkpoint = 0;
		m_status.dwCheckPoint = 0;
	}
	else
	{
		++m_checkpoint;
		m_status.dwCheckPoint = m_checkpoint;
	}

	::SetServiceStatus(m_statusHandle, &m_status);
}

void CServiceBase::WriteEventLogEntry(PCWSTR message, WORD type)
{
	EventSourceHandle source(m_name.c_str());

	if (!source.get())
	{
		return;
	}

	LPCWSTR strings[2] = {m_name.c_str(), message};

	::ReportEventW(
		source.get(),
		type,
		0,
		0,
		nullptr,
		2,
		0,
		strings,
		nullptr);
}

void CServiceBase::WriteErrorLogEntry(PCWSTR function, DWORD error)
{
	std::wstring message;
	try
	{
		// C++17 无 std::format，用 swprintf_s 组装消息。
		wchar_t buffer[256];
		int n = swprintf_s(buffer, L"%s failed w/err 0x%08X", function, error);
		message = (n >= 0) ? std::wstring(buffer) : std::wstring(L"Error logging failed");
	}
	catch (...)
	{
		message = L"Error logging failed";
	}
	WriteEventLogEntry(message.c_str(), EVENTLOG_ERROR_TYPE);
}
