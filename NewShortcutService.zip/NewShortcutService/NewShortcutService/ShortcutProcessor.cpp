#include "ShortcutProcessor.h"

#include "Constants.h"
#include "DesktopEnumerator.h"
#include "ShortcutLink.h"

#include <windows.h>
#include <cwctype>

// =============================================================================
// ShortcutProcessor.cpp
// -----------------------------------------------------------------------------
// 核心处理逻辑实现。所有文件系统异常在方法内部被吞掉（尽力而为），
// 单个文件 / 目录出错不影响整体流程。
// =============================================================================

namespace fs = std::filesystem;

namespace
{
	// 判断路径扩展名是否为 .lnk（大小写不敏感）。
	bool IsShortcutFile(const fs::path& p)
	{
		std::wstring ext = p.extension().wstring();
		for (auto& c : ext)
		{
			c = static_cast<wchar_t>(std::towlower(c));
		}
		return ext == constants::SHORTCUT_EXTENSION;
	}

	// 生成唯一目标路径：若目标已存在，则依次尝试 name_1.lnk、name_2.lnk……
	// 最多尝试 1000 次，超出则返回原始路径（由上层的搬运操作决定成败）。
	fs::path MakeUniquePath(const fs::path& desired)
	{
		if (!fs::exists(desired))
		{
			return desired;
		}

		fs::path stem = desired.stem();
		fs::path ext = desired.extension();
		fs::path parent = desired.parent_path();

		constexpr int MAX_ATTEMPTS = 1000;
		for (int attempt = 1; attempt <= MAX_ATTEMPTS; ++attempt)
		{
			fs::path candidate = parent /
				(stem.wstring() + L"_" + std::to_wstring(attempt) + ext.wstring());
			if (!fs::exists(candidate))
			{
				return candidate;
			}
		}

		return desired;
	}

	// 判断两个目录是否为同一路径（用于避免把公共桌面上的文件搬到它自己）。
	bool IsSamePath(const fs::path& a, const fs::path& b)
	{
		std::error_code ec;
		return fs::equivalent(a, b, ec);
	}

	// 生成一个当前不存在的 .tmp 临时路径（在原文件同目录下）。
	// 若首选的 "<name>.tmp" 已存在，则追加序号继续尝试。
	fs::path MakeUniqueTmpPath(const fs::path& original)
	{
		fs::path candidate = original;
		candidate += L".tmp";
		if (!fs::exists(candidate))
		{
			return candidate;
		}

		constexpr int MAX_ATTEMPTS = 1000;
		for (int attempt = 1; attempt <= MAX_ATTEMPTS; ++attempt)
		{
			fs::path c = original;
			c += (L".tmp" + std::to_wstring(attempt));
			if (!fs::exists(c))
			{
				return c;
			}
		}
		return candidate;
	}

	// 安全删除：不直接 DeleteFileW（会被外部监控服务捕获并送入回收站）。
	// 步骤：1) 将原文件重命名为 .tmp 后缀；2) 删除该 .tmp 文件。
	// 通过先改名规避针对 .lnk 的监控，从而避免文件被移入回收站。
	// 返回 true 表示文件已被成功清除。
	bool SafeDelete(const fs::path& target)
	{
		fs::path tmp = MakeUniqueTmpPath(target);

		// 第一步：重命名为 .tmp。此处的 MoveFileW 仅为同目录改名。
		if (!MoveFileW(target.c_str(), tmp.c_str()))
		{
			return false;
		}

		// 第二步：删除已改名的 .tmp 文件。
		if (!DeleteFileW(tmp.c_str()))
		{
			// 删除失败：尽力把文件名改回，避免残留 .tmp。
			MoveFileW(tmp.c_str(), target.c_str());
			return false;
		}

		return true;
	}

	// 安全移动：不直接 MoveFileW（会被外部监控服务捕获并把源文件送入回收站）。
	// 步骤：1) 复制到目标目录；2) 将原文件重命名为 .tmp 后缀；3) 删除该 .tmp。
	// 返回 true 表示已成功搬运（目标已就位且源已清除）。
	//
	// 说明：dest 由调用方经 MakeUniquePath 生成，但在“检查—复制”之间仍可能有其他
	// 进程抢先创建同名文件（TOCTOU）。故此处用 CopyFileW(..., TRUE) 要求目标不存在，
	// 若冲突则重新生成唯一名重试，避免直接覆盖他人文件。
	bool SafeMove(const fs::path& src, const fs::path& dest)
	{
		fs::path target = dest;

		constexpr int MAX_RETRY = 1000;
		for (int attempt = 0; attempt < MAX_RETRY; ++attempt)
		{
			// bFailIfExists = TRUE：目标已存在则失败，杜绝覆盖。
			if (CopyFileW(src.c_str(), target.c_str(), TRUE))
			{
				break;
			}

			DWORD err = GetLastError();
			if (err == ERROR_FILE_EXISTS || err == ERROR_ALREADY_EXISTS)
			{
				// 目标被抢占：重新生成一个唯一名再试。
				target = MakeUniquePath(dest);
				continue;
			}

			// 其他错误：复制失败，放弃。
			return false;
		}

		// 第二步 + 第三步：安全删除源文件（改名为 .tmp 再删除）。
		if (!SafeDelete(src))
		{
			// 源文件清除失败：回滚删除刚复制的目标，保持原状。
			SafeDelete(target);
			return false;
		}

		return true;
	}
}

void ShortcutProcessor::ProcessShortcut(const fs::path& shortcut,
                                        const fs::path& dest_root,
                                        shortcut::LinkReader& reader,
                                        OperationReport& report)
{
	// 读取快捷方式信息（复用 reader 内部 COM 对象）。
	shortcut::LinkInfo info = reader.Read(shortcut);

	// 安全策略：读取失败时状态不确定，既不删除也不移动。
	if (!info.loaded)
	{
		return;
	}

	// 失效快捷方式：目标为空、或目标文件已不存在（如程序被卸载）。
	// 这类应当删除，不搬运。特殊有效项（如“此电脑”）不属失效，会被保留。
	if (info.is_dangling)
	{
		if (SafeDelete(shortcut))
		{
			++report.deleted_count;
			report.deleted_files.push_back(shortcut.filename().wstring());
		}
		return;
	}

	// 特殊快捷方式（shell 命名空间对象 / CLSID，且目标有效）：保留原位，不搬运。
	if (info.special)
	{
		return;
	}

	// 普通有效快捷方式：搬运到公共桌面，重名自动追加后缀。
	fs::path dest = MakeUniquePath(dest_root / shortcut.filename());
	if (SafeMove(shortcut, dest))
	{
		++report.moved_count;
		report.moved_files.push_back(shortcut.filename().wstring());
	}
}

void ShortcutProcessor::ProcessDesktop(const fs::path& desktop,
                                       shortcut::LinkReader& reader,
                                       OperationReport& report)
{
	fs::path public_desktop(constants::PUBLIC_DESKTOP);

	// 公共桌面本身不作为“源”处理（它是搬运目标）。
	if (IsSamePath(desktop, public_desktop))
	{
		return;
	}

	try
	{
		for (const auto& entry : fs::directory_iterator(desktop))
		{
			if (!entry.is_regular_file())
			{
				continue;
			}
			if (!IsShortcutFile(entry.path()))
			{
				continue;
			}

			ProcessShortcut(entry.path(), public_desktop, reader, report);
		}
	}
	catch (const fs::filesystem_error&)
	{
		// 单个桌面目录处理失败时忽略，继续处理其他桌面。
	}
}

void ShortcutProcessor::CleanupPublicDesktop(shortcut::LinkReader& reader,
                                             OperationReport& report)
{
	fs::path public_desktop(constants::PUBLIC_DESKTOP);

	try
	{
		if (!fs::exists(public_desktop) || !fs::is_directory(public_desktop))
		{
			return;
		}

		for (const auto& entry : fs::directory_iterator(public_desktop))
		{
			if (!entry.is_regular_file())
			{
				continue;
			}
			if (!IsShortcutFile(entry.path()))
			{
				continue;
			}

			shortcut::LinkInfo info = reader.Read(entry.path());
			// 仅当成功读取且确认为失效快捷方式（空目标 / 目标不存在）时才删除。
			if (info.loaded && info.is_dangling)
			{
				if (SafeDelete(entry.path()))
				{
					++report.deleted_count;
					report.deleted_files.push_back(entry.path().filename().wstring());
				}
			}
		}
	}
	catch (const fs::filesystem_error&)
	{
		// 忽略清理过程中的错误。
	}
}

OperationReport ShortcutProcessor::ScanAll()
{
	OperationReport report;

	// 复用同一个读取器处理整轮扫描，避免逐文件重建 COM 对象。
	shortcut::LinkReader reader;

	// 遍历所有桌面来源并处理。
	auto desktops = desktop::EnumerateDesktops();
	for (const auto& desktop : desktops)
	{
		ProcessDesktop(desktop, reader, report);
	}

	// 最后清理公共桌面中残留的失效快捷方式。
	CleanupPublicDesktop(reader, report);

	return report;
}

OperationReport ShortcutProcessor::ProcessSingle(const fs::path& shortcut_path)
{
	OperationReport report;

	// 仅处理 .lnk 文件。
	if (!IsShortcutFile(shortcut_path))
	{
		return report;
	}

	// 文件可能在去抖等待期间已被删除 / 移动，需再次确认存在。
	std::error_code ec;
	if (!fs::exists(shortcut_path, ec) || !fs::is_regular_file(shortcut_path, ec))
	{
		return report;
	}

	shortcut::LinkReader reader;
	fs::path public_desktop(constants::PUBLIC_DESKTOP);
	fs::path parent = shortcut_path.parent_path();

	// 若变更发生在公共桌面自身：只做失效快捷方式清理，不搬运。
	if (IsSamePath(parent, public_desktop))
	{
		shortcut::LinkInfo info = reader.Read(shortcut_path);
		if (info.loaded && info.is_dangling)
		{
			if (SafeDelete(shortcut_path))
			{
				++report.deleted_count;
				report.deleted_files.push_back(shortcut_path.filename().wstring());
			}
		}
		return report;
	}

	// 其他桌面上的快捷方式：走标准处理逻辑。
	ProcessShortcut(shortcut_path, public_desktop, reader, report);

	return report;
}
