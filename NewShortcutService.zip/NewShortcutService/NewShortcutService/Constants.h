#pragma once

#include <windows.h>
#include <string_view>

// =============================================================================
// Constants.h
// -----------------------------------------------------------------------------
// 集中存放整个服务用到的所有硬编码常量。
// 目的：避免魔法值散落在各个源文件中，后期若需调整路径 / 服务名 / 时间参数，
//       只需修改此处一个文件即可。
// =============================================================================

namespace constants
{
	// -------------------------------------------------------------------------
	// 路径相关常量
	// -------------------------------------------------------------------------

	// 公共桌面目录：所有用户可见的桌面，普通快捷方式最终会被集中搬运到这里。
	inline constexpr std::wstring_view PUBLIC_DESKTOP = L"C:\\Users\\Public\\Desktop";

	// HarmonyOS 桌面重定向根目录：该目录下每个子目录的 Desktop 也会被扫描。
	inline constexpr std::wstring_view REDIRECT_ROOT = L"C:\\HarmonyOS";

	// 用户目录根：用于枚举 C:\Users\<用户名>\Desktop。
	inline constexpr std::wstring_view USERS_ROOT = L"C:\\Users";

	// 快捷方式文件扩展名（小写，比较时需大小写不敏感）。
	inline constexpr std::wstring_view SHORTCUT_EXTENSION = L".lnk";

	// -------------------------------------------------------------------------
	// 服务标识常量
	// -------------------------------------------------------------------------

	// 服务内部名称（供 SCM 使用，也用于事件日志源名称）。
	inline constexpr std::wstring_view SERVICE_NAME = L"ShortcutService";

	// 服务显示名称（在“服务”管理器中展示）。
	inline constexpr std::wstring_view SERVICE_DISPLAY_NAME = L"ShortcutMoveService";

	// 服务描述文本。
	inline constexpr std::wstring_view SERVICE_DESCRIPTION =
		L"Automatic move User's Desktop shortcut link to Public's Desktop folder";

	// 服务启动类型：随系统自动启动。
	inline constexpr DWORD SERVICE_START_TYPE = SERVICE_AUTO_START;

	// 服务运行账户：本地系统账户（拥有 SE_TCB_PRIVILEGE，可跨会话取用户令牌）。
	inline constexpr std::wstring_view SERVICE_ACCOUNT = L"NT AUTHORITY\\SYSTEM";

	// -------------------------------------------------------------------------
	// 时间 / 行为参数
	// -------------------------------------------------------------------------

	// 文件事件去抖延迟（毫秒）。
	// 快捷方式创建 / 写入过程中操作系统会连续抛出多条通知，
	// 收到通知后等待该时长再统一处理，避免处理“尚在写入中”的 .lnk 文件，
	// 同时把短时间内的多次变更合并为一次处理。
	inline constexpr DWORD DEBOUNCE_DELAY_MS = 500;

	// 桌面刷新使用的命令：IE 图标缓存刷新工具。
	// 以目标用户令牌跨会话执行，确保用户看到的桌面立即更新。
	inline constexpr std::wstring_view REFRESH_COMMAND = L"ie4uinit.exe";
	inline constexpr std::wstring_view REFRESH_ARGUMENTS = L"-show";
}
