#include "ServiceInstaller.h"

#include <vector>
#include <string>

// =============================================================================
// ServiceInstaller.cpp
// -----------------------------------------------------------------------------
// 安装 / 卸载实现。相较原版的关键改进：
//   - 启动失败（非“已在运行”）时回滚，删除刚创建的服务，避免残留半成品服务。
// =============================================================================

BOOL InstallService(PCWSTR serviceName, PCWSTR displayName, DWORD startType,
                    PCWSTR dependencies, PCWSTR account, PCWSTR password, PCWSTR description) noexcept
{
	// 取当前可执行文件完整路径（作为服务的二进制路径）。
	// 缓冲不足时按需扩容。
	std::vector<wchar_t> pathBuf(MAX_PATH);
	while (true)
	{
		DWORD len = GetModuleFileNameW(nullptr, pathBuf.data(), static_cast<DWORD>(pathBuf.size()));
		if (len == 0)
		{
			return FALSE;
		}
		if (len < pathBuf.size())
		{
			break;
		}
		// 缓冲不足：扩容重试。
		pathBuf.resize(pathBuf.size() * 2);
	}
	PCWSTR szPath = pathBuf.data();

	// 连接 SCM。
	ScopedSCHandle schSCManager(
		OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT | SC_MANAGER_CREATE_SERVICE));
	if (!schSCManager)
	{
		return FALSE;
	}

	// 创建服务。
	ScopedSCHandle schService(
		CreateServiceW(
			schSCManager,
			serviceName,
			displayName,
			SERVICE_ALL_ACCESS,
			SERVICE_WIN32_OWN_PROCESS,
			startType,
			SERVICE_ERROR_NORMAL,
			szPath,
			nullptr,
			nullptr,
			dependencies,
			account,
			password));
	if (!schService)
	{
		return FALSE;
	}

	// 设置服务描述（失败不影响安装结果）。
	if (description && *description)
	{
		SERVICE_DESCRIPTIONW sd;
		sd.lpDescription = const_cast<LPWSTR>(description);
		ChangeServiceConfig2W(schService, SERVICE_CONFIG_DESCRIPTION, &sd);
	}

	// 立即启动服务。
	if (!StartServiceW(schService, 0, nullptr))
	{
		DWORD err = GetLastError();
		if (err != ERROR_SERVICE_ALREADY_RUNNING)
		{
			// 启动失败：回滚，删除刚创建的服务，避免留下无法启动的残留服务。
			DeleteService(schService);
			return FALSE;
		}
	}

	return TRUE;
}

BOOL UninstallService(PCWSTR serviceName) noexcept
{
	ScopedSCHandle schSCManager(OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT));
	if (!schSCManager)
	{
		return FALSE;
	}

	ScopedSCHandle schService(
		OpenServiceW(schSCManager, serviceName, SERVICE_STOP | SERVICE_QUERY_STATUS | DELETE));
	if (!schService)
	{
		return FALSE;
	}

	// 若服务仍在运行，先尝试停止并等待其停止（最多 30 秒）。
	SERVICE_STATUS ssSvcStatus = {};
	if (QueryServiceStatus(schService, &ssSvcStatus) && ssSvcStatus.dwCurrentState != SERVICE_STOPPED)
	{
		if (ControlService(schService, SERVICE_CONTROL_STOP, &ssSvcStatus))
		{
			constexpr DWORD maxWait = 30;
			for (DWORD i = 0; i < maxWait; ++i)
			{
				Sleep(1000);
				if (!QueryServiceStatus(schService, &ssSvcStatus))
				{
					break;
				}
				if (ssSvcStatus.dwCurrentState == SERVICE_STOPPED)
				{
					break;
				}
			}
			// 即便未能在超时内停止，仍继续尝试删除（删除标记会在停止后生效）。
		}
	}

	if (!DeleteService(schService))
	{
		return FALSE;
	}

	return TRUE;
}
