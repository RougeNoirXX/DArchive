#pragma once

#include <filesystem>
#include <set>

// =============================================================================
// DesktopEnumerator.h
// -----------------------------------------------------------------------------
// 负责收集系统中所有“需要被处理 / 监控”的用户桌面目录。
//
// 数据来源（三路合并，自动去重）：
//   1. C:\Users\<用户名>\Desktop     —— 排除 Public/Default/Administrator/All Users
//   2. C:\HarmonyOS\<子目录>\Desktop —— HarmonyOS 桌面重定向
//   3. 注册表 HKEY_USERS\<SID>\...\User Shell Folders 中的 Desktop 项
//      —— 覆盖桌面被重定向到非默认位置的情况
// =============================================================================

namespace desktop
{
	// 返回去重后的桌面目录集合（使用 std::set 保证唯一且有序）。
	std::set<std::filesystem::path> EnumerateDesktops();
}
