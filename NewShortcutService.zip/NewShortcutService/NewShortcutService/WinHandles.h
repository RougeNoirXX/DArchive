#pragma once

#include <windows.h>
#include <utility>

// =============================================================================
// WinHandles.h
// -----------------------------------------------------------------------------
// 一组针对 Windows 各类句柄的 RAII 封装。
// 目的：确保句柄在离开作用域时自动释放，杜绝资源泄漏，并使异常安全。
//
// 设计要点：
//   - 统一禁止拷贝、允许移动（句柄天然不可复制，但可转移所有权）。
//   - 提供隐式转换以便直接传入 Win32 API。
// =============================================================================

namespace winhandles
{
	// -------------------------------------------------------------------------
	// RegKey：注册表键句柄（HKEY）的 RAII 封装。
	// 析构时自动调用 RegCloseKey。
	// -------------------------------------------------------------------------
	class RegKey
	{
	public:
		RegKey() noexcept : hkey_(nullptr)
		{
		}

		explicit RegKey(HKEY hkey) noexcept : hkey_(hkey)
		{
		}

		~RegKey()
		{
			if (hkey_)
			{
				RegCloseKey(hkey_);
			}
		}

		RegKey(const RegKey&) = delete;
		RegKey& operator=(const RegKey&) = delete;

		RegKey(RegKey&& other) noexcept : hkey_(other.hkey_)
		{
			other.hkey_ = nullptr;
		}

		RegKey& operator=(RegKey&& other) noexcept
		{
			// 注意：本类重载了 operator&，故此处用 std::addressof 取真实地址。
			if (this != std::addressof(other))
			{
				if (hkey_)
				{
					RegCloseKey(hkey_);
				}
				hkey_ = other.hkey_;
				other.hkey_ = nullptr;
			}
			return *this;
		}

		// 隐式转换为 HKEY，便于直接传入注册表 API。
		operator HKEY() const noexcept { return hkey_; }

		// 取地址运算符：便于作为“输出参数”传给 RegOpenKeyExW(&key) 等。
		HKEY* operator&() noexcept { return &hkey_; }

	private:
		HKEY hkey_;
	};

	// -------------------------------------------------------------------------
	// ScopedHandle：通用内核对象句柄（HANDLE）的 RAII 封装。
	// 适用于进程 / 线程 / 事件 / 文件等由 CloseHandle 释放的句柄。
	// 注意：INVALID_HANDLE_VALUE 与 nullptr 都视为“无效”。
	// -------------------------------------------------------------------------
	class ScopedHandle
	{
	public:
		ScopedHandle() noexcept : handle_(nullptr)
		{
		}

		explicit ScopedHandle(HANDLE h) noexcept : handle_(h)
		{
		}

		~ScopedHandle()
		{
			Close();
		}

		ScopedHandle(const ScopedHandle&) = delete;
		ScopedHandle& operator=(const ScopedHandle&) = delete;

		ScopedHandle(ScopedHandle&& other) noexcept : handle_(other.handle_)
		{
			other.handle_ = nullptr;
		}

		ScopedHandle& operator=(ScopedHandle&& other) noexcept
		{
			if (this != &other)
			{
				Close();
				handle_ = other.handle_;
				other.handle_ = nullptr;
			}
			return *this;
		}

		HANDLE get() const noexcept { return handle_; }

		// 判断句柄是否有效（同时排除 nullptr 与 INVALID_HANDLE_VALUE）。
		bool valid() const noexcept
		{
			return handle_ != nullptr && handle_ != INVALID_HANDLE_VALUE;
		}

		// 重置为新句柄，先释放旧句柄。
		void reset(HANDLE h = nullptr) noexcept
		{
			if (handle_ != h)
			{
				Close();
				handle_ = h;
			}
		}

		// 交出所有权，调用方负责释放。
		HANDLE release() noexcept
		{
			HANDLE tmp = handle_;
			handle_ = nullptr;
			return tmp;
		}

		operator HANDLE() const noexcept { return handle_; }

	private:
		void Close() noexcept
		{
			if (handle_ != nullptr && handle_ != INVALID_HANDLE_VALUE)
			{
				CloseHandle(handle_);
			}
			handle_ = nullptr;
		}

		HANDLE handle_;
	};

	// -------------------------------------------------------------------------
	// FindFileHandle：FindFirstFile 系列返回句柄的 RAII 封装。
	// 该类句柄必须用 FindClose 释放，不能用 CloseHandle。
	// -------------------------------------------------------------------------
	class FindFileHandle
	{
	public:
		explicit FindFileHandle(HANDLE h) noexcept : handle_(h)
		{
		}

		~FindFileHandle()
		{
			if (handle_ != INVALID_HANDLE_VALUE)
			{
				FindClose(handle_);
			}
		}

		FindFileHandle(const FindFileHandle&) = delete;
		FindFileHandle& operator=(const FindFileHandle&) = delete;

		FindFileHandle(FindFileHandle&& other) noexcept : handle_(other.handle_)
		{
			other.handle_ = INVALID_HANDLE_VALUE;
		}

		FindFileHandle& operator=(FindFileHandle&& other) noexcept
		{
			if (this != &other)
			{
				if (handle_ != INVALID_HANDLE_VALUE)
				{
					FindClose(handle_);
				}
				handle_ = other.handle_;
				other.handle_ = INVALID_HANDLE_VALUE;
			}
			return *this;
		}

		HANDLE get() const noexcept { return handle_; }
		bool valid() const noexcept { return handle_ != INVALID_HANDLE_VALUE; }

	private:
		HANDLE handle_;
	};
}
