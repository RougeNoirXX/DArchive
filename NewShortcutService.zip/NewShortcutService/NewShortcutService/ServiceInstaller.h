#pragma once

#include <windows.h>

// =============================================================================
// ServiceInstaller.h
// -----------------------------------------------------------------------------
// 服务的安装与卸载辅助函数，以及 SCM 句柄的 RAII 封装。
// =============================================================================

// SC_HANDLE 的 RAII 封装：析构时自动 CloseServiceHandle。
struct ScopedSCHandle
{
	SC_HANDLE handle = nullptr;

	ScopedSCHandle() noexcept = default;

	explicit ScopedSCHandle(SC_HANDLE h) noexcept : handle(h)
	{
	}

	~ScopedSCHandle() noexcept
	{
		if (handle)
		{
			CloseServiceHandle(handle);
		}
	}

	ScopedSCHandle(const ScopedSCHandle&) = delete;
	ScopedSCHandle& operator=(const ScopedSCHandle&) = delete;

	ScopedSCHandle(ScopedSCHandle&& other) noexcept : handle(other.handle)
	{
		other.handle = nullptr;
	}

	ScopedSCHandle& operator=(ScopedSCHandle&& other) noexcept
	{
		if (this != &other)
		{
			if (handle)
			{
				CloseServiceHandle(handle);
			}
			handle = other.handle;
			other.handle = nullptr;
		}
		return *this;
	}

	operator SC_HANDLE() const noexcept { return handle; }
};

// 安装并启动服务。成功返回 TRUE。
// 若创建成功但启动失败（且非“已在运行”），将回滚删除已创建的服务。
BOOL InstallService(PCWSTR serviceName,
                    PCWSTR displayName,
                    DWORD startType,
                    PCWSTR dependencies,
                    PCWSTR account,
                    PCWSTR password,
                    PCWSTR description = nullptr) noexcept;

// 停止并卸载服务。成功返回 TRUE。
BOOL UninstallService(PCWSTR serviceName) noexcept;
