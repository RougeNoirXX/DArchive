#include "WindowsServiceImpl.h"

#include "Constants.h"
#include "DesktopEnumerator.h"
#include "DesktopRefresher.h"
#include "OperationReport.h"
#include "PathClassifier.h"
#include "ShortcutProcessor.h"

#include <objbase.h>
#include <map>
#include <set>
#include <string>

// =============================================================================
// WindowsServiceImpl.cpp
// -----------------------------------------------------------------------------
// 服务实现的编排逻辑。
// =============================================================================

CWindowsServiceImpl::CWindowsServiceImpl(const wchar_t* serviceName,
                                         bool canStop,
                                         bool canShutdown,
                                         bool canPauseContinue)
	: CServiceBase(serviceName, canStop, canShutdown, canPauseContinue)
{
}

CWindowsServiceImpl::~CWindowsServiceImpl() noexcept
{
	// 保险起见：析构时确保监控停止、工作线程结束。
	// （正常路径下 OnStop 已完成清理，这里是兜底。）
	// 说明：服务对象按进程级生命周期管理（wmain 有意不释放），此析构
	// 仅在构造 / 启动异常路径触发；被 detach 的工作线程在进程退出前仍
	// 可能访问本对象，因此该清理不能是唯一手段——进程终止才是最终兜底。
	m_stopping.store(true, std::memory_order_release);
	m_watcher.Stop();
	m_probe.Stop();

	// 有界地停止工作线程（与 OnStop 相同策略）。
	StopWorkerWithGrace();
}

void CWindowsServiceImpl::OnStart(DWORD, wchar_t**)
{
	// 注入探测诊断日志：探测线程卡死 / 退役等异常事件写入事件日志。
	m_probe.SetDiagnosticCallback([this](const wchar_t* message)
	{
		WriteEventLogEntry(message, EVENTLOG_WARNING_TYPE);
	});

	// 启动工作线程，OnStart 需尽快返回以便 SCM 收到 RUNNING 状态。
	m_worker = std::thread([this] { ServiceWorkerThread(); });
}

void CWindowsServiceImpl::HandleReport(const OperationReport& report)
{
	if (!report.HasChanges())
	{
		return;
	}

	// 写入事件日志摘要。
	std::wstring summary;
	report.BuildSummary(summary);
	WriteEventLogEntry(summary.c_str(), EVENTLOG_INFORMATION_TYPE);

	// 注意：桌面刷新不在此处触发，改由调用方在“整轮 / 整批”处理完成后统一刷新一次，
	// 避免批量处理时反复 spawn ie4uinit.exe。
}

void CWindowsServiceImpl::ServiceWorkerThread()
{
	// 顶层异常防护：任何异常（bad_alloc / system_error / 意外异常）都不得
	// 逃出线程入口，否则 std::terminate 会直接终止整个服务进程。
	// 异常时停止监控 / 探测器并上报 STOPPED，避免 SCM 仍显示运行中。
	try
	{
		ServiceWorkerThreadBody();
	}
	catch (const std::exception&)
	{
		m_stopping.store(true, std::memory_order_release);
		WriteEventLogEntry(
			L"Worker thread terminated by an unexpected exception.",
			EVENTLOG_ERROR_TYPE);
		ShutdownAfterWorkerFailure();
	}
	catch (...)
	{
		m_stopping.store(true, std::memory_order_release);
		WriteEventLogEntry(
			L"Worker thread terminated by an unknown exception.",
			EVENTLOG_ERROR_TYPE);
		ShutdownAfterWorkerFailure();
	}
}

void CWindowsServiceImpl::ServiceWorkerThreadBody()
{
	// 工作线程内统一初始化 COM（快捷方式读取依赖 COM）。
	// 使用多线程套间以适配后续在同一线程中的多次 COM 调用。
	HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
	bool comInitialized = SUCCEEDED(hr);

	struct CoGuard
	{
		bool active;
		~CoGuard() { if (active) CoUninitialize(); }
	} guard{comInitialized};

	ShortcutProcessor processor;

	// ---- 目录分类（带缓存）：本地（事件驱动） vs 远程 / 重定向（轮询） ----
	// Local / Remote 长期缓存；Unknown 不缓存——每次重枚举自动重新探测，
	// 避免一次临时故障（如分类探测达上限）把目录永久锁在 Unknown。
	// 分类为 Unknown（探测超时）的目录一律走轮询：轮询自带可达性门禁，
	// 不会对死 UNC 打开监控句柄，避免启动 / 运行阶段被 SMB 超时阻塞。
	std::map<std::filesystem::path, pathcls::DirKind> classified;

	auto classifyDir = [&classified](const std::filesystem::path& d)
	{
		auto it = classified.find(d);
		if (it != classified.end())
		{
			return it->second;
		}
		pathcls::DirKind kind = pathcls::Classify(d, constants::REMOTE_PROBE_TIMEOUT_MS);
		if (kind != pathcls::DirKind::Unknown)
		{
			classified.emplace(d, kind);
		}
		return kind;
	};

	// 先枚举全部桌面（其中远程叶子不做阻塞式存在性检查），再按分类拆分。
	std::set<std::filesystem::path> localDesktops;
	std::set<std::filesystem::path> remoteDesktops;
	{
		auto all = desktop::EnumerateDesktops();
		for (const auto& d : all)
		{
			if (classifyDir(d) == pathcls::DirKind::Local)
			{
				localDesktops.insert(d);
			}
			else
			{
				remoteDesktops.insert(d);
			}
		}
	}

	// ---- 阶段一：启动时全量扫描（仅本地，避免远程宕机阻塞启动）----
	{
		OperationReport report = processor.ScanAll(localDesktops);
		HandleReport(report);
		// 全量扫描后若有变更，统一刷新一次桌面（而非每个文件刷新一次）。
		if (report.HasChanges())
		{
			refresh::RefreshActiveSessions();
		}
	}

	// 若已请求停止，则不再进入监控。
	if (m_stopping.load(std::memory_order_acquire))
	{
		return;
	}

	// ---- 阶段二：进入实时监控 ----
	// 事件监控集合 = 本地桌面 + 公共桌面。
	std::set<std::filesystem::path> watchDirs = localDesktops;

	// 额外把公共桌面纳入监控：直接向 C:\Users\Public\Desktop 拷贝失效快捷方式时，
	// 也需要触发清理。EnumerateDesktops 出于“不把它当搬运源”的目的排除了公共桌面，
	// 这里显式补上，由 ProcessSingle 内部对公共桌面只做失效清理、不搬运。
	{
		std::filesystem::path public_desktop(constants::PUBLIC_DESKTOP);
		std::error_code ec;
		if (std::filesystem::is_directory(public_desktop, ec))
		{
			watchDirs.insert(public_desktop);
		}
	}

	// 变更回调（本地事件）：处理本批所有 .lnk，最后仅刷新一次桌面。
	auto onChange = [this, &processor](const std::set<std::filesystem::path>& paths)
	{
		// 批次处理前重建公共桌面索引一次：搬运前去重比对用。
		// （索引在搬运 / 删除时增量维护，整批共享，避免逐文件重扫公共桌面。）
		processor.RefreshPublicIndex();

		bool anyChange = false;
		for (const auto& path : paths)
		{
			OperationReport report = processor.ProcessSingle(path);
			HandleReport(report);
			if (report.HasChanges())
			{
				anyChange = true;
			}
		}

		// 整批处理完成后，若确有变更，统一刷新一次桌面。
		if (anyChange)
		{
			refresh::RefreshActiveSessions();
		}
	};

	// 轮询回调（远程桌面）：先经可达性门禁，仅对可达目录重扫。
	auto onPoll = [this, &processor](const std::set<std::filesystem::path>& dirs)
	{
		// 逐个做可达性门禁，剔除不可达目录，避免对死 UNC 发起会阻塞的扫描。
		std::set<std::filesystem::path> reachable;
		for (const auto& d : dirs)
		{
			if (m_probe.IsReachable(d, constants::REMOTE_PROBE_TIMEOUT_MS))
			{
				reachable.insert(d);
			}
		}

		if (reachable.empty())
		{
			return;
		}

		OperationReport report = processor.ScanDirectories(reachable);
		HandleReport(report);
		if (report.HasChanges())
		{
			refresh::RefreshActiveSessions();
		}
	};

	// 重扫回调（本地事件缓冲溢出时）：整目录重扫，无需可达性门禁。
	auto onRescan = [this, &processor](const std::set<std::filesystem::path>& dirs)
	{
		OperationReport report = processor.ScanDirectories(dirs);
		HandleReport(report);
		if (report.HasChanges())
		{
			refresh::RefreshActiveSessions();
		}
	};

	// 已登记的本地桌面集合：周期重扫时使用。
	std::set<std::filesystem::path> trackedLocal = watchDirs;

	// 已登记为轮询的目录集合：用于识别“Unknown 重分类为 Local”的目录迁移。
	std::set<std::filesystem::path> trackedPoll = remoteDesktops;

	// 周期重枚举回调：重新枚举桌面目录，返回“新发现 / 重分类”的目录供监控器
	// 增量登记。已登记的目录由监控器 / 集合去重跳过；分类结果带缓存，
	// Unknown 条目每次重枚举自动重新探测。
	auto onRefresh = [this, &processor, &classifyDir, &trackedLocal, &trackedPoll]() -> DirectoryWatcher::DirSets
	{
		DirectoryWatcher::DirSets sets;

		auto all = desktop::EnumerateDesktops();
		for (const auto& d : all)
		{
			pathcls::DirKind kind = classifyDir(d);
			if (kind == pathcls::DirKind::Local)
			{
				trackedLocal.insert(d);
				sets.watchDirs.insert(d);
				// 之前按轮询登记、本次确认为本地：升入事件监控并移出轮询，
				// 避免双通道重复处理。
				if (trackedPoll.erase(d) > 0)
				{
					sets.removePollDirs.insert(d);
				}
			}
			else
			{
				trackedPoll.insert(d);
				sets.pollDirs.insert(d);
			}
		}

		// 顺带对已登记的本地桌面做一次全量重扫（含公共桌面 dangling 清理）：
		//   - 升级改安装目录后，公共桌面残留的旧副本（dangling）及时清理；
		//   - 兜底事件监控因溢出 / 重发失败而漏掉的本地变更。
		// ScanAll 内部会先重建公共索引，故同时具备去重能力。
		OperationReport report = processor.ScanAll(trackedLocal);
		HandleReport(report);
		if (report.HasChanges())
		{
			refresh::RefreshActiveSessions();
		}

		return sets;
	};

	// Run 阻塞运行，直到 OnStop 调用 m_watcher.Stop()。
	m_watcher.Run(watchDirs, remoteDesktops, onChange, onPoll, onRescan, onRefresh);
}

void CWindowsServiceImpl::OnStop()
{
	// 标记停止并即时唤醒监控循环。
	m_stopping.store(true, std::memory_order_release);
	m_watcher.Stop();
	// 停止探测器（若探测线程卡在死 UNC 上，其内部会 detach 而不阻塞此处）。
	m_probe.Stop();

	// 有界地等待工作线程退出。
	StopWorkerWithGrace();
}

void CWindowsServiceImpl::StopWorkerWithGrace()
{
	if (!m_worker.joinable())
	{
		return;
	}

	// 打断工作线程可能卡在死 UNC 上的同步 IO（远程目录扫描等）。
	// 空闲时调用无副作用（ERROR_NOT_FOUND）。
	CancelSynchronousIo(m_worker.native_handle());

	// 有界等待：取消不保证所有文件系统 provider 即时响应，
	// 这里轮询线程退出状态，超时则降级为 detach，避免无限挂起。
	HANDLE native = m_worker.native_handle();
	DWORD exitCode = 0;
	const ULONGLONG deadline = GetTickCount64() + constants::SERVICE_WORKER_JOIN_GRACE_MS;
	bool exited = false;
	for (;;)
	{
		if (native && GetExitCodeThread(native, &exitCode) && exitCode != STILL_ACTIVE)
		{
			exited = true;
			break;
		}
		if (GetTickCount64() >= deadline)
		{
			break;
		}
		Sleep(100);
	}

	if (exited)
	{
		m_worker.join();
	}
	else
	{
		// 取消未生效（provider 不响应取消）：detach，线程随进程退出被系统回收。
		// 安全前提：服务对象为进程级生命周期（wmain 有意不释放），detach
		// 线程在进程退出前访问的任何成员都仍有效，不存在 use-after-free。
		m_worker.detach();
		WriteEventLogEntry(
			L"Worker thread still blocked after cancel grace period; detached.",
			EVENTLOG_WARNING_TYPE);
	}
}

void CWindowsServiceImpl::ShutdownAfterWorkerFailure()
{
	// 工作线程异常退出后：停止监控与探测器，并向 SCM 报告服务已停止。
	// 分发器据此返回、进程正常退出；不再出现“SCM 显示运行中、实际已停摆”。
	m_watcher.Stop();
	m_probe.Stop();
	SetServiceStatus(SERVICE_STOPPED, ERROR_EXCEPTION_IN_SERVICE);
}

void CWindowsServiceImpl::OnShutdown()
{
	// 系统关机路径：执行与 OnStop 相同的完整清理，
	// 确保监控循环与工作线程在关机前有序退出。
	OnStop();
}
