﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace OfficeTool
{
    public class AppxInstaller
    {
        /// <summary>
        /// 安装 Component 目录中全部 Appx 包（静默）。成功返回 true，任何失败返回 false。
        /// </summary>
        /// <param name="componentFolder">解压目录中 Component 文件夹路径</param>
        public static bool InstallComponentAppx(string componentFolder)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(componentFolder))
                    return false;

                if (!Directory.Exists(componentFolder))
                    return false;

                // 找 *.appx 或 *.msix
                var appxFiles = Directory.GetFiles(componentFolder, "*.appx");
                var msixFiles = Directory.GetFiles(componentFolder, "*.msix");

                var all = new string[appxFiles.Length + msixFiles.Length];
                appxFiles.CopyTo(all, 0);
                msixFiles.CopyTo(all, appxFiles.Length);

                return all.Length != 0 && all.All(InstallSingle);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 使用 Add-AppxPackage 静默安装单个 appx/msix。
        /// </summary>
        private static bool InstallSingle(string filePath)
        {
            try
            {
                // 全路径需加引号
                var escaped = "\"" + filePath + "\"";

                // PowerShell 脚本：Add-AppxPackage "c:\path\xxx.appx"
                var script = "Add-AppxPackage " + escaped;

                var psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = "-NoProfile -ExecutionPolicy Bypass -Command " + script,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.UTF8,
                    StandardErrorEncoding = Encoding.UTF8
                };

                using (var p = Process.Start(psi))
                {
                    var stdout = p?.StandardOutput.ReadToEnd();
                    var stderr = p?.StandardError.ReadToEnd();

                    p?.WaitForExit();

                    if (p != null && p.ExitCode != 0)
                    {
                        return false;
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}