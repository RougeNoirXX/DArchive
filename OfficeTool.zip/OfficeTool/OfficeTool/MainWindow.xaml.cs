using System;
using System.Threading.Tasks;
using System.Windows;
using OfficeTool;

namespace OfficeTool
{
    public partial class MainWindow : Window
    {
        private readonly DownloadAndExtractHelper _helper = new DownloadAndExtractHelper();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ProgressBar1.Value = 0;
                // 解压后的结构：
                // extractPath\Office\
                // extractPath\Component\
                const string url = @"file://I:/Book.rar"; // 请替换
                const string fileName = "download_test.rar";
                var extractPath = "";
                try
                {
                    extractPath = await _helper.DownloadAndExtractAsync(
                        url,
                        fileName,
                        progress =>
                        {
                            Dispatcher.Invoke(() =>
                            {
                                ProgressBar1.Value = progress * 100;
                            });
                        });

                    MessageBox.Show("解压完成，路径：" + extractPath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("错误：" + ex.Message);
                }
                
                var removed = await Task.Run(OfficeUninstaller.UninstallOffice);

                if (!removed)
                {
                    MessageBox.Show("卸载 Office 2021 失败。");
                    return;
                }
                // 安装 Office 2024
                ProgressBar1.Value = 0;
                var officeFolder = System.IO.Path.Combine(extractPath, "Office");
                var officeInstalled = await Task.Run(() => OfficeInstaller.InstallOffice(officeFolder));

                if (!officeInstalled)
                {
                    MessageBox.Show("安装 Office 2024 失败。");
                    return;
                }

                // 安装 Appx
                ProgressBar1.Value = 0;
                var compFolder = System.IO.Path.Combine(extractPath, "component");

                var appxInstalled = await Task.Run(() => AppxInstaller.InstallComponentAppx(compFolder));

                if (!appxInstalled)
                {
                    MessageBox.Show("安装 Appx 失败。");
                    return;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ProgressBar1.Value = 0;
        }
    }
}