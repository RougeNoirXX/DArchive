﻿using System;
using System.Diagnostics;
using System.IO;

namespace OfficeTool
{
    public abstract class OfficeInstaller
    {
        /// <summary>
        /// 开始安装 Office 2024
        /// </summary>
        /// <param name="extractedRootPath">解压后的根目录路径，例如：C:\Temp\Extracted123\</param>
        /// <returns>安装成功返回 true，否则返回 false</returns>
        public static bool InstallOffice(string extractedRootPath)
        {
            try
            {
                if (string.IsNullOrEmpty(extractedRootPath) || !Directory.Exists(extractedRootPath))
                    return false;

                // Office 文件夹路径
                var officeFolder = Path.Combine(extractedRootPath, "Office");
                if (!Directory.Exists(officeFolder))
                    return false;

                // setup.exe 路径
                var setupPath = Path.Combine(officeFolder, "setup.exe");
                if (!File.Exists(setupPath))
                    return false;

                // configuration.xml 路径（大小写都可能存在）
                var configPath = Path.Combine(officeFolder, "Configuration.xml");
                if (!File.Exists(configPath))
                    configPath = Path.Combine(officeFolder, "configuration.xml");

                if (!File.Exists(configPath))
                    return false;

                // 构造启动参数
                var arguments = "/configure \"" + configPath + "\"";

                var psi = new ProcessStartInfo
                {
                    FileName = setupPath,
                    Arguments = arguments,
                    UseShellExecute = false,
                    CreateNoWindow = false, // 允许显示 Office 安装 GUI
                };

                using (var p = Process.Start(psi))
                {
                    p?.WaitForExit(); // 等待安装完成

                    // ExitCode = 0 通常表示成功
                    return p != null && p.ExitCode == 0;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}