﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;


namespace OfficeTool
{
    public class DownloadAndExtractHelper
    {
        /// <summary>
        /// 下载并解压 RAR 文件（支持进度回调）
        /// </summary>
        public async Task<string> DownloadAndExtractAsync(
            string url,
            string fileName,
            Action<double> progressChanged)
        {
            var temp = Path.GetTempPath();
            var rarPath = Path.Combine(temp, fileName);

            if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                await DownloadWithProgressAsync(url, rarPath, progressChanged);
            }
            else if (url.StartsWith("file://", StringComparison.OrdinalIgnoreCase))
            {
                var localPath = new Uri(url).LocalPath;
                await CopyFileWithProgressAsync(localPath, rarPath, progressChanged);
            }
            else
            {
                throw new NotSupportedException("不支持的协议：" + url);
            }

            var unpackDir = Path.Combine(temp, "unpack_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(unpackDir);

            await ExtractRarAsync(rarPath, unpackDir);

            return unpackDir;
        }


        /// <summary>
        /// 兼容.NET 4.8.1 的下载（带进度）
        /// </summary>
        private static async Task DownloadWithProgressAsync(string url, string outputPath, Action<double> progress)
        {
            using (var client = new HttpClient())
            using (var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead))
            {
                response.EnsureSuccessStatusCode();

                var total = response.Content.Headers.ContentLength;

                using (var input = await response.Content.ReadAsStreamAsync())
                using (var output = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    var buffer = new byte[81920];
                    long downloaded = 0;
                    int bytesRead;

                    while ((bytesRead = await input.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    {
                        await output.WriteAsync(buffer, 0, bytesRead);
                        downloaded += bytesRead;

                        if (!total.HasValue || total.Value <= 0) continue;
                        var ratio = (double)downloaded / total.Value;
                        progress?.Invoke(ratio);
                    }
                }
            }

            progress?.Invoke(1.0);
        }

        /// <summary>
        /// File异步下载
        /// </summary>
        private static async Task CopyFileWithProgressAsync(string source, string dest, Action<double> progress)
        {
            const int bufferSize = 81920;

            using (var input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var output = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                var total = input.Length;
                long copied = 0;

                var buffer = new byte[bufferSize];
                int read;

                while ((read = await input.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    await output.WriteAsync(buffer, 0, read);
                    copied += read;

                    var ratio = (double)copied / total;
                    progress?.Invoke(ratio);
                }
            }

            progress?.Invoke(1.0);
        }


        /// <summary>
        /// 使用 WinRAR 解压
        /// </summary>
        private static async Task ExtractRarAsync(string rarFile, string destFolder)
        {
            const string libraryPath = @"D:\Software\Install\WinRAR\WinRAR.exe";

            if (!File.Exists(libraryPath))
                throw new FileNotFoundException("WinRAR 未安装或路径错误: " + libraryPath);

            var args = $"x -ibck -o+ \"{rarFile}\" \"{destFolder}\\\"";

            var p = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = libraryPath,
                    Arguments = args,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                }
            };

            p.Start();

            // 异步等待，不阻塞 UI
            await Task.Run(() => p.WaitForExit());
        }
    }
}