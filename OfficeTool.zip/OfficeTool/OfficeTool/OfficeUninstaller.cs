﻿using System;
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;

namespace OfficeTool
{
    public abstract class OfficeUninstaller
    {
        /// <summary>
        /// 卸载本机 Office 2021
        /// </summary>
        /// <returns>true 卸载完成，false 失败或异常</returns>
        public static bool UninstallOffice()
        {
            try
            {
                var setupPath = GetOffice2021SetupPath();
                if (string.IsNullOrEmpty(setupPath) || !File.Exists(setupPath))
                    return false;

                // 使用命令行启动卸载
                var psi = new ProcessStartInfo
                {
                    FileName = setupPath,
                    Arguments = "/uninstall ProPlus /dll OSPP.VBS", // /uninstall /modify 也可，取决于 Office SKU
                    UseShellExecute = false,
                    CreateNoWindow = false, // 允许显示卸载窗口
                };

                using (var p = Process.Start(psi))
                {
                    p?.WaitForExit(); // 等待卸载完成
                    return p != null && p.ExitCode == 0; // 0表示成功
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 获取 Office 2021 安装 Setup.exe 路径
        /// </summary>
        private static string GetOffice2021SetupPath()
        {
            // Office 2021 默认安装路径（Click-to-Run 方式）
            var possiblePaths = new[]
            {
                @"C:\Program Files\Microsoft Office\root\Office16\Setup.exe",
                @"C:\Program Files (x86)\Microsoft Office\root\Office16\Setup.exe"
            };

            foreach (var path in possiblePaths)
            {
                if (File.Exists(path))
                    return path;
            }

            // 可选：从注册表查询 Click-to-Run 安装路径
            const string key = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Office16.PROPLUS2021";
            using (var reg = Registry.LocalMachine.OpenSubKey(key))
            {
                if (reg == null) return null; // 未找到
                var installPath = reg.GetValue("InstallLocation") as string;
                if (string.IsNullOrEmpty(installPath)) return null; // 未找到
                var exe = Path.Combine(installPath, "Setup.exe");
                if (File.Exists(exe))
                    return exe;
            }

            return null; // 未找到
        }
    }
}