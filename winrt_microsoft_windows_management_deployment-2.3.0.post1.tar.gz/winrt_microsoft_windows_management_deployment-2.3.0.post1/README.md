<!-- warning: Please don't edit this file. It was automatically generated. -->

# winrt-Microsoft.Windows.Management.Deployment

ATTENTION: This package has been renamed to
[winui3-Microsoft.Windows.Management.Deployment](https://pypi.org/project/winui3-Microsoft.Windows.Management.Deployment/).
Use the new package for the latest updates.

Windows Runtime (WinRT) APIs for for the `Microsoft.Windows.Management.Deployment` namespace.

This package provides the `winrt.microsoft.windows.management.deployment` module.
